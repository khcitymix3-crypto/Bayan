# استقرار سریع بیان روی VPS (اوبونتو)

1) نصب Bun:            curl -fsSL https://bun.sh/install | bash
2) آپلود این پوشه:     scp -r BAYAN root@SERVER_IP:/root/bayan   (یا git clone)
3) نصب وابستگی‌ها:      cd /root/bayan && bun install
4) دیتابیس:            DATABASE_URL=file:/root/bayan/db/custom.db bunx prisma db push
                       (فایل db/custom.db از قبل آماده است؛ برای دیتای خالی حذفش کنید)
5) بیلد:               bun run build
6) اجرا:               bunx pm2 start "NODE_ENV=production DATABASE_URL=file:/root/bayan/db/custom.db bun .next/standalone/server.js" --name bayan
7) HTTPS با Caddy:     apt install caddy && /etc/caddy/Caddyfile را از فایل Caddyfile همین بسته کپی کنید و دامنه را عوض کنید
8) تست:                curl -I http://localhost:3000  →  HTTP 200

پورت اپ: 3000 (داخل سرور) — برای دنیای بیرون از Caddy/Nginx روی 80/443 استفاده کنید.
