// ============================================================
// BAYAN | بیان — داده اولیه: مدیر، کاربران نمونه، پست‌ها، گروه، کانال، کسب‌وکارها
// اجرا: bunx tsx prisma/seed.ts  (یا bun prisma/seed.ts)
// ============================================================
import { PrismaClient } from '@prisma/client'
import { createHash, randomBytes, scryptSync } from 'crypto'

const db = new PrismaClient()

function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex')
  const hash = scryptSync(password, salt, 64).toString('hex')
  return `scrypt$${salt}$${hash}`
}

async function main() {
  console.log('🌱 Seeding BAYAN...')

  // اگر قبلاً seed شده، اجرا نشود
  const existing = await db.user.count()
  if (existing > 0) {
    console.log('داده‌ها از قبل موجود است — رد شد')
    return
  }

  const users = await Promise.all(
    [
      { name: 'مدیر بیان', username: 'admin', phone: '+989120000001', role: 'ADMIN', bio: 'حساب رسمی مدیریت پلتفرم BAYAN | بیان' },
      { name: 'سارا محمدی', username: 'sara', phone: '+989120000002', role: 'USER', bio: 'عکاس وTravel enthusiast | خرمشهر' },
      { name: 'علی رضایی', username: 'ali', phone: '+989120000003', role: 'MODERATOR', bio: 'برنامه‌نویس وب و موبایل' },
      { name: 'نانوایی برادران کریم', username: 'karim_bakery', phone: '+989120000004', role: 'USER', bio: 'نان تازه هر روز صبح' },
      { name: 'رضا احمدی', username: 'reza', phone: '+989120000005', role: 'USER', bio: 'دبیر تاریخ، علاقه‌مند به تاریخ خرمشهر' },
    ].map((u) =>
      db.user.create({
        data: {
          name: u.name,
          username: u.username,
          phone: u.phone,
          passwordHash: hashPassword('bayan1234'),
          role: u.role,
          bio: u.bio,
          isPhoneVerified: true,
        },
      })
    )
  )

  const [admin, sara, ali, karim, reza] = users

  // دنبال‌کردن‌ها
  for (const follower of [sara, ali, reza]) {
    await db.follow.create({ data: { followerId: follower.id, followingId: admin.id } })
  }
  await db.follow.create({ data: { followerId: admin.id, followingId: sara.id } })
  await db.follow.create({ data: { followerId: ali.id, followingId: sara.id } })

  // پست‌ها
  const posts = await Promise.all([
    db.post.create({
      data: {
        authorId: admin.id,
        content:
          'به BAYAN | بیان خوش آمدید! 🌟\n\nبیان یک اکوسیستم دیجیتال است: شبکه اجتماعی، پیام‌رسان، نقشه هوشمند، صفحه کسب‌وکار و دستیار هوش مصنوعی — همه در یک اپ ساده، سریع و در دسترس همه.\n\n#بیان #BAYAN #خرمشهر',
      },
    }),
    db.post.create({
      data: {
        authorId: sara.id,
        content:
          'غروب امروز کنار اروندرود فوق‌العاده بود. اهالی خرمشهر همیشه به من انرژی می‌دهن 🌅\n\n#خرمشهر #عکاسی #گردشگری',
      },
    }),
    db.post.create({
      data: {
        authorId: reza.id,
        content:
          'یادمان روزهای مقاومت خرمشهر گرامی. این شهر نماد ایستادگی ملت ماست. «خرمشهر آزاد شد» و بیان هم می‌خواهد روایتگری این سرزمین را زنده نگه دارد.\n\n#خرمشهر #تاریخ',
      },
    }),
    db.post.create({
      data: {
        authorId: karim.id,
        content:
          'نان تازه سنگک و بربری از تنور آماده است! از ساعت ۷ صبح تا پایان ظهر در خدمت شما هستیم.\n\n#نانوایی #خرمشهر',
      },
    }),
    db.post.create({
      data: {
        authorId: ali.id,
        content:
          'نکته امنیتی: برای حساب بیان خود رمز عبور طولانی و یکتا انتخاب کنید و کد تأیید خود را با کسی به اشتراک نگذارید.\n\n#امنیت #بیان',
      },
    }),
  ])

  // هشتگ‌ها
  for (const post of posts) {
    const tags = (post.content.match(/#([\w\u0600-\u06FF]+)/g) || []).map((t) => t.slice(1))
    for (const tag of Array.from(new Set(tags))) {
      const h = await db.hashtag.upsert({ where: { tag }, update: {}, create: { tag } })
      await db.postHashtag.create({ data: { postId: post.id, hashtagId: h.id } })
    }
  }

  // لایک و نظر
  await db.like.create({ data: { postId: posts[1].id, userId: admin.id } })
  await db.like.create({ data: { postId: posts[1].id, userId: ali.id } })
  await db.like.create({ data: { postId: posts[0].id, userId: sara.id } })
  await db.post.update({ where: { id: posts[1].id }, data: { likeCount: 2 } })
  await db.post.update({ where: { id: posts[0].id }, data: { likeCount: 1 } })

  const c1 = await db.comment.create({
    data: { postId: posts[1].id, authorId: ali.id, content: 'عکس فوق‌العاده‌ای است! 🌅' },
  })
  await db.comment.create({
    data: { postId: posts[1].id, authorId: sara.id, parentId: c1.id, content: 'ممنون علی جان 🙏' },
  })
  await db.post.update({ where: { id: posts[1].id }, data: { commentCount: 2 } })

  // گروه و کانال
  const group = await db.conversation.create({
    data: { type: 'GROUP', title: 'اهالی خرمشهر', description: 'گفت‌وگوی اهالی و دوستداران خرمشهر', ownerId: admin.id },
  })
  await db.convMember.createMany({
    data: users.map((u) => ({ conversationId: group.id, userId: u.id, role: u.id === admin.id ? 'OWNER' : 'MEMBER' })),
  })
  await db.message.create({ data: { conversationId: group.id, senderId: admin.id, type: 'SYSTEM', content: 'گروه «اهالی خرمشهر» ساخته شد.' } })
  await db.message.create({ data: { conversationId: group.id, senderId: sara.id, content: 'سلام به همه! خوشحالم که اینجا هستیم 🌟' } })
  await db.message.create({ data: { conversationId: group.id, senderId: reza.id, content: 'سلام! چه گروه خوبی.' } })

  const channel = await db.conversation.create({
    data: { type: 'CHANNEL', title: 'اخبار بیان', description: 'کانال رسمی اطلاع‌رسانی پلتفرم بیان', ownerId: admin.id },
  })
  await db.convMember.createMany({
    data: users.map((u) => ({ conversationId: channel.id, userId: u.id, role: u.id === admin.id ? 'OWNER' : 'MEMBER' })),
  })
  await db.message.create({
    data: { conversationId: channel.id, senderId: admin.id, content: '🚀 نسخه اولیه بیان منتشر شد! شبکه اجتماعی، پیام‌رسان، نقشه و دستیار هوشمند فعال است.' },
  })
  await db.message.create({
    data: { conversationId: channel.id, senderId: admin.id, content: '📍 کسب‌وکار خود را در نقشه بیان ثبت کنید تا مشتریان شما را پیدا کنند.' },
  })

  // گفت‌وگوی خصوصی نمونه
  const dm = await db.conversation.create({ data: { type: 'DIRECT' } })
  await db.convMember.createMany({
    data: [
      { conversationId: dm.id, userId: admin.id, role: 'OWNER' },
      { conversationId: dm.id, userId: sara.id, role: 'OWNER' },
    ],
  })
  await db.message.create({ data: { conversationId: dm.id, senderId: sara.id, content: 'سلام، برای صفحه رسمی کسب‌وکار چطور می‌تونم اقدام کنم؟' } })
  await db.message.create({ data: { conversationId: dm.id, senderId: admin.id, content: 'سلام سارا! از منوی کسب‌وکار، گزینه «ثبت کسب‌وکار» را انتخاب کنید.' } })

  // کسب‌وکارهای نمونه — خرمشهر و آبادان
  await db.business.createMany({
    data: [
      { ownerId: karim.id, name: 'نانوایی برادران کریم', category: 'نانوایی', description: 'نان سنگک و بربری تازه — تحویل حضوری', phone: '06152221000', address: 'خیابان اصلی، خرمشهر', city: 'خرمشهر', lat: 30.4402, lng: 48.2687, hours: '۷ تا ۱۴', isVerified: true },
      { name: 'رستوران اروند', category: 'رستوران', description: 'غذاهای جنوبی، ماهی و میگوی تازه', phone: '06152223000', address: 'کنارکه اروندرود، خرمشهر', city: 'خرمشهر', lat: 30.4338, lng: 48.2631, hours: '۱۲ تا ۲۳', isVerified: true },
      { name: 'داروخانه دکتر رحیمی', category: 'داروخانه', description: 'داروخانه شبانه‌روزی', phone: '06152224000', address: 'میدان مرکزی، خرمشهر', city: 'خرمشهر', lat: 30.4425, lng: 48.2759, hours: '۲۴ ساعته' },
      { name: 'هتل پالمیر', category: 'هتل', description: 'اقامتگاه راحت با دسترسی به رودخانه', phone: '06152225000', address: 'بلوار ساحلی، آبادان', city: 'آبادان', lat: 30.3392, lng: 48.3043, hours: '۲۴ ساعته' },
      { name: 'تعمیرگاه خودرو جنوب', category: 'تعمیرگاه', description: 'مکانیکی و برق خودرو انواع ایرانی و خارجی', phone: '06152226000', address: 'جاده کمربندی، خرمشهر', city: 'خرمشهر', lat: 30.4470, lng: 48.2550, hours: '۸ تا ۱۸' },
      { name: 'آرایشگاه مردانه آریا', category: 'خدمات منزل', description: 'خدمات آرایشگاه در محل شما با هماهنگی قبلی', phone: '09161234000', address: 'خدمات در منزل — خرمشهر و آبادان', city: 'خرمشهر', lat: 30.4350, lng: 48.2820, hours: '۱۰ تا ۲۱' },
    ],
  })

  // اعلان خوش‌آمد برای همه
  await db.notification.createMany({
    data: users.map((u) => ({
      userId: u.id,
      type: 'SYSTEM',
      text: 'به BAYAN | بیان خوش آمدید! این نسخه نمایشی با حساب‌های نمونه آماده شده است.',
    })),
  })

  console.log(`✅ Seed کامل شد: ${users.length} کاربر، ${posts.length} پست، ۲ گفت‌وگو، ۶ کسب‌وکار`)
  console.log('👤 حساب مدیر: موبایل 09120000001 | رمز bayan1234')
  console.log('👤 حساب نمونه: موبایل 09120000002 | رمز bayan1234 (username: sara)')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(() => db.$disconnect())
