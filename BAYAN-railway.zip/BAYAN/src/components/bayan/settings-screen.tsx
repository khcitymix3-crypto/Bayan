'use client'

import { useEffect, useState } from 'react'
import { api } from '@/components/bayan/api'
import { ScreenHeader, LoadingBlock } from '@/components/bayan/ui-bits'
import { useBayan } from '@/components/bayan/store'
import { T } from '@/lib/i18n'
import { faNum } from '@/lib/persian'
import { useTheme } from 'next-themes'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Slider } from '@/components/ui/slider'
import { toast } from '@/hooks/use-toast'
import { Loader2, LogOut, Monitor, Moon, ShieldCheck, Smartphone, Sun, Trash2 } from 'lucide-react'

// ============================================================
// BAYAN | بیان — تنظیمات: ظاهر، دسترسی‌پذیری، حریم خصوصی، امنیت
// ============================================================

interface SessionData {
  id: string
  device: string
  createdAt: string
  isCurrent: boolean
}

export function SettingsScreen() {
  const { goBack, me, patchMe } = useBayan()
  const { theme, setTheme } = useTheme()
  const [busy, setBusy] = useState(false)
  const [sessions, setSessions] = useState<SessionData[] | null>(null)
  const [trustedName, setTrustedName] = useState(me?.trustedName || '')
  const [trustedPhone, setTrustedPhone] = useState(me?.trustedPhone || '')

  useEffect(() => {
    api<{ sessions: SessionData[] }>('/auth/sessions')
      .then((r) => setSessions(r.sessions))
      .catch(() => setSessions([]))
  }, [])

  if (!me) return null

  async function patch(body: Record<string, unknown>, message?: string) {
    setBusy(true)
    try {
      const res = await api<{ user: Record<string, unknown> }>('/auth/me', { method: 'PATCH', body })
      patchMe(res.user as never)
      if (message) toast({ description: message })
    } catch (e) {
      toast({ description: e instanceof Error ? e.message : T.common.error, variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  async function logout() {
    await api('/auth/logout', { method: 'POST' }).catch(() => null)
    location.reload()
  }

  async function logoutOthers() {
    try {
      await api('/auth/sessions', { method: 'DELETE' })
      setSessions((s) => (s || []).filter((x) => x.isCurrent))
      toast({ description: T.settings.logoutAll + ' ✓' })
    } catch (e) {
      toast({ description: e instanceof Error ? e.message : T.common.error, variant: 'destructive' })
    }
  }

  const highContrast = document.documentElement.classList.contains('hc-mode')

  return (
    <div>
      <ScreenHeader title={T.settings.title} onBack={goBack} />

      <div className="mx-auto max-w-2xl space-y-6 p-4 pb-24">
        {/* ظاهر */}
        <Section title={T.settings.appearance}>
          <div>
            <Label className="mb-2 block">{T.settings.theme}</Label>
            <div className="grid grid-cols-3 gap-2" role="radiogroup" aria-label={T.settings.theme}>
              {[
                { key: 'light', label: T.settings.light, icon: Sun },
                { key: 'dark', label: T.settings.dark, icon: Moon },
                { key: 'system', label: T.settings.system, icon: Monitor },
              ].map((o) => (
                <button
                  key={o.key}
                  role="radio"
                  aria-checked={theme === o.key}
                  className={`flex min-h-14 flex-col items-center justify-center gap-1 rounded-xl border text-xs font-bold transition-colors ${
                    theme === o.key ? 'border-primary bg-primary/10 text-primary' : 'text-muted-foreground hover:bg-accent'
                  }`}
                  onClick={() => setTheme(o.key)}
                >
                  <o.icon className="h-5 w-5" aria-hidden />
                  {o.label}
                </button>
              ))}
            </div>
          </div>

          {/* اندازه قلم — دسترسی‌پذیری */}
          <div>
            <Label className="mb-2 block">
              {T.settings.fontScale}: <span className="tabular">{faNum(Math.round((me.fontScale || 1) * 100))}٪</span>
            </Label>
            <Slider
              min={0.9}
              max={1.4}
              step={0.1}
              value={[me.fontScale || 1]}
              onValueCommit={([v]) => patch({ fontScale: v }, undefined)}
              onValueChange={([v]) => {
                document.documentElement.style.setProperty('--font-scale', String(v))
              }}
              aria-label={T.settings.fontScale}
            />
          </div>

          {/* کنتراست بالا */}
          <div className="flex items-center justify-between">
            <Label htmlFor="hc">{T.settings.highContrast}</Label>
            <Switch
              id="hc"
              checked={highContrast}
              onCheckedChange={(checked) => {
                document.documentElement.classList.toggle('hc-mode', checked)
                patch({ highContrast: checked })
              }}
              aria-label={T.settings.highContrast}
            />
          </div>
        </Section>

        {/* حریم خصوصی */}
        <Section title={T.settings.privacy}>
          <div>
            <Label className="mb-2 block">{T.settings.whoCanSeeProfile}</Label>
            <SelectRow
              value={me.privacyProfile}
              options={[
                { key: 'EVERYONE', label: T.settings.everyone },
                { key: 'FOLLOWERS', label: T.settings.followers },
                { key: 'NOBODY', label: T.settings.nobody },
              ]}
              onChange={(v) => patch({ privacyProfile: v })}
              ariaLabel={T.settings.whoCanSeeProfile}
            />
          </div>
          <div>
            <Label className="mb-2 block">{T.settings.whoCanMessage}</Label>
            <SelectRow
              value={me.privacyMessage}
              options={[
                { key: 'EVERYONE', label: T.settings.everyone },
                { key: 'FOLLOWERS', label: T.settings.followers },
                { key: 'NOBODY', label: T.settings.nobody },
              ]}
              onChange={(v) => patch({ privacyMessage: v })}
              ariaLabel={T.settings.whoCanMessage}
            />
          </div>

          {/* یار بیان */}
          <div className="rounded-xl border border-primary/25 bg-primary/5 p-3">
            <Label className="mb-2 block font-bold">{T.settings.trusted}</Label>
            <div className="space-y-2">
              <Input
                value={trustedName}
                onChange={(e) => setTrustedName(e.target.value)}
                placeholder={T.settings.trustedName}
                aria-label={T.settings.trustedName}
              />
              <Input
                value={trustedPhone}
                onChange={(e) => setTrustedPhone(e.target.value)}
                placeholder={T.settings.trustedPhone}
                dir="ltr"
                className="text-left"
                inputMode="tel"
                aria-label={T.settings.trustedPhone}
              />
              <Button
                size="sm"
                className="min-h-10 w-full"
                disabled={busy}
                onClick={() => patch({ trustedName, trustedPhone }, T.common.save + ' ✓')}
              >
                {T.common.save}
              </Button>
            </div>
          </div>
        </Section>

        {/* امنیت */}
        <Section title={T.settings.security}>
          <div className="flex items-center gap-2 rounded-xl bg-muted/50 p-3 text-sm text-muted-foreground">
            <ShieldCheck className="h-5 w-5 shrink-0 text-primary" aria-hidden />
            رمز عبور با scrypt هش شده، نشست‌ها httpOnly هستند و ورود مشکوک محدود می‌شود
          </div>

          <div>
            <Label className="mb-2 block">{T.settings.sessions}</Label>
            {sessions === null ? (
              <LoadingBlock />
            ) : (
              <div className="space-y-2">
                {sessions.map((s) => (
                  <div key={s.id} className="flex items-center gap-2 rounded-xl border p-3 text-sm">
                    <Smartphone className="h-4 w-4 shrink-0 text-muted-foreground" aria-hidden />
                    <span className="min-w-0 flex-1 truncate">{s.device || 'دستگاه ناشناس'}</span>
                    {s.isCurrent && <span className="shrink-0 text-xs font-bold text-primary">{T.settings.current}</span>}
                  </div>
                ))}
                {sessions.length > 1 && (
                  <Button variant="outline" className="w-full min-h-11" onClick={logoutOthers}>
                    <Trash2 className="h-4 w-4" aria-hidden /> {T.settings.logoutAll}
                  </Button>
                )}
              </div>
            )}
          </div>

          <Button variant="destructive" className="w-full min-h-11 font-bold" onClick={logout}>
            <LogOut className="h-4 w-4" aria-hidden /> {T.settings.logout}
          </Button>
        </Section>

        {/* زبان */}
        <Section title={T.settings.language}>
          <div className="space-y-2 text-sm">
            <p className="flex items-center justify-between rounded-xl border p-3">
              <span className="font-bold">{T.settings.languageFa}</span>
              <span className="text-primary">✓</span>
            </p>
            <p className="flex items-center justify-between rounded-xl border border-dashed p-3 text-muted-foreground">
              <span>{T.settings.languageSoon}</span>
            </p>
          </div>
        </Section>

        {/* درباره */}
        <Section title={T.settings.about}>
          <p className="text-sm leading-7 text-muted-foreground">{T.settings.aboutText}</p>
        </Section>
      </div>
    </div>
  )
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section aria-label={title}>
      <h2 className="mb-2.5 text-sm font-black text-foreground">{title}</h2>
      <div className="space-y-3">{children}</div>
    </section>
  )
}

function SelectRow({
  value,
  options,
  onChange,
  ariaLabel,
}: {
  value: string
  options: Array<{ key: string; label: string }>
  onChange: (v: string) => void
  ariaLabel: string
}) {
  return (
    <div className="grid grid-cols-3 gap-2" role="radiogroup" aria-label={ariaLabel}>
      {options.map((o) => (
        <button
          key={o.key}
          role="radio"
          aria-checked={value === o.key}
          className={`min-h-11 rounded-xl border text-xs font-bold transition-colors ${
            value === o.key ? 'border-primary bg-primary/10 text-primary' : 'text-muted-foreground hover:bg-accent'
          }`}
          onClick={() => onChange(o.key)}
        >
          {o.label}
        </button>
      ))}
    </div>
  )
}
