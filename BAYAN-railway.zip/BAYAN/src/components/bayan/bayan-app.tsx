'use client'

import { useEffect, useState } from 'react'
import { useBayan, loadMe } from '@/components/bayan/store'
import { T } from '@/lib/i18n'
import { faNum } from '@/lib/persian'
import { AuthScreen } from '@/components/bayan/auth-screen'
import { HomeScreen } from '@/components/bayan/home-screen'
import { ExploreScreen } from '@/components/bayan/explore-screen'
import { ProfileScreen } from '@/components/bayan/profile-screen'
import { MessagesScreen, ChatScreen } from '@/components/bayan/messages-screen'
import { NotificationsScreen } from '@/components/bayan/notifications-screen'
import { SettingsScreen } from '@/components/bayan/settings-screen'
import { AdminScreen } from '@/components/bayan/admin-screen'
import { AiScreen } from '@/components/bayan/ai-screen'
import { SosScreen } from '@/components/bayan/sos-screen'
import { MapScreen } from '@/components/bayan/map-screen'
import { BusinessScreen } from '@/components/bayan/business-screen'
import { Composer } from '@/components/bayan/post-card'
import { HashtagScreen } from '@/components/bayan/hashtag-screen'
import { LoadingBlock } from '@/components/bayan/ui-bits'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetHeader as SheetHead, SheetTitle } from '@/components/ui/sheet'
import {
  Bell, Compass, Home, Map as MapIcon, MessageCircle, MoreHorizontal,
  Phone, Settings, ShieldCheck, Sparkles, Store, User, Plus,
} from 'lucide-react'

// ============================================================
// BAYAN | بیان — پوسته اصلی SPA
// ناوبری: نوار پایین (خانه/کشف/+/پیام‌ها/پروفایل) + منوی بیشتر
// ============================================================

export function BayanApp() {
  const { ready, me, view, navigate, goBack, unread, composerOpen, setComposerOpen, moreOpen, setMoreOpen, setMe } = useBayan()
  const [online, setOnline] = useState(true)

  // بازیابی نشست هنگام شروع
  useEffect(() => {
    loadMe().then(({ user, unread: u }) => setMe(user, u))
  }, [setMe])

  // وضعیت آنلاین
  useEffect(() => {
    const on = () => setOnline(true)
    const off = () => setOnline(false)
    window.addEventListener('online', on)
    window.addEventListener('offline', off)
    return () => {
      window.removeEventListener('online', on)
      window.removeEventListener('offline', off)
    }
  }, [])

  // رجیستر Service Worker (نصب PWA)
  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').catch(() => null)
    }
  }, [])

  // ثبت بازدید پست از لینک اشتراک‌گذاری (?post=ID)
  useEffect(() => {
    const postId = new URLSearchParams(location.search).get('post')
    if (postId) navigate({ screen: 'home' })
  }, [navigate])

  if (!ready) {
    return (
      <div className="flex min-h-dvh flex-col items-center justify-center gap-3 bg-gradient-to-b from-secondary/60 to-background">
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-lg">
          <Sparkles className="h-8 w-8" aria-hidden />
        </div>
        <p className="text-lg font-black">{T.brand}</p>
        <LoadingBlock />
      </div>
    )
  }

  // صفحه احراز هویت برای مهمان‌ها وقتی به آن نیاز است
  const guestScreens = ['home', 'explore', 'map', 'business', 'sos']
  const needAuth = !me && !guestScreens.includes(view.screen)

  let content: React.ReactNode
  if (needAuth) {
    content = <AuthScreen />
  } else {
    switch (view.screen) {
      case 'home':
        content = <HomeScreen />
        break
      case 'explore':
        content = <ExploreScreen />
        break
      case 'hashtag':
        content = <HashtagScreen tag={view.tag || ''} />
        break
      case 'messages':
        content = <MessagesScreen pendingUsername={view.username} />
        break
      case 'chat':
        content = view.conversationId ? (
          <ChatScreen conversationId={view.conversationId} />
        ) : (
          <MessagesScreen />
        )
        break
      case 'profile':
        content = <ProfileScreen username={view.username || me?.username || ''} />
        break
      case 'notifications':
        content = <NotificationsScreen />
        break
      case 'settings':
        content = <SettingsScreen />
        break
      case 'admin':
        content = <AdminScreen />
        break
      case 'ai':
        content = <AiScreen />
        break
      case 'sos':
        content = <SosScreen />
        break
      case 'map':
        content = <MapScreenWrapper />
        break
      case 'business':
        content = <BusinessScreen />
        break
      default:
        content = <HomeScreen />
    }
  }

  const fullScreen = ['chat', 'ai', 'sos', 'map'].includes(view.screen)
  const showNav = !fullScreen && !needAuth && view.screen !== 'auth'

  return (
    <div className="min-h-dvh">
      {/* هدر عمومی (برای صفحاتی که هدر اختصاصی ندارند) */}
      {showNav && <TopBar />}

      <main className={showNav ? 'pb-24' : ''} aria-label={T.brand}>
        {content}
      </main>

      {/* نوار پایین + دکمه مرکزی */}
      {showNav && <BottomNav />}

      {/* سازنده پست */}
      {me && <Composer open={composerOpen} onClose={() => setComposerOpen(false)} />}

      {/* منوی بیشتر */}
      {me && (
        <Sheet open={moreOpen} onOpenChange={setMoreOpen}>
          <SheetContent side="bottom" className="rounded-t-3xl">
            <SheetHead className="sr-only">
              <SheetTitle>{T.nav.more}</SheetTitle>
            </SheetHead>
            <div className="grid grid-cols-4 gap-3 p-2 pb-8">
              <MoreItem icon={Bell} label={T.nav.notifications} badge={unread} onClick={() => navigate({ screen: 'notifications' })} />
              <MoreItem icon={MapIcon} label={T.nav.map} onClick={() => navigate({ screen: 'map' })} />
              <MoreItem icon={Store} label={T.nav.business} onClick={() => navigate({ screen: 'business' })} />
              <MoreItem icon={Sparkles} label={T.nav.ai} onClick={() => navigate({ screen: 'ai' })} />
              <MoreItem icon={Phone} label={T.nav.sos} onClick={() => navigate({ screen: 'sos' })} danger />
              <MoreItem icon={Settings} label={T.nav.settings} onClick={() => navigate({ screen: 'settings' })} />
              {['ADMIN', 'MODERATOR'].includes(me.role) && (
                <MoreItem icon={ShieldCheck} label={T.nav.admin} onClick={() => navigate({ screen: 'admin' })} />
              )}
              <MoreItem icon={Plus} label={T.post.createPost} onClick={() => setComposerOpen(true)} />
            </div>
          </SheetContent>
        </Sheet>
      )}

      {!online && (
        <div className="fixed bottom-24 right-1/2 z-50 translate-x-1/2 rounded-full bg-foreground px-4 py-1.5 text-xs font-bold text-background shadow-lg" role="status">
          {T.common.offline}
        </div>
      )}
    </div>
  )
}

function MapScreenWrapper() {
  const { goBack } = useBayan()
  return <MapScreen onBack={goBack} />
}

// ============================================================
// هدر بالا
// ============================================================

function TopBar() {
  const { me, navigate, unread, setMoreOpen } = useBayan()

  return (
    <header className="sticky top-0 z-30 border-b bg-background/85 backdrop-blur-md safe-top">
      <div className="mx-auto flex h-14 max-w-2xl items-center gap-2 px-3">
        <button
          type="button"
          className="flex items-center gap-2"
          onClick={() => navigate({ screen: 'home' })}
          aria-label={T.brand}
        >
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-primary-foreground" aria-hidden>
            <Sparkles className="h-5 w-5" />
          </span>
          <span className="text-lg font-black tracking-tight">{T.brandShort}</span>
        </button>

        <div className="mr-auto flex items-center gap-1">
          {!me && (
            <Button size="sm" className="min-h-10 px-4 font-bold" onClick={() => navigate({ screen: 'auth' })}>
              {T.auth.login}
            </Button>
          )}
          {me && (
            <button
              type="button"
              className="relative flex h-11 w-11 items-center justify-center rounded-full hover:bg-accent"
              onClick={() => navigate({ screen: 'notifications' })}
              aria-label={`${T.nav.notifications} (${unread} خوانده‌نشده)`}
            >
              <Bell className="h-5 w-5" aria-hidden />
              {unread > 0 && (
                <span className="absolute right-2 top-2 flex h-4 min-w-4 items-center justify-center rounded-full bg-destructive px-1 text-[0.6rem] font-bold text-white tabular">
                  {faNum(unread > 9 ? '۹+' : unread)}
                </span>
              )}
            </button>
          )}
          <button
            type="button"
            className="flex h-11 w-11 items-center justify-center rounded-full hover:bg-accent"
            onClick={() => (me ? setMoreOpen(true) : navigate({ screen: 'auth' }))}
            aria-label={T.nav.more}
          >
            <MoreHorizontal className="h-5 w-5" aria-hidden />
          </button>
        </div>
      </div>
    </header>
  )
}

// ============================================================
// نوار پایین
// ============================================================

function BottomNav() {
  const { view, navigate, setComposerOpen, me } = useBayan()

  const items = [
    { key: 'home', label: T.nav.home, icon: Home, onClick: () => navigate({ screen: 'home' }) },
    { key: 'explore', label: T.nav.explore, icon: Compass, onClick: () => navigate({ screen: 'explore' }) },
    { key: 'create', label: '', icon: Plus, onClick: () => (me ? setComposerOpen(true) : navigate({ screen: 'auth' })) },
    { key: 'messages', label: T.nav.messages, icon: MessageCircle, onClick: () => navigate({ screen: me ? 'messages' : 'auth' }) },
    {
      key: 'profile',
      label: T.nav.profile,
      icon: User,
      onClick: () => navigate(me ? { screen: 'profile', username: me.username } : { screen: 'auth' }),
    },
  ]

  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-30 border-t bg-background/90 backdrop-blur-md safe-bottom"
      aria-label="ناوبری اصلی"
    >
      <div className="mx-auto flex max-w-2xl items-stretch justify-around">
        {items.map((item) => {
          const active = view.screen === item.key
          if (item.key === 'create') {
            return (
              <button
                key={item.key}
                type="button"
                onClick={item.onClick}
                className="relative -top-3 flex h-12 w-12 items-center justify-center self-center rounded-2xl bg-primary text-primary-foreground shadow-lg shadow-primary/30 transition-transform active:scale-95"
                aria-label={T.post.createPost}
              >
                <item.icon className="h-6 w-6" aria-hidden />
              </button>
            )
          }
          return (
            <button
              key={item.key}
              type="button"
              onClick={item.onClick}
              aria-current={active ? 'page' : undefined}
              className={`flex min-h-14 flex-1 flex-col items-center justify-center gap-0.5 text-[0.65rem] font-bold transition-colors ${
                active ? 'text-primary' : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <item.icon className={`h-5 w-5 ${active ? 'fill-primary/15' : ''}`} aria-hidden />
              {item.label}
            </button>
          )
        })}
      </div>
    </nav>
  )
}

function MoreItem({
  icon: Icon,
  label,
  onClick,
  badge,
  danger,
}: {
  icon: typeof Home
  label: string
  onClick: () => void
  badge?: number
  danger?: boolean
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`relative flex min-h-20 flex-col items-center justify-center gap-1.5 rounded-2xl border text-[0.7rem] font-bold transition-colors hover:bg-accent ${
        danger ? 'border-red-500/25 text-red-600' : 'text-foreground'
      }`}
    >
      <Icon className="h-6 w-6" aria-hidden />
      {label}
      {badge ? (
        <span className="absolute right-2 top-2 flex h-4 min-w-4 items-center justify-center rounded-full bg-destructive px-1 text-[0.55rem] text-white tabular">
          {faNum(badge)}
        </span>
      ) : null}
    </button>
  )
}
