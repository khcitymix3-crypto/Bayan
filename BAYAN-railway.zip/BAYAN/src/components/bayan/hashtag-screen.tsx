'use client'

import { useCallback, useEffect, useState } from 'react'
import { api } from '@/components/bayan/api'
import { EmptyState, FeedSkeleton, ScreenHeader } from '@/components/bayan/ui-bits'
import { PostCard, type PostData } from '@/components/bayan/post-card'
import { useBayan } from '@/components/bayan/store'
import { T } from '@/lib/i18n'
import { Hash } from 'lucide-react'

// ============================================================
// BAYAN | بیان — فید هشتگ
// ============================================================

export function HashtagScreen({ tag }: { tag: string }) {
  const { goBack } = useBayan()
  const [posts, setPosts] = useState<PostData[]>([])
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const res = await api<{ posts: PostData[] }>(`/posts?tab=hashtag&tag=${encodeURIComponent(tag)}`)
      setPosts(res.posts)
    } finally {
      setLoading(false)
    }
  }, [tag])

  useEffect(() => {
    load()
  }, [load])

  return (
    <div>
      <ScreenHeader title={`#${tag}`} subtitle={T.explore.hashtags} onBack={goBack} />
      {loading ? (
        <FeedSkeleton />
      ) : posts.length === 0 ? (
        <EmptyState icon={<Hash className="h-12 w-12" />} title={T.explore.empty} />
      ) : (
        <div className="mx-auto max-w-2xl space-y-3 p-3">
          {posts.map((p) => (
            <PostCard key={p.id} post={p} highlightTag={tag} />
          ))}
        </div>
      )}
    </div>
  )
}
