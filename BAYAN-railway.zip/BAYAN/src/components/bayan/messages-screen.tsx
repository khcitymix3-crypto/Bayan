'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { api } from '@/components/bayan/api'
import { BayanAvatar, EmptyState, LoadingBlock, ScreenHeader } from '@/components/bayan/ui-bits'
import { useBayan } from '@/components/bayan/store'
import { T } from '@/lib/i18n'
import { faNum, timeAgoFa } from '@/lib/persian'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { toast } from '@/hooks/use-toast'
import {
  ArrowRight, Megaphone, MessageCircle, Plus, Send, Users, ImagePlus, Loader2,
} from 'lucide-react'

// ============================================================
// BAYAN | بیان — پیام‌رسان: فهرست گفت‌وگو + چت با Polling
// فاز ۲: تعویض به WebSocket برای هم‌زمانی کامل
// ============================================================

interface ConversationData {
  id: string
  type: string
  title: string
  avatarUrl: string | null
  otherUsername: string | null
  description: string
  membersCount: number
  lastMessage: { content: string; senderName: string; createdAt: string; isMine: boolean } | null
  lastMessageAt: string
  unread: number
  myRole: string
}

interface MessageData {
  id: string
  type: string
  content: string
  mediaId: string | null
  createdAt: string
  isMine: boolean
  sender: { id: string; name: string; username: string; avatarUrl: string | null } | null
}

export function MessagesScreen({ openConversationId, pendingUsername }: { openConversationId?: string; pendingUsername?: string }) {
  const { navigate, goBack } = useBayan()
  const [conversations, setConversations] = useState<ConversationData[]>([])
  const [loading, setLoading] = useState(true)
  const [tab, setTab] = useState<'all' | 'DIRECT' | 'GROUP' | 'CHANNEL'>('all')
  const [showCreate, setShowCreate] = useState(false)

  const load = useCallback(async () => {
    try {
      const res = await api<{ conversations: ConversationData[] }>('/conversations')
      setConversations(res.conversations)
    } catch (e) {
      toast({ description: e instanceof Error ? e.message : T.common.error, variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    load()
    const t = setInterval(load, 7000)
    return () => clearInterval(t)
  }, [load])

  // گفت‌وگو با کاربر مشخص (از پروفایل)
  useEffect(() => {
    if (pendingUsername) {
      startDirect(pendingUsername)
    }
  }, [pendingUsername])

  // باز کردن مستقیم گفت‌وگو (از کشف)
  useEffect(() => {
    if (openConversationId) {
      navigate({ screen: 'chat', conversationId: openConversationId })
    }
  }, [openConversationId])

  async function startDirect(username: string) {
    try {
      const res = await api<{ conversationId: string }>('/conversations', { body: { type: 'DIRECT', username } })
      navigate({ screen: 'chat', conversationId: res.conversationId })
    } catch (e) {
      toast({ description: e instanceof Error ? e.message : T.common.error, variant: 'destructive' })
    }
  }

  const filtered = tab === 'all' ? conversations : conversations.filter((c) => c.type === tab)

  return (
    <div>
      <ScreenHeader
        title={T.chat.title}
        onBack={goBack}
        action={
          <Button size="icon" variant="ghost" className="min-h-11 w-11" onClick={() => setShowCreate(true)} aria-label={T.chat.newGroup}>
            <Plus className="h-5 w-5" />
          </Button>
        }
      />

      <div className="sticky top-14 z-20 flex gap-1 border-b bg-background/85 px-2 py-1.5 backdrop-blur-md" role="tablist">
        {[
          { key: 'all' as const, label: T.explore.all },
          { key: 'DIRECT' as const, label: T.chat.direct },
          { key: 'GROUP' as const, label: T.chat.groups },
          { key: 'CHANNEL' as const, label: T.chat.channels },
        ].map((t) => (
          <button
            key={t.key}
            role="tab"
            aria-selected={tab === t.key}
            className={`min-h-9 rounded-full px-4 text-sm font-semibold transition-colors ${
              tab === t.key ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-accent'
            }`}
            onClick={() => setTab(t.key)}
          >
            {t.label}
          </button>
        ))}
      </div>

      {loading ? (
        <LoadingBlock />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={<MessageCircle className="h-12 w-12" />}
          title={T.chat.emptyConversations}
          hint="از کشف، کاربران را پیدا کنید و پیام بدهید"
        />
      ) : (
        <div className="mx-auto max-w-2xl divide-y">
          {filtered.map((c) => (
            <button
              key={c.id}
              type="button"
              className="flex w-full items-center gap-3 p-3.5 text-right transition-colors hover:bg-accent/50"
              onClick={() => navigate({ screen: 'chat', conversationId: c.id })}
            >
              {c.type === 'DIRECT' ? (
                <BayanAvatar name={c.title} src={c.avatarUrl} />
              ) : (
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                  {c.type === 'CHANNEL' ? <Megaphone className="h-5 w-5" aria-hidden /> : <Users className="h-5 w-5" aria-hidden />}
                </div>
              )}
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <p className="truncate text-sm font-bold">
                    {c.title}
                    {c.type !== 'DIRECT' && <span className="mr-1.5 text-xs font-normal text-muted-foreground">({faNum(c.membersCount)})</span>}
                  </p>
                  {c.lastMessage && (
                    <span className="shrink-0 text-[0.65rem] text-muted-foreground">{timeAgoFa(c.lastMessage.createdAt)}</span>
                  )}
                </div>
                <div className="flex items-center justify-between gap-2">
                  <p className="truncate text-xs text-muted-foreground">
                    {c.lastMessage ? `${c.lastMessage.isMine ? 'شما: ' : c.type !== 'DIRECT' ? c.lastMessage.senderName + ': ' : ''}${c.lastMessage.content}` : '—'}
                  </p>
                  {c.unread > 0 && (
                    <span className="flex h-5 min-w-5 shrink-0 items-center justify-center rounded-full bg-primary px-1.5 text-[0.65rem] font-bold text-primary-foreground tabular">
                      {faNum(c.unread)}
                    </span>
                  )}
                </div>
              </div>
            </button>
          ))}
        </div>
      )}

      {showCreate && <CreateGroupChannel onClose={() => setShowCreate(false)} onCreated={load} />}
    </div>
  )
}

// ============================================================
// صفحه چت
// ============================================================

export function ChatScreen({ conversationId }: { conversationId: string }) {
  const { goBack, navigate, me } = useBayan()
  const [messages, setMessages] = useState<MessageData[]>([])
  const [conv, setConv] = useState<{ title: string; type: string; myRole: string; description: string } | null>(null)
  const [text, setText] = useState('')
  const [sending, setSending] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [showAdd, setShowAdd] = useState(false)
  const bottomRef = useRef<HTMLDivElement>(null)

  const load = useCallback(
    async (silent = false) => {
      try {
        const res = await api<{ conversation: { title: string; type: string; myRole: string; description: string }; messages: MessageData[] }>(
          `/conversations/${conversationId}/messages`
        )
        setConv(res.conversation)
        setMessages(res.messages)
      } catch (e) {
        if (!silent) toast({ description: e instanceof Error ? e.message : T.common.error, variant: 'destructive' })
      }
    },
    [conversationId]
  )

  useEffect(() => {
    load()
    const t = setInterval(() => load(true), 4000)
    return () => clearInterval(t)
  }, [load])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages.length])

  async function send() {
    const content = text.trim()
    if (!content || sending) return
    setSending(true)
    try {
      const res = await api<{ message: MessageData }>(`/conversations/${conversationId}/messages`, { body: { content } })
      setMessages((m) => [...m, res.message])
      setText('')
    } catch (e) {
      toast({ description: e instanceof Error ? e.message : T.common.error, variant: 'destructive' })
    } finally {
      setSending(false)
    }
  }

  async function sendImage(file: File) {
    setUploading(true)
    try {
      const fd = new FormData()
      fd.append('file', file)
      const up = await api<{ mediaId: string }>('/upload', { formData: fd })
      const res = await api<{ message: MessageData }>(`/conversations/${conversationId}/messages`, {
        body: { content: '🖼', mediaId: up.mediaId },
      })
      setMessages((m) => [...m, res.message])
    } catch (e) {
      toast({ description: e instanceof Error ? e.message : T.common.error, variant: 'destructive' })
    } finally {
      setUploading(false)
    }
  }

  const canPost = conv && (conv.type !== 'CHANNEL' || conv.myRole !== 'MEMBER')

  return (
    <div className="flex h-dvh flex-col">
      <ScreenHeader
        title={conv?.title || T.chat.title}
        subtitle={conv ? (conv.type === 'DIRECT' ? T.chat.direct : conv.type === 'GROUP' ? `گروه · ${T.chat.messages}` : 'کانال') : undefined}
        onBack={goBack}
        action={
          conv && conv.type !== 'DIRECT' && conv.myRole !== 'MEMBER' ? (
            <Button size="icon" variant="ghost" className="min-h-11 w-11" onClick={() => setShowAdd(true)} aria-label={T.chat.addMember}>
              <Plus className="h-5 w-5" />
            </Button>
          ) : undefined
        }
      />

      {/* پیام‌ها */}
      <div className="bayan-scroll flex-1 overflow-y-auto px-3 py-3">
        <div className="mx-auto max-w-2xl space-y-2.5">
          {messages.map((m) => {
            if (m.type === 'SYSTEM') {
              return (
                <p key={m.id} className="text-center text-xs text-muted-foreground">
                  {m.content}
                </p>
              )
            }
            return (
              <div key={m.id} className={`flex ${m.isMine ? 'justify-start flex-row-reverse' : 'justify-end'} gap-2`}>
                {!m.isMine && m.sender && (
                  <button type="button" onClick={() => navigate({ screen: 'profile', username: m.sender!.username })} aria-label={m.sender.name}>
                    <BayanAvatar name={m.sender.name} src={m.sender.avatarUrl} size="sm" />
                  </button>
                )}
                <div
                  className={`max-w-[75%] px-3.5 py-2.5 shadow-sm ${
                    m.isMine ? 'chat-bubble-me bg-primary text-primary-foreground' : 'chat-bubble-them bg-muted'
                  }`}
                >
                  {!m.isMine && conv?.type !== 'DIRECT' && m.sender && (
                    <p className="mb-0.5 text-xs font-bold text-primary">{m.sender.name}</p>
                  )}
                  {m.mediaId && (
                    <img src={`/api/media/${m.mediaId}`} alt="تصویر پیام" className="mb-1 max-h-64 rounded-lg object-cover" loading="lazy" />
                  )}
                  <p className="whitespace-pre-wrap break-words text-sm leading-6">{m.content}</p>
                  <p className={`mt-1 text-[0.6rem] ${m.isMine ? 'text-primary-foreground/70' : 'text-muted-foreground'}`} dir="ltr">
                    {timeAgoFa(m.createdAt)}
                  </p>
                </div>
              </div>
            )
          })}
          <div ref={bottomRef} />
        </div>
      </div>

      {/* ارسال */}
      <div className="border-t bg-background p-2.5 safe-bottom">
        {canPost ? (
          <div className="mx-auto flex max-w-2xl items-center gap-2">
            <label className="flex h-11 w-11 shrink-0 cursor-pointer items-center justify-center rounded-full text-muted-foreground hover:bg-accent" aria-label={T.post.addImage}>
              {uploading ? <Loader2 className="h-5 w-5 animate-spin" aria-hidden /> : <ImagePlus className="h-5 w-5" aria-hidden />}
              <input
                type="file"
                accept="image/jpeg,image/png,image/webp"
                className="sr-only"
                onChange={(e) => e.target.files?.[0] && sendImage(e.target.files[0])}
              />
            </label>
            <Input
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder={T.chat.messagePlaceholder}
              className="min-h-11 flex-1 rounded-full"
              aria-label={T.chat.messagePlaceholder}
              onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && send()}
            />
            <Button size="icon" className="h-11 w-11 shrink-0 rounded-full" onClick={send} disabled={sending || !text.trim()} aria-label={T.chat.send}>
              <Send className="h-5 w-5 -scale-x-100" aria-hidden />
            </Button>
          </div>
        ) : (
          <p className="py-2 text-center text-xs text-muted-foreground">{T.chat.channelReadonly}</p>
        )}
      </div>

      {showAdd && (
        <AddMemberDialog
          conversationId={conversationId}
          onClose={() => setShowAdd(false)}
        />
      )}
    </div>
  )
}

// ============================================================
// دیالوگ ساخت گروه/کانال
// ============================================================

function CreateGroupChannel({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const { navigate } = useBayan()
  const [type, setType] = useState<'GROUP' | 'CHANNEL'>('GROUP')
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [busy, setBusy] = useState(false)

  async function create() {
    setBusy(true)
    try {
      const res = await api<{ conversationId: string }>('/conversations', {
        body: { type, title, description },
      })
      onCreated()
      onClose()
      navigate({ screen: 'chat', conversationId: res.conversationId })
    } catch (e) {
      toast({ description: e instanceof Error ? e.message : T.common.error, variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={onClose} role="dialog" aria-modal="true">
      <div className="w-full max-w-sm rounded-2xl bg-card p-5" onClick={(e) => e.stopPropagation()}>
        <h2 className="mb-4 font-bold">{type === 'GROUP' ? T.chat.createGroup : T.chat.createChannel}</h2>
        <div className="mb-4 flex gap-2" role="tablist">
          <button
            className={`min-h-10 flex-1 rounded-xl text-sm font-bold ${type === 'GROUP' ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}
            onClick={() => setType('GROUP')}
          >
            {T.chat.groups}
          </button>
          <button
            className={`min-h-10 flex-1 rounded-xl text-sm font-bold ${type === 'CHANNEL' ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}
            onClick={() => setType('CHANNEL')}
          >
            {T.chat.channels}
          </button>
        </div>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="ctitle">{type === 'GROUP' ? T.chat.groupTitle : T.chat.channelTitle}</Label>
            <Input id="ctitle" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={60} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="cdesc">{T.chat.description}</Label>
            <Input id="cdesc" value={description} onChange={(e) => setDescription(e.target.value)} maxLength={300} />
          </div>
          <div className="flex gap-2 pt-1">
            <Button variant="outline" className="flex-1 min-h-11" onClick={onClose}>
              {T.common.cancel}
            </Button>
            <Button className="flex-1 min-h-11 font-bold" disabled={busy || title.trim().length < 2} onClick={create}>
              {busy ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : T.common.confirm}
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

function AddMemberDialog({ conversationId, onClose }: { conversationId: string; onClose: () => void }) {
  const [username, setUsername] = useState('')
  const [busy, setBusy] = useState(false)

  async function add() {
    setBusy(true)
    try {
      await api(`/conversations/${conversationId}/members`, { body: { username } })
      toast({ description: 'عضو اضافه شد' })
      onClose()
    } catch (e) {
      toast({ description: e instanceof Error ? e.message : T.common.error, variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={onClose} role="dialog" aria-modal="true">
      <div className="w-full max-w-sm rounded-2xl bg-card p-5" onClick={(e) => e.stopPropagation()}>
        <h2 className="mb-4 font-bold">{T.chat.addMember}</h2>
        <div className="space-y-1.5">
          <Label htmlFor="muser">{T.chat.memberUsername}</Label>
          <Input id="muser" dir="ltr" className="text-left" value={username} onChange={(e) => setUsername(e.target.value)} />
        </div>
        <div className="mt-4 flex gap-2">
          <Button variant="outline" className="flex-1 min-h-11" onClick={onClose}>
            {T.common.cancel}
          </Button>
          <Button className="flex-1 min-h-11 font-bold" disabled={busy || !username.trim()} onClick={add}>
            {busy ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <ArrowRight className="h-4 w-4" aria-hidden />}
            {T.chat.addMember}
          </Button>
        </div>
      </div>
    </div>
  )
}
