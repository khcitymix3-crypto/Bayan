'use client'

import { useCallback, useEffect, useState } from 'react'
import { api } from '@/components/bayan/api'
import { BayanAvatar, EmptyState, FeedSkeleton, LoadingBlock, ScreenHeader } from '@/components/bayan/ui-bits'
import { PostCard, type PostData } from '@/components/bayan/post-card'
import { useBayan } from '@/components/bayan/store'
import { T } from '@/lib/i18n'
import { faCompact, faNum, formatJalali } from '@/lib/persian'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { toast } from '@/hooks/use-toast'
import { CalendarDays, Pencil, Send, UserPlus, UserCheck } from 'lucide-react'

// ============================================================
// BAYAN | بیان — پروفایل کاربر (خود و دیگران) + ویرایش پروفایل
// ============================================================

interface ProfileData {
  id: string
  name: string
  username: string
  bio: string
  avatarUrl: string | null
  createdAt: string
  postsCount: number
  followersCount: number
  followingCount: number
  isFollowing: boolean
  isMe: boolean
}

export function ProfileScreen({ username }: { username: string }) {
  const { navigate, goBack, patchMe, me } = useBayan()
  const [profile, setProfile] = useState<ProfileData | null>(null)
  const [posts, setPosts] = useState<PostData[]>([])
  const [loading, setLoading] = useState(true)
  const [tab, setTab] = useState<'posts' | 'saved'>('posts')

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const p = await api<{ profile: ProfileData }>(`/users/${username}`)
      setProfile(p.profile)
      const feed = await api<{ posts: PostData[] }>(`/posts?tab=${p.profile.isMe && tab === 'saved' ? 'saved' : 'user'}&username=${username}`)
      setPosts(feed.posts)
    } catch (e) {
      toast({ description: e instanceof Error ? e.message : T.common.error, variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }, [username, tab])

  useEffect(() => {
    load()
  }, [load])

  async function toggleFollow() {
    if (!profile) return
    try {
      const res = await api<{ isFollowing: boolean }>(`/users/${profile.username}/follow`, { method: 'POST' })
      setProfile((p) => (p ? { ...p, isFollowing: res.isFollowing, followersCount: p.followersCount + (res.isFollowing ? 1 : -1) } : p))
    } catch (e) {
      toast({ description: e instanceof Error ? e.message : T.common.error, variant: 'destructive' })
    }
  }

  if (loading && !profile) {
    return (
      <div>
        <ScreenHeader title={T.nav.profile} onBack={goBack} />
        <FeedSkeleton />
      </div>
    )
  }

  if (!profile) {
    return (
      <div>
        <ScreenHeader title={T.nav.profile} onBack={goBack} />
        <EmptyState title={T.explore.empty} />
      </div>
    )
  }

  return (
    <div>
      <ScreenHeader
        title={profile.name}
        subtitle={`@${profile.username}`}
        onBack={goBack}
        action={
          profile.isMe ? (
            <EditProfileButton
              onSaved={(p) => {
                setProfile((old) => (old ? { ...old, ...p } : old))
                patchMe(p)
                load()
              }}
            />
          ) : (
            <div className="flex gap-1.5">
              <Button size="sm" variant="outline" className="min-h-10" onClick={() => navigate({ screen: 'messages', username: profile.username })}>
                <Send className="h-4 w-4" aria-hidden />
              </Button>
              <Button size="sm" className="min-h-10 px-4" variant={profile.isFollowing ? 'secondary' : 'default'} onClick={toggleFollow}>
                {profile.isFollowing ? (
                  <><UserCheck className="h-4 w-4" aria-hidden /> {T.explore.unfollow}</>
                ) : (
                  <><UserPlus className="h-4 w-4" aria-hidden /> {T.explore.follow}</>
                )}
              </Button>
            </div>
          )
        }
      />

      <div className="mx-auto max-w-2xl">
        {/* هدر پروفایل */}
        <section className="flex items-center gap-4 p-4" aria-label={`پروفایل ${profile.name}`}>
          <BayanAvatar name={profile.name} src={profile.avatarUrl} size="xl" />
          <div className="grid flex-1 grid-cols-3 gap-1 text-center">
            <Stat label={T.profile.posts} value={faNum(profile.postsCount)} />
            <Stat label={T.profile.followers} value={faCompact(profile.followersCount)} />
            <Stat label={T.profile.following} value={faCompact(profile.followingCount)} />
          </div>
        </section>

        <div className="px-4 pb-2">
          {profile.bio && <p className="text-sm leading-6">{profile.bio}</p>}
          <p className="mt-1.5 flex items-center gap-1.5 text-xs text-muted-foreground">
            <CalendarDays className="h-3.5 w-3.5" aria-hidden />
            {T.profile.joinDate} {formatJalali(new Date(profile.createdAt))}
          </p>
        </div>

        {/* تب‌ها */}
        <div className="mt-2 flex border-b" role="tablist">
          <button
            role="tab"
            aria-selected={tab === 'posts'}
            className={`flex min-h-11 flex-1 items-center justify-center text-sm font-semibold ${tab === 'posts' ? 'border-b-2 border-primary text-primary' : 'text-muted-foreground'}`}
            onClick={() => setTab('posts')}
          >
            {T.profile.posts}
          </button>
          {profile.isMe && (
            <button
              role="tab"
              aria-selected={tab === 'saved'}
              className={`flex min-h-11 flex-1 items-center justify-center text-sm font-semibold ${tab === 'saved' ? 'border-b-2 border-primary text-primary' : 'text-muted-foreground'}`}
              onClick={() => setTab('saved')}
            >
              {T.profile.saved}
            </button>
          )}
        </div>

        {loading ? (
          <LoadingBlock />
        ) : posts.length === 0 ? (
          <EmptyState title={T.profile.noPosts} />
        ) : (
          <div className="space-y-3 p-3">
            {posts.map((p) => (
              <PostCard
                key={p.id}
                post={p}
                onChanged={(np) => {
                  if (!np) setPosts((arr) => arr.filter((x) => x.id !== p.id))
                }}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="font-black tabular">{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  )
}

function EditProfileButton({ onSaved }: { onSaved: (p: Partial<ProfileData>) => void }) {
  const { me } = useBayan()
  const [open, setOpen] = useState(false)
  const [name, setName] = useState(me?.name || '')
  const [bio, setBio] = useState(me?.bio || '')
  const [busy, setBusy] = useState(false)

  async function save() {
    setBusy(true)
    try {
      const res = await api<{ user: { name: string; bio: string; username: string; avatarUrl: string | null } }>('/auth/me', {
        method: 'PATCH',
        body: { name, bio },
      })
      onSaved({ name: res.user.name, bio: res.user.bio })
      setOpen(false)
      toast({ description: T.profile.saved2 })
    } catch (e) {
      toast({ description: e instanceof Error ? e.message : T.common.error, variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  return (
    <>
      <Button size="sm" variant="outline" className="min-h-10 px-3" onClick={() => setOpen(true)}>
        <Pencil className="h-4 w-4" aria-hidden /> {T.profile.editProfile}
      </Button>
      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={() => setOpen(false)} role="dialog" aria-modal="true">
          <div className="w-full max-w-sm rounded-2xl bg-card p-5" onClick={(e) => e.stopPropagation()}>
            <h2 className="mb-4 font-bold">{T.profile.editProfile}</h2>
            <div className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="ename">{T.auth.name}</Label>
                <Input id="ename" value={name} onChange={(e) => setName(e.target.value)} maxLength={50} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="ebio">{T.profile.bio}</Label>
                <Input id="ebio" value={bio} onChange={(e) => setBio(e.target.value)} maxLength={300} placeholder="درباره خودتان…" />
              </div>
              <div className="flex gap-2">
                <Button variant="outline" className="flex-1 min-h-11" onClick={() => setOpen(false)}>
                  {T.common.cancel}
                </Button>
                <Button className="flex-1 min-h-11 font-bold" disabled={busy || name.trim().length < 2} onClick={save}>
                  {T.profile.save}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
