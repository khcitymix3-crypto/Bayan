'use client'

import { useEffect, useState } from 'react'
import { api } from '@/components/bayan/api'
import { BayanAvatar, EmptyState, FeedSkeleton } from '@/components/bayan/ui-bits'
import { useBayan } from '@/components/bayan/store'
import { T } from '@/lib/i18n'
import { faCompact, timeAgoFa } from '@/lib/persian'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Search, Hash, Users, FileText, Megaphone, UserPlus } from 'lucide-react'

// ============================================================
// BAYAN | بیان — کشف: جست‌وجوی کاربران، مطالب، کانال‌ها، هشتگ‌ها
// جست‌وجوی فارسی با نرمال‌سازی «ی/ي» و «ک/ك»
// ============================================================

interface SearchResult {
  users: Array<{ id: string; name: string; username: string; avatarUrl: string | null; bio: string }>
  posts: Array<{
    id: string; content: string; mediaUrl: string | null; createdAt: string
    likeCount: number; commentCount: number
    author: { id: string; name: string; username: string; avatarUrl: string | null }
  }>
  channels: Array<{ id: string; type: string; title: string; description: string; membersCount: number }>
  hashtags: Array<{ tag: string; postsCount: number }>
}

const EMPTY: SearchResult = { users: [], posts: [], channels: [], hashtags: [] }

export function ExploreScreen() {
  const { navigate } = useBayan()
  const [q, setQ] = useState('')
  const [result, setResult] = useState<SearchResult>(EMPTY)
  const [searching, setSearching] = useState(false)
  const [searched, setSearched] = useState(false)

  useEffect(() => {
    const term = q.trim()
    if (!term) {
      setResult(EMPTY)
      setSearched(false)
      return
    }
    const t = setTimeout(async () => {
      setSearching(true)
      try {
        const res = await api<SearchResult>(`/search?q=${encodeURIComponent(term)}`)
        setResult(res)
        setSearched(true)
      } catch {
        setResult(EMPTY)
      } finally {
        setSearching(false)
      }
    }, 350)
    return () => clearTimeout(t)
  }, [q])

  const total =
    result.users.length + result.posts.length + result.channels.length + result.hashtags.length

  async function follow(username: string) {
    try {
      await api(`/users/${username}/follow`, { method: 'POST' })
      const res = await api<SearchResult>(`/search?q=${encodeURIComponent(q.trim())}`)
      setResult(res)
    } catch {
      // بی‌صدا
    }
  }

  function openHashtag(tag: string) {
    navigate({ screen: 'hashtag', tag })
  }

  return (
    <div className="mx-auto max-w-2xl pb-4">
      {/* جست‌وجو */}
      <div className="sticky top-14 z-20 border-b bg-background/90 px-3 py-2.5 backdrop-blur-md">
        <div className="relative">
          <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={T.explore.searchPlaceholder}
            className="min-h-11 bg-muted/50 pr-9"
            aria-label={T.explore.title}
            type="search"
          />
        </div>
      </div>

      {searching && <FeedSkeleton />}

      {!searching && !searched && (
        <div className="p-4">
          <h2 className="mb-3 flex items-center gap-2 text-sm font-bold text-muted-foreground">
            <Hash className="h-4 w-4" aria-hidden /> {T.explore.hashtags}
          </h2>
          <TrendingHashtags onPick={openHashtag} />
        </div>
      )}

      {!searching && searched && total === 0 && (
        <EmptyState icon={<Search className="h-12 w-12" />} title={T.explore.empty} hint="عبارت دیگری را امتحان کنید" />
      )}

      {!searching && searched && (
        <div className="space-y-5 p-3">
          {result.users.length > 0 && (
            <section aria-label={T.explore.users}>
              <h2 className="mb-2 flex items-center gap-1.5 px-1 text-sm font-bold text-muted-foreground">
                <Users className="h-4 w-4" aria-hidden /> {T.explore.users}
              </h2>
              <div className="space-y-2">
                {result.users.map((u) => (
                  <div key={u.id} className="flex items-center gap-3 rounded-xl border bg-card p-3">
                    <button type="button" className="flex min-w-0 flex-1 items-center gap-3 text-right" onClick={() => navigate({ screen: 'profile', username: u.username })}>
                      <BayanAvatar name={u.name} src={u.avatarUrl} />
                      <div className="min-w-0">
                        <p className="truncate text-sm font-bold">{u.name}</p>
                        <p className="truncate text-xs text-muted-foreground" dir="ltr">@{u.username}</p>
                      </div>
                    </button>
                    <Button size="sm" variant="outline" className="min-h-9 shrink-0" onClick={() => follow(u.username)}>
                      <UserPlus className="h-4 w-4" aria-hidden />
                    </Button>
                  </div>
                ))}
              </div>
            </section>
          )}

          {result.hashtags.length > 0 && (
            <section aria-label={T.explore.hashtags}>
              <h2 className="mb-2 px-1 text-sm font-bold text-muted-foreground"># {T.explore.hashtags}</h2>
              <div className="flex flex-wrap gap-2">
                {result.hashtags.map((h) => (
                  <button
                    key={h.tag}
                    type="button"
                    onClick={() => openHashtag(h.tag)}
                    className="rounded-full border bg-card px-4 py-2 text-sm font-bold text-primary transition-colors hover:bg-accent"
                  >
                    #{h.tag}
                    <span className="mr-1.5 text-xs font-normal text-muted-foreground">({faCompact(h.postsCount)})</span>
                  </button>
                ))}
              </div>
            </section>
          )}

          {result.channels.length > 0 && (
            <section aria-label={T.explore.channelsTab}>
              <h2 className="mb-2 flex items-center gap-1.5 px-1 text-sm font-bold text-muted-foreground">
                <Megaphone className="h-4 w-4" aria-hidden /> {T.explore.channelsTab}
              </h2>
              <div className="space-y-2">
                {result.channels.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    className="flex w-full items-center gap-3 rounded-xl border bg-card p-3 text-right"
                    onClick={() => navigate({ screen: 'messages', conversationId: c.id })}
                  >
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                      <Megaphone className="h-5 w-5" aria-hidden />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-bold">{c.title}</p>
                      <p className="truncate text-xs text-muted-foreground">
                        {c.type === 'CHANNEL' ? 'کانال' : 'گروه'} · {faNum(c.membersCount)} {T.explore.membersCount}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            </section>
          )}

          {result.posts.length > 0 && (
            <section aria-label={T.explore.posts}>
              <h2 className="mb-2 flex items-center gap-1.5 px-1 text-sm font-bold text-muted-foreground">
                <FileText className="h-4 w-4" aria-hidden /> {T.explore.posts}
              </h2>
              <div className="space-y-2">
                {result.posts.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    className="w-full rounded-xl border bg-card p-3 text-right"
                    onClick={() => navigate({ screen: 'profile', username: p.author.username })}
                  >
                    <p className="line-clamp-3 text-sm leading-6">{p.content}</p>
                    <p className="mt-2 text-xs text-muted-foreground">
                      {p.author.name} · {timeAgoFa(p.createdAt)} · ❤ {faNum(p.likeCount)} · 💬 {faNum(p.commentCount)}
                    </p>
                  </button>
                ))}
              </div>
            </section>
          )}
        </div>
      )}
    </div>
  )
}

function faNum(n: number) {
  return String(n).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[Number(d)])
}

/** هشتگ‌های پرطرفدار */
function TrendingHashtags({ onPick }: { onPick: (tag: string) => void }) {
  const [tags, setTags] = useState<Array<{ tag: string; postsCount: number }>>([])

  useEffect(() => {
    fetch('/api/hashtags/trending')
      .then((r) => r.json())
      .then((d) => setTags(d.hashtags || []))
      .catch(() => setTags([]))
  }, [])

  if (tags.length === 0) return null
  return (
    <div className="flex flex-wrap gap-2">
      {tags.map((h) => (
        <button
          key={h.tag}
          type="button"
          onClick={() => onPick(h.tag)}
          className="rounded-full border bg-card px-4 py-2 text-sm font-bold text-primary transition-colors hover:bg-accent"
        >
          #{h.tag}
          <span className="mr-1.5 text-xs font-normal text-muted-foreground">({faCompact(h.postsCount)})</span>
        </button>
      ))}
    </div>
  )
}
