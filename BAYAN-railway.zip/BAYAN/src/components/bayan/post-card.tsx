'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { api } from '@/components/bayan/api'
import { BayanAvatar } from '@/components/bayan/ui-bits'
import { useBayan } from '@/components/bayan/store'
import { T } from '@/lib/i18n'
import { faCompact, timeAgoFa } from '@/lib/persian'
import { toast } from '@/hooks/use-toast'
import {
  Heart, MessageCircle, Bookmark, MoreHorizontal, Flag, Trash2, Send, ImagePlus, X, Loader2,
} from 'lucide-react'

// ============================================================
// BAYAN | بیان — کارت پست با تعامل کامل
// ============================================================

export interface PostData {
  id: string
  content: string
  mediaType: string
  mediaUrl: string | null
  status: string
  likeCount: number
  commentCount: number
  createdAt: string
  liked: boolean
  bookmarked: boolean
  author: { id: string; name: string; username: string; avatarUrl: string | null }
}

interface CommentData {
  id: string
  content: string
  parentId: string | null
  createdAt: string
  author: { id: string; name: string; username: string; avatarUrl: string | null }
}

export function PostCard({
  post,
  onChanged,
  highlightTag,
}: {
  post: PostData
  onChanged?: (p: PostData | null) => void
  highlightTag?: string
}) {
  const { me, navigate } = useBayan()
  const [data, setData] = useState(post)
  const [showComments, setShowComments] = useState(false)
  const [comments, setComments] = useState<CommentData[] | null>(null)
  const [commentText, setCommentText] = useState('')
  const [replyTo, setReplyTo] = useState<CommentData | null>(null)
  const [busy, setBusy] = useState(false)

  const update = (patch: Partial<PostData>) => {
    setData((d) => ({ ...d, ...patch }))
    onChanged?.({ ...data, ...patch })
  }

  async function toggleLike() {
    if (!me) return navigate({ screen: 'auth' })
    if (busy) return
    setBusy(true)
    // بهینه‌سازی خوش‌بینانه
    update({ liked: !data.liked, likeCount: data.likeCount + (data.liked ? -1 : 1) })
    try {
      const res = await api<{ liked: boolean; likeCount: number }>(`/posts/${data.id}/like`, { method: 'POST' })
      update({ liked: res.liked, likeCount: res.likeCount })
    } catch {
      update({ liked: data.liked, likeCount: data.likeCount })
    } finally {
      setBusy(false)
    }
  }

  async function toggleBookmark() {
    if (!me) return navigate({ screen: 'auth' })
    try {
      const res = await api<{ bookmarked: boolean }>(`/posts/${data.id}/bookmark`, { method: 'POST' })
      update({ bookmarked: res.bookmarked })
      if (res.bookmarked) toast({ description: T.post.saved })
    } catch (e) {
      toast({ description: e instanceof Error ? e.message : T.common.error, variant: 'destructive' })
    }
  }

  async function loadComments() {
    setShowComments((s) => !s)
    if (comments === null) {
      try {
        const res = await api<{ comments: CommentData[] }>(`/posts/${data.id}/comments`)
        setComments(res.comments)
      } catch {
        setComments([])
      }
    }
  }

  async function submitComment() {
    if (!me) return navigate({ screen: 'auth' })
    const text = commentText.trim()
    if (!text) return
    try {
      const res = await api<{ comment: CommentData }>(`/posts/${data.id}/comments`, {
        body: { content: text, parentId: replyTo?.id || undefined },
      })
      setComments((c) => [...(c || []), res.comment])
      setCommentText('')
      setReplyTo(null)
      update({ commentCount: data.commentCount + 1 })
    } catch (e) {
      toast({ description: e instanceof Error ? e.message : T.common.error, variant: 'destructive' })
    }
  }

  async function deletePost() {
    if (!confirm(T.post.delete + '؟')) return
    try {
      await api(`/posts/${data.id}`, { method: 'DELETE' })
      onChanged?.(null)
      toast({ description: T.post.deleted })
    } catch (e) {
      toast({ description: e instanceof Error ? e.message : T.common.error, variant: 'destructive' })
    }
  }

  async function reportPost(reason: string) {
    if (!me) return navigate({ screen: 'auth' })
    try {
      await api('/reports', { body: { targetType: 'POST', targetId: data.id, reason } })
      toast({ description: T.post.reported })
    } catch (e) {
      toast({ description: e instanceof Error ? e.message : T.common.error, variant: 'destructive' })
    }
  }

  function sharePost() {
    const url = `${location.origin}/?post=${data.id}`
    if (navigator.share) {
      navigator.share({ title: 'BAYAN | بیان', text: data.content.slice(0, 80), url }).catch(() => null)
    } else {
      navigator.clipboard.writeText(url).then(() => toast({ description: T.post.shareCopied }))
    }
  }

  function renderContent(content: string) {
    const parts = content.split(/(#[\w\u0600-\u06FF\u200c]+)/g)
    return parts.map((part, i) => {
      if (part.startsWith('#')) {
        const tag = part.slice(1)
        const isHi = highlightTag && tag.toLowerCase() === highlightTag.toLowerCase()
        return (
          <button
            key={i}
            type="button"
            className={`text-primary hover:underline font-semibold ${isHi ? 'bg-primary/10 rounded px-1' : ''}`}
            onClick={(e) => {
              e.stopPropagation()
              navigate({ screen: 'hashtag', tag })
            }}
          >
            {part}
          </button>
        )
      }
      return <span key={i}>{part}</span>
    })
  }

  const isMine = me?.id === data.author.id
  const rootComments = comments?.filter((c) => !c.parentId) || []
  const replies = comments?.filter((c) => c.parentId) || []

  return (
    <article
      className="rounded-2xl border bg-card p-4 transition-shadow hover:shadow-sm"
      aria-label={`پست ${data.author.name}`}
    >
      {/* سربرگ */}
      <div className="flex items-center gap-3">
        <button
          type="button"
          className="flex items-center gap-3 min-w-0 flex-1 text-right"
          onClick={() => navigate({ screen: 'profile', username: data.author.username })}
          aria-label={`پروفایل ${data.author.name}`}
        >
          <BayanAvatar name={data.author.name} src={data.author.avatarUrl} />
          <div className="min-w-0">
            <p className="truncate font-bold text-sm">{data.author.name}</p>
            <p className="truncate text-xs text-muted-foreground" dir="ltr">
              @{data.author.username} · {timeAgoFa(data.createdAt)}
            </p>
          </div>
        </button>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" aria-label="گزینه‌های بیشتر" className="shrink-0">
              <MoreHorizontal className="h-5 w-5" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            <DropdownMenuItem onClick={sharePost}>
              <Send className="ml-2 h-4 w-4" /> {T.post.share}
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => reportPost('SPAM')}>
              <Flag className="ml-2 h-4 w-4" /> {T.post.report}
            </DropdownMenuItem>
            {isMine && (
              <DropdownMenuItem onClick={deletePost} className="text-destructive focus:text-destructive">
                <Trash2 className="ml-2 h-4 w-4" /> {T.post.delete}
              </DropdownMenuItem>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* متن */}
      <div
        className="mt-3 block w-full cursor-pointer text-right"
        onClick={() => navigate({ screen: 'profile', username: data.author.username })}
      >
        <p className="whitespace-pre-wrap break-words text-[0.95rem] leading-7">{renderContent(data.content)}</p>
      </div>

      {/* تصویر */}
      {data.mediaUrl && (
        <button
          type="button"
          className="mt-3 block w-full overflow-hidden rounded-xl border"
          onClick={() => window.open(data.mediaUrl!, '_blank')}
          aria-label="مشاهده تصویر"
        >
          <img
            src={data.mediaUrl}
            alt="تصویر پیوست پست"
            className="max-h-[420px] w-full object-cover"
            loading="lazy"
          />
        </button>
      )}

      {/* اکشن‌ها */}
      <div className="mt-3 flex items-center gap-1 text-muted-foreground" role="toolbar" aria-label="عملیات پست">
        <button
          type="button"
          onClick={toggleLike}
          aria-pressed={data.liked}
          aria-label={`${T.post.like} (${data.likeCount})`}
          className={`flex min-h-11 items-center gap-1.5 rounded-lg px-2.5 text-sm transition-colors hover:bg-accent ${
            data.liked ? 'text-rose-500' : ''
          }`}
        >
          <Heart className={`h-5 w-5 ${data.liked ? 'fill-current' : ''}`} aria-hidden />
          <span className="tabular">{faCompact(data.likeCount)}</span>
        </button>

        <button
          type="button"
          onClick={loadComments}
          aria-expanded={showComments}
          aria-label={`${T.post.comment} (${data.commentCount})`}
          className="flex min-h-11 items-center gap-1.5 rounded-lg px-2.5 text-sm transition-colors hover:bg-accent"
        >
          <MessageCircle className="h-5 w-5" aria-hidden />
          <span className="tabular">{faCompact(data.commentCount)}</span>
        </button>

        <button
          type="button"
          onClick={toggleBookmark}
          aria-pressed={data.bookmarked}
          aria-label={T.post.save}
          className={`mr-auto flex min-h-11 items-center gap-1.5 rounded-lg px-2.5 text-sm transition-colors hover:bg-accent ${
            data.bookmarked ? 'text-primary' : ''
          }`}
        >
          <Bookmark className={`h-5 w-5 ${data.bookmarked ? 'fill-current' : ''}`} aria-hidden />
        </button>
      </div>

      {/* نظرات */}
      {showComments && (
        <div className="mt-2 border-t pt-3" aria-label={T.post.comments}>
          {comments === null ? (
            <p className="py-2 text-center text-xs text-muted-foreground">{T.common.loading}</p>
          ) : (
            <div className="space-y-3">
              {rootComments.length === 0 && <p className="py-1 text-center text-xs text-muted-foreground">اولین نظر را شما بنویسید</p>}
              {rootComments.map((c) => (
                <div key={c.id} className="space-y-2">
                  <CommentRow
                    comment={c}
                    onReply={() => setReplyTo(c)}
                    canDelete={me?.id === c.author.id || isMine}
                    onDelete={async () => {
                      await api(`/comments/${c.id}`, { method: 'DELETE' }).catch(() => null)
                      setComments((cs) => (cs || []).filter((x) => x.id !== c.id && x.parentId !== c.id))
                      update({ commentCount: Math.max(0, data.commentCount - 1) })
                    }}
                  />
                  {replies
                    .filter((r) => r.parentId === c.id)
                    .map((r) => (
                      <div key={r.id} className="mr-6">
                        <CommentRow
                          comment={r}
                          onReply={() => setReplyTo(c)}
                          canDelete={me?.id === r.author.id || isMine}
                          onDelete={async () => {
                            await api(`/comments/${r.id}`, { method: 'DELETE' }).catch(() => null)
                            setComments((cs) => (cs || []).filter((x) => x.id !== r.id))
                            update({ commentCount: Math.max(0, data.commentCount - 1) })
                          }}
                        />
                      </div>
                    ))}
                </div>
              ))}

              <div className="flex items-center gap-2 pt-1">
                <Input
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder={replyTo ? `پاسخ به ${replyTo.author.name}…` : T.post.addComment}
                  className="h-10 text-sm"
                  aria-label={T.post.addComment}
                  onKeyDown={(e) => e.key === 'Enter' && submitComment()}
                />
                <Button size="icon" className="h-10 w-10 shrink-0" onClick={submitComment} aria-label={T.chat.send}>
                  <Send className="h-4 w-4" />
                </Button>
                {replyTo && (
                  <Button size="sm" variant="ghost" onClick={() => setReplyTo(null)} aria-label={T.common.cancel}>
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </article>
  )
}

function CommentRow({
  comment,
  onReply,
  canDelete,
  onDelete,
}: {
  comment: CommentData
  onReply: () => void
  canDelete: boolean
  onDelete: () => void
}) {
  return (
    <div className="flex gap-2">
      <BayanAvatar name={comment.author.name} src={comment.author.avatarUrl} size="sm" />
      <div className="min-w-0 flex-1 rounded-xl bg-muted/60 px-3 py-2">
        <div className="flex items-center gap-2">
          <button
            type="button"
            className="truncate text-xs font-bold hover:underline"
            onClick={() => useBayan.getState().navigate({ screen: 'profile', username: comment.author.username })}
          >
            {comment.author.name}
          </button>
          <span className="text-[0.65rem] text-muted-foreground">{timeAgoFa(comment.createdAt)}</span>
        </div>
        <p className="mt-0.5 break-words text-sm leading-6">{comment.content}</p>
        <div className="mt-1 flex gap-3 text-[0.7rem] text-muted-foreground">
          <button type="button" className="hover:text-foreground" onClick={onReply}>
            {T.post.reply}
          </button>
          {canDelete && (
            <button type="button" className="text-destructive/80 hover:text-destructive" onClick={onDelete}>
              {T.post.delete}
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

/** سازنده پست (شیت پایین صفحه) */
export function Composer({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { navigate } = useBayan()
  const [content, setContent] = useState('')
  const [mediaUrl, setMediaUrl] = useState<string | null>(null)
  const [mediaId, setMediaId] = useState<string | null>(null)
  const [uploading, setUploading] = useState(false)
  const [busy, setBusy] = useState(false)

  if (!open) return null

  async function pickImage(file: File) {
    setUploading(true)
    try {
      const fd = new FormData()
      fd.append('file', file)
      const res = await api<{ url: string; mediaId: string }>('/upload', { formData: fd })
      setMediaUrl(res.url)
      setMediaId(res.mediaId)
    } catch (e) {
      toast({ description: e instanceof Error ? e.message : T.common.error, variant: 'destructive' })
    } finally {
      setUploading(false)
    }
  }

  async function submit(status: 'PUBLISHED' | 'DRAFT') {
    const text = content.trim()
    if (!text && !mediaId) return
    setBusy(true)
    try {
      await api('/posts', { body: { content: text, mediaType: mediaId ? 'IMAGE' : 'TEXT', mediaId, status } })
      setContent('')
      setMediaUrl(null)
      setMediaId(null)
      onClose()
      toast({ description: status === 'PUBLISHED' ? T.post.published : T.post.draftSaved })
      navigate({ screen: 'home' })
      window.dispatchEvent(new Event('bayan:feed-refresh'))
    } catch (e) {
      toast({ description: e instanceof Error ? e.message : T.common.error, variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 sm:items-center" onClick={onClose} role="dialog" aria-modal="true" aria-label={T.post.createPost}>
      <div
        className="w-full max-w-lg rounded-t-2xl bg-card p-4 pb-8 shadow-xl sm:rounded-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-bold">{T.post.createPost}</h2>
          <Button variant="ghost" size="icon" onClick={onClose} aria-label={T.common.close}>
            <X className="h-5 w-5" />
          </Button>
        </div>

        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder={T.post.placeholder}
          rows={4}
          maxLength={5000}
          className="w-full resize-none rounded-xl border bg-transparent p-3 text-[0.95rem] leading-7 outline-none placeholder:text-muted-foreground/60 focus:ring-1 focus:ring-ring"
          aria-label={T.post.placeholder}
        />

        {mediaUrl && (
          <div className="relative mt-2">
            <img src={mediaUrl} alt="پیش‌نمایش تصویر" className="max-h-48 rounded-xl object-cover" />
            <Button
              size="icon" variant="secondary"
              className="absolute right-2 top-2 h-8 w-8 rounded-full"
              onClick={() => { setMediaUrl(null); setMediaId(null) }}
              aria-label="حذف تصویر"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        )}

        <div className="mt-3 flex items-center gap-2">
          <label className="flex min-h-11 cursor-pointer items-center gap-1.5 rounded-lg px-3 text-sm text-muted-foreground hover:bg-accent">
            {uploading ? <LoaderIcon /> : <ImagePlus className="h-5 w-5" aria-hidden />}
            {T.post.addImage}
            <input
              type="file" accept="image/jpeg,image/png,image/webp,image/gif" className="sr-only"
              onChange={(e) => e.target.files?.[0] && pickImage(e.target.files[0])}
              aria-label={T.post.addImage}
            />
          </label>
          <div className="mr-auto flex gap-2">
            <Button variant="outline" className="min-h-11" disabled={busy} onClick={() => submit('DRAFT')}>
              {T.post.draft}
            </Button>
            <Button className="min-h-11 px-6 font-bold" disabled={busy || (!content.trim() && !mediaId)} onClick={() => submit('PUBLISHED')}>
              {busy ? <LoaderIcon /> : T.post.publish}
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

function LoaderIcon() {
  return <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
}
