'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { api } from '@/components/bayan/api'
import { EmptyState, LoadingBlock, ScreenHeader } from '@/components/bayan/ui-bits'
import { MapScreen, loadLeaflet, type BusinessData } from '@/components/bayan/map-screen'
import { useBayan } from '@/components/bayan/store'
import { T } from '@/lib/i18n'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { toast } from '@/hooks/use-toast'
import { Loader2, MapPin, Phone, Plus, Search, Store } from 'lucide-react'

// ============================================================
// BAYAN | بیان — کسب‌وکارها: فهرست + ثبت کسب‌وکار روی نقشه
// ============================================================

const CATEGORIES = [
  'فروشگاه', 'نانوایی', 'رستوران', 'پزشک', 'داروخانه', 'هتل',
  'مدرسه', 'دانشگاه', 'تعمیرگاه', 'شرکت', 'کارخانه', 'خدمات منزل',
  'گردشگری', 'حمل‌ونقل', 'مراکز عمومی', 'سایر',
]

export function BusinessScreen() {
  const { goBack, me } = useBayan()
  const [businesses, setBusinesses] = useState<BusinessData[]>([])
  const [q, setQ] = useState('')
  const [loading, setLoading] = useState(true)
  const [showMap, setShowMap] = useState(false)
  const [showRegister, setShowRegister] = useState(false)

  const load = useCallback(async () => {
    try {
      const res = await api<{ businesses: BusinessData[] }>(`/businesses${q.trim() ? `?q=${encodeURIComponent(q.trim())}` : ''}`)
      setBusinesses(res.businesses)
    } catch {
      setBusinesses([])
    } finally {
      setLoading(false)
    }
  }, [q])

  useEffect(() => {
    const t = setTimeout(load, 300)
    return () => clearTimeout(t)
  }, [load])

  if (showMap) {
    return <MapScreen onBack={() => { setShowMap(false); load() }} />
  }

  return (
    <div>
      <ScreenHeader
        title={T.business.title}
        onBack={goBack}
        action={
          me && (
            <Button size="sm" className="min-h-10 px-3" onClick={() => setShowRegister(true)}>
              <Plus className="h-4 w-4" aria-hidden /> {T.business.registerBusiness}
            </Button>
          )
        }
      />

      <div className="sticky top-14 z-20 border-b bg-background/90 p-2.5 backdrop-blur-md">
        <div className="relative">
          <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={T.map.searchMap}
            className="min-h-11 bg-muted/50 pr-9"
            type="search"
            aria-label={T.business.title}
          />
        </div>
      </div>

      {/* ورود به نقشه */}
      <button
        type="button"
        onClick={() => setShowMap(true)}
        className="mx-4 mt-3 flex w-[calc(100%-2rem)] items-center gap-3 rounded-2xl border border-primary/25 bg-primary/5 p-4 text-right"
      >
        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground">
          <MapPin className="h-6 w-6" aria-hidden />
        </div>
        <div className="min-w-0 flex-1">
          <p className="font-bold text-primary">{T.map.title}</p>
          <p className="text-xs text-muted-foreground">مشاهده همه کسب‌وکارها روی نقشه + مسیریابی</p>
        </div>
      </button>

      {loading ? (
        <LoadingBlock />
      ) : businesses.length === 0 ? (
        <EmptyState icon={<Store className="h-12 w-12" />} title={T.map.noBusinesses} hint="اولین کسب‌وکار را ثبت کنید" />
      ) : (
        <div className="mx-auto max-w-2xl space-y-2.5 p-4">
          {businesses.map((b) => (
            <div key={b.id} className="rounded-2xl border bg-card p-4">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="flex items-center gap-1.5 font-black">
                    {b.name}
                    {b.isVerified && <span className="rounded bg-primary/10 px-1.5 py-0.5 text-[0.6rem] font-bold text-primary">{T.business.verified}</span>}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {b.category} {b.city && `· ${b.city}`}
                  </p>
                </div>
                {b.phone && (
                  <a
                    href={`tel:${b.phone}`}
                    className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary"
                    aria-label={`${T.business.call} ${b.name}`}
                  >
                    <Phone className="h-4 w-4" aria-hidden />
                  </a>
                )}
              </div>
              {b.description && <p className="mt-1.5 text-sm leading-6">{b.description}</p>}
              {b.address && <p className="mt-1.5 text-xs text-muted-foreground">📍 {b.address}</p>}
              {b.hours && <p className="mt-1 text-xs text-muted-foreground">🕘 {b.hours}</p>}
            </div>
          ))}
        </div>
      )}

      {showRegister && (
        <RegisterBusiness
          onClose={() => setShowRegister(false)}
          onDone={() => { setShowRegister(false); load() }}
        />
      )}
    </div>
  )
}

// ============================================================
// ثبت کسب‌وکار + انتخاب موقعیت روی نقشه کوچک
// ============================================================

function RegisterBusiness({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const { me } = useBayan()
  const [form, setForm] = useState({
    name: '', category: 'فروشگاه', description: '', phone: '', address: '', city: '', hours: '',
    lat: 30.4394, lng: 48.2666,
  })
  const [busy, setBusy] = useState(false)
  const [picking, setPicking] = useState(false)

  const set = (k: string, v: string | number) => setForm((f) => ({ ...f, [k]: v }))

  async function submit() {
    setBusy(true)
    try {
      await api('/businesses', { body: form })
      toast({ description: T.business.registered })
      onDone()
    } catch (e) {
      toast({ description: e instanceof Error ? e.message : T.common.error, variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  if (picking) {
    return (
      <div className="fixed inset-0 z-50 flex flex-col bg-background" role="dialog" aria-modal="true" aria-label={T.business.selectOnMap}>
        <PickLocationMap
          initial={[form.lat, form.lng]}
          onPick={(lat, lng) => {
            set('lat', lat)
            set('lng', lng)
            setPicking(false)
          }}
        />
        <p className="border-t p-2.5 text-center text-xs text-muted-foreground">
          موقعیت انتخابی: <span className="tabular" dir="ltr">{form.lat.toFixed(5)}, {form.lng.toFixed(5)}</span>
        </p>
      </div>
    )
  }

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/40 p-4" onClick={onClose} role="dialog" aria-modal="true">
      <div className="mx-auto my-4 w-full max-w-md rounded-2xl bg-card p-5" onClick={(e) => e.stopPropagation()}>
        <h2 className="mb-1 font-bold">{T.business.registerBusiness}</h2>
        <p className="mb-4 text-xs text-muted-foreground">{T.business.hint}</p>

        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="bname">{T.business.name}</Label>
            <Input id="bname" value={form.name} onChange={(e) => set('name', e.target.value)} maxLength={80} />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="bcat">{T.business.category}</Label>
            <select
              id="bcat"
              value={form.category}
              onChange={(e) => set('category', e.target.value)}
              className="min-h-11 w-full rounded-xl border bg-transparent px-3 text-sm"
            >
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1.5">
              <Label htmlFor="bphone">{T.business.phone}</Label>
              <Input id="bphone" dir="ltr" className="text-left" value={form.phone} onChange={(e) => set('phone', e.target.value)} inputMode="tel" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="bcity">{T.business.city}</Label>
              <Input id="bcity" value={form.city} onChange={(e) => set('city', e.target.value)} />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="baddr">{T.business.address}</Label>
            <Input id="baddr" value={form.address} onChange={(e) => set('address', e.target.value)} />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="bhours">{T.business.hours}</Label>
            <Input id="bhours" value={form.hours} onChange={(e) => set('hours', e.target.value)} placeholder="۸ تا ۲۱" />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="bdesc">معرفی</Label>
            <textarea
              id="bdesc"
              value={form.description}
              onChange={(e) => set('description', e.target.value)}
              rows={2}
              maxLength={1000}
              className="w-full resize-none rounded-xl border bg-transparent p-3 text-sm outline-none focus:ring-1 focus:ring-ring"
            />
          </div>

          {/* موقعیت */}
          <button
            type="button"
            onClick={() => setPicking(true)}
            className="flex min-h-14 w-full items-center gap-2.5 rounded-xl border border-dashed border-primary/40 bg-primary/5 p-3 text-sm font-bold text-primary"
          >
            <MapPin className="h-5 w-5" aria-hidden />
            <span className="flex-1 text-right">{T.business.selectOnMap}</span>
            <span className="tabular text-xs" dir="ltr">{form.lat.toFixed(3)}, {form.lng.toFixed(3)}</span>
          </button>

          <div className="flex gap-2 pt-1">
            <Button variant="outline" className="flex-1 min-h-11" onClick={onClose}>{T.common.cancel}</Button>
            <Button className="flex-1 min-h-11 font-bold" disabled={busy || form.name.trim().length < 2} onClick={submit}>
              {busy ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : T.business.submit}
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

function PickLocationMap({ initial, onPick }: { initial: [number, number]; onPick: (lat: number, lng: number) => void }) {
  const containerRef = useRef<HTMLDivElement>(null)
  const mapRef = useRef<import('leaflet').Map | null>(null)
  const markerRef = useRef<import('leaflet').Marker | null>(null)
  const [ready, setReady] = useState(false)

  useEffect(() => {
    loadLeaflet().then(() => setReady(true))
  }, [])

  useEffect(() => {
    if (!ready || !containerRef.current || mapRef.current) return
    let map: import('leaflet').Map | null = null
    let cancelled = false

    loadLeaflet().then((L) => {
      if (cancelled || !containerRef.current || mapRef.current) return
      map = L.map(containerRef.current, { center: initial, zoom: 13 })
      L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OpenStreetMap' }).addTo(map)
      const marker = L.marker(initial, { draggable: true }).addTo(map)
      markerRef.current = marker
      mapRef.current = map

      map.on('click', (e: import('leaflet').LeafletMouseEvent) => {
        marker.setLatLng(e.latlng)
      })
    })
    return () => {
      cancelled = true
      map?.remove()
      mapRef.current = null
    }
  }, [ready])

  return (
    <div className="relative flex-1">
      <div ref={containerRef} className="h-full w-full" />
      <button
        type="button"
        onClick={() => {
          const ll = markerRef.current?.getLatLng()
          if (ll) onPick(ll.lat, ll.lng)
        }}
        className="absolute bottom-5 left-1/2 z-10 -translate-x-1/2 rounded-xl bg-primary px-8 py-3 font-bold text-primary-foreground shadow-lg"
      >
        تأیید این موقعیت
      </button>
    </div>
  )
}
