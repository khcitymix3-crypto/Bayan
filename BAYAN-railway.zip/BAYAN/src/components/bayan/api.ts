'use client'

// ============================================================
// BAYAN | بیان — کلاینت API (سمت مرورگر)
// ============================================================

export class ApiError extends Error {
  status: number
  constructor(message: string, status: number) {
    super(message)
    this.status = status
  }
}

export async function api<T = unknown>(
  path: string,
  options: { method?: string; body?: unknown; formData?: FormData } = {}
): Promise<T> {
  const init: RequestInit = {
    method: options.method || (options.body || options.formData ? 'POST' : 'GET'),
    credentials: 'same-origin',
  }

  if (options.formData) {
    init.body = options.formData
  } else if (options.body !== undefined) {
    init.headers = { 'Content-Type': 'application/json' }
    init.body = JSON.stringify(options.body)
  }

  const res = await fetch(`/api${path}`, init)
  let data: Record<string, unknown> = {}
  try {
    data = await res.json()
  } catch {
    // پاسخ غیر JSON
  }

  if (!res.ok) {
    throw new ApiError(String(data.error || 'خطای ارتباط با سرور'), res.status)
  }
  return data as T
}
