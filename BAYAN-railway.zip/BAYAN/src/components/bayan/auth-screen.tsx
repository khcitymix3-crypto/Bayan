'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { api } from '@/components/bayan/api'
import { useBayan, type Me } from '@/components/bayan/store'
import { T } from '@/lib/i18n'
import { faNum } from '@/lib/persian'
import { Loader2, ShieldCheck, Sparkles } from 'lucide-react'

// ============================================================
// BAYAN | بیان — صفحه ورود و ثبت‌نام (دو مرحله‌ای با OTP)
// ============================================================

type Mode = 'login' | 'register'
type Step = 'form' | 'otp'

export function AuthScreen() {
  const { setMe, navigate } = useBayan()
  const [mode, setMode] = useState<Mode>('login')
  const [step, setStep] = useState<Step>('form')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [demoCode, setDemoCode] = useState('')

  const [form, setForm] = useState({ name: '', username: '', phone: '', password: '', otp: '' })

  const set = (key: string, value: string) => setForm((f) => ({ ...f, [key]: value }))

  async function submitForm() {
    setError('')
    setBusy(true)
    try {
      if (mode === 'login') {
        const data = await api<{ user: Me }>('/auth/login', { body: { phone: form.phone, password: form.password } })
        setMe(data.user)
        navigate({ screen: 'home' })
      } else {
        // مرحله ۱: صدور کد
        const data = await api<{ demoCode: string }>('/auth/otp', { body: { phone: form.phone } })
        setDemoCode(data.demoCode)
        setStep('otp')
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : T.common.error)
    } finally {
      setBusy(false)
    }
  }

  async function submitRegister() {
    setError('')
    setBusy(true)
    try {
      const data = await api<{ user: Me }>('/auth/register', {
        body: {
          name: form.name,
          username: form.username,
          phone: form.phone,
          password: form.password,
          otpCode: form.otp,
        },
      })
      setMe(data.user)
      navigate({ screen: 'home' })
    } catch (e) {
      setError(e instanceof Error ? e.message : T.common.error)
    } finally {
      setBusy(false)
    }
  }

  const canSubmitLogin = form.phone.trim().length >= 10 && form.password.length >= 8
  const canRequestOtp = form.name.trim().length >= 2 && form.username.trim().length >= 3 && form.phone.trim().length >= 10 && form.password.length >= 8

  return (
    <main className="min-h-dvh flex flex-col items-center justify-center px-4 py-8 bg-gradient-to-b from-secondary/60 to-background">
      {/* برند */}
      <div className="mb-8 text-center select-none" aria-hidden>
        <div className="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-lg">
          <Sparkles className="h-8 w-8" />
        </div>
        <h1 className="text-2xl font-black tracking-tight">{T.brand}</h1>
        <p className="mt-1 text-sm text-muted-foreground">{T.tagline}</p>
      </div>

      <section
        className="w-full max-w-sm rounded-2xl border bg-card p-6 shadow-sm"
        aria-label={mode === 'login' ? T.auth.loginTitle : T.auth.registerTitle}
      >
        <h2 className="mb-4 text-lg font-bold">
          {mode === 'login' ? T.auth.loginTitle : step === 'form' ? T.auth.registerTitle : T.auth.step2}
        </h2>

        {error && (
          <div role="alert" className="mb-4 rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">
            {error}
          </div>
        )}

        {mode === 'login' && (
          <form
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault()
              submitForm()
            }}
          >
            <div className="space-y-1.5">
              <Label htmlFor="phone">{T.auth.phone}</Label>
              <Input
                id="phone" inputMode="tel" dir="ltr" className="text-left"
                placeholder={T.auth.phoneHint} value={form.phone}
                onChange={(e) => set('phone', e.target.value)} autoComplete="tel" required
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="password">{T.auth.password}</Label>
              <Input
                id="password" type="password" dir="ltr" className="text-left"
                value={form.password} onChange={(e) => set('password', e.target.value)}
                autoComplete="current-password" required
              />
            </div>
            <Button type="submit" className="w-full min-h-11 text-base font-bold" disabled={busy || !canSubmitLogin}>
              {busy ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : T.auth.login}
            </Button>
          </form>
        )}

        {mode === 'register' && step === 'form' && (
          <form
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault()
              submitForm()
            }}
          >
            <div className="space-y-1.5">
              <Label htmlFor="name">{T.auth.name}</Label>
              <Input id="name" value={form.name} onChange={(e) => set('name', e.target.value)} autoComplete="name" required />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="username">{T.auth.username}</Label>
              <Input
                id="username" dir="ltr" className="text-left" placeholder={T.auth.usernameHint}
                value={form.username} onChange={(e) => set('username', e.target.value.replace(/[^a-zA-Z0-9_]/g, ''))}
                autoComplete="username" required
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="rphone">{T.auth.phone}</Label>
              <Input
                id="rphone" inputMode="tel" dir="ltr" className="text-left"
                placeholder={T.auth.phoneHint} value={form.phone}
                onChange={(e) => set('phone', e.target.value)} autoComplete="tel" required
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="rpassword">{T.auth.password}</Label>
              <Input
                id="rpassword" type="password" dir="ltr" className="text-left"
                value={form.password} onChange={(e) => set('password', e.target.value)}
                autoComplete="new-password" required minLength={8}
              />
            </div>
            <Button type="submit" className="w-full min-h-11 text-base font-bold" disabled={busy || !canRequestOtp}>
              {busy ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : T.auth.sendOtp}
            </Button>
          </form>
        )}

        {mode === 'register' && step === 'otp' && (
          <form
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault()
              submitRegister()
            }}
          >
            <p className="text-sm text-muted-foreground">
              کد تأیید به شماره <span className="font-bold tabular" dir="ltr">{faNum(form.phone)}</span> ارسال شد.
            </p>
            {demoCode && (
              <div className="rounded-lg border border-dashed border-primary/40 bg-primary/5 px-3 py-2 text-center" role="status">
                <p className="text-xs text-muted-foreground">{T.auth.demoOtp}</p>
                <p className="text-xl font-black tabular tracking-[0.4em] text-primary" dir="ltr">{faNum(demoCode)}</p>
              </div>
            )}
            <div className="space-y-1.5">
              <Label htmlFor="otp">{T.auth.otpCode}</Label>
              <Input
                id="otp" inputMode="numeric" dir="ltr" className="text-center text-lg tracking-[0.5em] tabular"
                maxLength={6} value={form.otp} onChange={(e) => set('otp', e.target.value.replace(/\D/g, ''))}
                required
              />
            </div>
            <Button type="submit" className="w-full min-h-11 text-base font-bold" disabled={busy || form.otp.length !== 6}>
              {busy ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : T.auth.register}
            </Button>
            <Button type="button" variant="ghost" className="w-full" onClick={() => setStep('form')}>
              {T.common.cancel}
            </Button>
          </form>
        )}

        <div className="mt-5 border-t pt-4 text-center">
          <button
            type="button"
            className="text-sm font-semibold text-primary hover:underline"
            onClick={() => {
              setMode(mode === 'login' ? 'register' : 'login')
              setStep('form')
              setError('')
              setDemoCode('')
            }}
          >
            {mode === 'login' ? T.auth.noAccount : T.auth.hasAccount}
          </button>
        </div>
      </section>

      <p className="mt-6 flex max-w-xs items-center justify-center gap-1.5 text-center text-xs text-muted-foreground">
        <ShieldCheck className="h-4 w-4 shrink-0" aria-hidden />
        رمزها با الگوریتم scrypt هش می‌شوند و شماره موبایل شما هرگز عمومی نمی‌شود
      </p>
    </main>
  )
}
