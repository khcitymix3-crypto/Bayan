'use client'

import { useEffect, useRef, useState } from 'react'
import { ScreenHeader } from '@/components/bayan/ui-bits'
import { useBayan } from '@/components/bayan/store'
import { T } from '@/lib/i18n'
import { faNum } from '@/lib/persian'
import { toast } from '@/hooks/use-toast'
import { AlertTriangle, MapPin, Phone, ShieldAlert, UserCheck, X } from 'lucide-react'

// ============================================================
// BAYAN | بیان — BAYAN SOS | کمک فوری
// شمارش معکوس ۵ ثانیه‌ای برای جلوگیری از تماس اشتباهی + لغو
// بیان جایگزین سازمان‌های امدادی نیست؛ فقط دسترسی را آسان می‌کند
// ============================================================

export function SosScreen() {
  const { goBack, me } = useBayan()
  const [countdown, setCountdown] = useState<number | null>(null)
  const [locating, setLocating] = useState(false)
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null)
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const holdRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current)
      if (holdRef.current) clearTimeout(holdRef.current)
    }
  }, [])

  function startCountdown() {
    if (countdown !== null) return
    let n = 5
    setCountdown(n)
    timerRef.current = setInterval(() => {
      n -= 1
      if (n <= 0) {
        if (timerRef.current) clearInterval(timerRef.current)
        setCountdown(null)
        // در نسخه نصب‌شده اندروید، tel: بازکننده تماس رسمی گوشی است
        window.location.href = 'tel:115'
        toast({ description: 'اتصال به اورژانس ۱۱۵ — در صورت نیاز لغو کنید', duration: 6000 })
      } else {
        setCountdown(n)
      }
    }, 1000)
  }

  function cancel() {
    if (timerRef.current) clearInterval(timerRef.current)
    if (holdRef.current) clearTimeout(holdRef.current)
    setCountdown(null)
  }

  function callNumber(number: string) {
    let n = 3
    setCountdown(n)
    timerRef.current = setInterval(() => {
      n -= 1
      if (n <= 0) {
        if (timerRef.current) clearInterval(timerRef.current)
        setCountdown(null)
        window.location.href = `tel:${number}`
      } else {
        setCountdown(n)
      }
    }, 1000)
  }

  function shareLocation() {
    if (!navigator.geolocation) {
      toast({ description: 'دسترسی به موقعیت در این دستگاه ممکن نیست', variant: 'destructive' })
      return
    }
    setLocating(true)
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords
        setLocation({ lat: latitude, lng: longitude })
        setLocating(false)
        const mapsUrl = `https://www.openstreetmap.org/?mlat=${latitude}&mlon=${longitude}#map=17/${latitude}/${longitude}`
        const text = `موقعیت من در بیان SOS: ${mapsUrl}`
        if (navigator.share) {
          navigator.share({ title: 'BAYAN SOS | موقعیت من', text }).catch(() => null)
        } else {
          navigator.clipboard.writeText(text).then(() => toast({ description: T.sos.locationShared }))
        }
      },
      () => {
        setLocating(false)
        toast({ description: T.map.locationPermission, variant: 'destructive' })
      },
      { enableHighAccuracy: true, timeout: 10000 }
    )
  }

  return (
    <div>
      <ScreenHeader title={T.sos.title} onBack={goBack} />

      <div className="mx-auto max-w-2xl space-y-5 p-4 pb-24">
        {/* هشدار قانونی */}
        <p className="flex items-start gap-2 rounded-xl bg-amber-500/10 p-3 text-xs leading-6 text-amber-700 dark:text-amber-400">
          <AlertTriangle className="h-4 w-4 shrink-0" aria-hidden />
          {T.sos.disclaimer}
        </p>

        {/* دکمه اضطراری بزرگ */}
        <div className="flex flex-col items-center py-4">
          {countdown === null ? (
            <button
              type="button"
              onPointerDown={() => {
                holdRef.current = setTimeout(startCountdown, 350)
              }}
              onPointerUp={cancel}
              onPointerLeave={cancel}
              className="flex h-44 w-44 select-none flex-col items-center justify-center gap-2 rounded-full bg-gradient-to-b from-red-500 to-red-700 text-white shadow-xl shadow-red-500/30 transition-transform active:scale-95"
              aria-label={T.sos.emergency}
            >
              <ShieldAlert className="h-12 w-12" aria-hidden />
              <span className="px-6 text-center text-sm font-black leading-6">{T.sos.emergency}</span>
              <span className="text-[0.65rem] opacity-80">{T.sos.holdToStart}</span>
            </button>
          ) : (
            <div className="flex flex-col items-center gap-4" role="alert" aria-live="assertive">
              <div className="flex h-44 w-44 items-center justify-center rounded-full border-8 border-red-500 bg-red-500/10">
                <p className="text-7xl font-black tabular text-red-600">{faNum(countdown)}</p>
              </div>
              <p className="font-bold">{T.sos.callingIn} {faNum(countdown)} ثانیه…</p>
              <button
                type="button"
                onClick={cancel}
                className="flex min-h-14 items-center gap-2 rounded-full bg-foreground px-8 text-base font-black text-background"
              >
                <X className="h-5 w-5" aria-hidden /> {T.sos.cancel}
              </button>
            </div>
          )}
        </div>

        {/* اقدامات سریع */}
        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={shareLocation}
            className="flex min-h-20 flex-col items-center justify-center gap-1.5 rounded-2xl border bg-card p-3 text-sm font-bold transition-colors hover:bg-accent"
          >
            <MapPin className={`h-6 w-6 text-primary ${locating ? 'animate-pulse' : ''}`} aria-hidden />
            {T.sos.shareLocation}
          </button>

          {me?.trustedPhone ? (
            <a
              href={`tel:${me.trustedPhone}`}
              className="flex min-h-20 flex-col items-center justify-center gap-1.5 rounded-2xl border bg-card p-3 text-sm font-bold transition-colors hover:bg-accent"
            >
              <UserCheck className="h-6 w-6 text-primary" aria-hidden />
              {T.sos.trusted}
              <span className="text-[0.65rem] font-normal text-muted-foreground">{me.trustedName || me.trustedPhone}</span>
            </a>
          ) : (
            <button
              type="button"
              onClick={() => toast({ description: 'از تنظیمات ← یار بیان، فرد مورد اعتماد را تعیین کنید' })}
              className="flex min-h-20 flex-col items-center justify-center gap-1.5 rounded-2xl border border-dashed bg-card p-3 text-sm font-bold text-muted-foreground"
            >
              <UserCheck className="h-6 w-6" aria-hidden />
              {T.sos.setTrusted}
            </button>
          )}
        </div>

        {/* موقعیت اشتراک‌گذاری‌شده */}
        {location && (
          <p className="rounded-xl bg-muted p-3 text-xs tabular" dir="ltr">
            {T.sos.locationShared} {location.lat.toFixed(5)}, {location.lng.toFixed(5)}
          </p>
        )}

        {/* شماره‌های رسمی */}
        <section aria-label={T.sos.numbers}>
          <h2 className="mb-2.5 font-black">{T.sos.numbers}</h2>
          <div className="grid grid-cols-2 gap-2.5">
            {T.sos.iranNumbers.map((n) => (
              <button
                key={n.number}
                type="button"
                onClick={() => callNumber(n.number)}
                className="flex items-center gap-2.5 rounded-xl border bg-card p-3 text-right transition-colors hover:bg-accent"
              >
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-red-500/10 text-red-600">
                  <Phone className="h-5 w-5" aria-hidden />
                </span>
                <span className="min-w-0">
                  <span className="block truncate text-xs text-muted-foreground">{n.name}</span>
                  <span className="block text-lg font-black tabular" dir="ltr">{faNum(n.number)}</span>
                </span>
              </button>
            ))}
          </div>
        </section>
      </div>
    </div>
  )
}
