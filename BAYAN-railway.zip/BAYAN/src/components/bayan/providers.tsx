'use client'

import { ThemeProvider } from 'next-themes'
import type { ReactNode } from 'react'

// ============================================================
// BAYAN | بیان — Providers: پوسته روشن/تاریک/خودکار
// ============================================================

export function Providers({ children }: { children: ReactNode }) {
  return (
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
      {children}
    </ThemeProvider>
  )
}
