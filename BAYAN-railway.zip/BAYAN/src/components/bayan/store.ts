'use client'

import { create } from 'zustand'

// ============================================================
// BAYAN | بیان — استور کلاینت (ناوبری SPA + کاربر جاری + تنظیمات)
// ============================================================

export type Screen =
  | 'home' | 'explore' | 'messages' | 'chat' | 'profile' | 'notifications'
  | 'map' | 'business' | 'ai' | 'sos' | 'settings' | 'admin' | 'auth' | 'hashtag'

export interface View {
  screen: Screen
  username?: string
  conversationId?: string
  tag?: string
}

export interface Me {
  id: string
  name: string
  username: string
  bio: string
  avatarUrl: string | null
  role: string
  phone: string
  isPhoneVerified: boolean
  trustedName: string
  trustedPhone: string
  privacyProfile: string
  privacyMessage: string
  fontScale: number
  highContrast: boolean
  createdAt: string
}

interface BayanState {
  ready: boolean
  me: Me | null
  unread: number
  view: View
  prevView: View | null
  composerOpen: boolean
  moreOpen: boolean
  setMe: (me: Me | null, unread?: number) => void
  patchMe: (patch: Partial<Me>) => void
  setUnread: (n: number) => void
  navigate: (view: View) => void
  goBack: () => void
  setComposerOpen: (open: boolean) => void
  setMoreOpen: (open: boolean) => void
}

export const useBayan = create<BayanState>((set) => ({
  ready: false,
  me: null,
  unread: 0,
  view: { screen: 'home' },
  prevView: null,
  composerOpen: false,
  moreOpen: false,
  setMe: (me, unread = 0) => set({ me, unread, ready: true }),
  patchMe: (patch) => set((s) => (s.me ? { me: { ...s.me, ...patch } } : {})),
  setUnread: (unread) => set({ unread }),
  navigate: (view) => set((s) => ({ prevView: s.view, view, moreOpen: false, composerOpen: false })),
  goBack: () => set((s) => ({ view: s.prevView || { screen: 'home' }, prevView: null, moreOpen: false })),
  setComposerOpen: (composerOpen) => set({ composerOpen }),
  setMoreOpen: (moreOpen) => set({ moreOpen }),
}))

/** بازیابی کاربر جاری هنگام شروع برنامه */
export async function loadMe() {
  try {
    const res = await fetch('/api/auth/me', { credentials: 'same-origin' })
    const data = await res.json()
    return { user: data.user as Me | null, unread: Number(data.unread || 0) }
  } catch {
    return { user: null, unread: 0 }
  }
}
