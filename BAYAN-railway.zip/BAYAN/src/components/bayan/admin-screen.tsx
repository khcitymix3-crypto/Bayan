'use client'

import { useCallback, useEffect, useState } from 'react'
import { api } from '@/components/bayan/api'
import { BayanAvatar, EmptyState, LoadingBlock, ScreenHeader } from '@/components/bayan/ui-bits'
import { useBayan } from '@/components/bayan/store'
import { T } from '@/lib/i18n'
import { faNum, timeAgoFa } from '@/lib/persian'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { toast } from '@/hooks/use-toast'
import {
  Ban, BarChart3, CheckCircle2, Eye, EyeOff, FileText, Flag, RotateCcw, Search, ShieldCheck, Store, Trash2, Users,
} from 'lucide-react'

// ============================================================
// BAYAN | بیان — پنل مدیریت: داشبورد، کاربران، مطالب، گزارش‌ها
// سطح دسترسی: ADMIN / MODERATOR — عملیات حساس لاگ می‌شوند
// ============================================================

interface Stats {
  users: number
  posts: number
  comments: number
  messages: number
  businesses: number
  reportsNew: number
  blocked: number
  media: number
}

export function AdminScreen() {
  const { goBack, me } = useBayan()
  const [tab, setTab] = useState<'dashboard' | 'users' | 'posts' | 'reports'>('dashboard')
  const [stats, setStats] = useState<Stats | null>(null)
  const [denied, setDenied] = useState(false)

  useEffect(() => {
    api<{ stats: Stats }>('/admin/stats')
      .then((r) => setStats(r.stats))
      .catch(() => setDenied(true))
  }, [])

  if (denied || (me && !['ADMIN', 'MODERATOR'].includes(me.role))) {
    return (
      <div>
        <ScreenHeader title={T.admin.title} onBack={goBack} />
        <EmptyState icon={<ShieldCheck className="h-12 w-12" />} title={T.admin.noAccess} />
      </div>
    )
  }

  const tabs = [
    { key: 'dashboard' as const, label: T.admin.dashboard, icon: BarChart3 },
    { key: 'users' as const, label: T.admin.users, icon: Users },
    { key: 'posts' as const, label: T.admin.posts, icon: FileText },
    { key: 'reports' as const, label: T.admin.reports, icon: Flag },
  ]

  return (
    <div>
      <ScreenHeader title={T.admin.title} onBack={goBack} />

      <div className="sticky top-14 z-20 flex border-b bg-background/85 backdrop-blur-md" role="tablist">
        {tabs.map((t) => (
          <button
            key={t.key}
            role="tab"
            aria-selected={tab === t.key}
            className={`flex min-h-12 flex-1 items-center justify-center gap-1.5 text-xs font-bold sm:text-sm ${
              tab === t.key ? 'border-b-2 border-primary text-primary' : 'text-muted-foreground'
            }`}
            onClick={() => setTab(t.key)}
          >
            <t.icon className="h-4 w-4" aria-hidden /> {t.label}
          </button>
        ))}
      </div>

      {tab === 'dashboard' && (stats ? <Dashboard stats={stats} /> : <LoadingBlock />)}
      {tab === 'users' && <UsersTab />}
      {tab === 'posts' && <PostsTab />}
      {tab === 'reports' && <ReportsTab />}
    </div>
  )
}

function Dashboard({ stats }: { stats: Stats }) {
  const cards = [
    { label: T.admin.totalUsers, value: stats.users, icon: Users },
    { label: T.admin.totalPosts, value: stats.posts, icon: FileText },
    { label: T.admin.totalMessages, value: stats.messages, icon: CheckCircle2 },
    { label: T.admin.newReports, value: stats.reportsNew, icon: Flag },
    { label: T.admin.blocked, value: stats.blocked, icon: Ban },
    { label: T.admin.businesses, value: stats.businesses, icon: Store },
  ]
  return (
    <div className="mx-auto max-w-2xl p-4">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {cards.map((c) => (
          <div key={c.label} className="rounded-2xl border bg-card p-4 text-center">
            <c.icon className="mx-auto mb-1.5 h-5 w-5 text-primary" aria-hidden />
            <p className="text-2xl font-black tabular">{faNum(c.value)}</p>
            <p className="mt-0.5 text-xs text-muted-foreground">{c.label}</p>
          </div>
        ))}
      </div>
      <p className="mt-4 rounded-xl bg-muted/60 p-3 text-xs leading-6 text-muted-foreground">
        <ShieldCheck className="ml-1 inline h-4 w-4" aria-hidden />
        تمام عملیات مدیریتی حساس (مسدودسازی، حذف پست، بررسی گزارش) در گزارش فعالیت مدیران ثبت می‌شود.
      </p>
    </div>
  )
}

// ---------------- کاربران ----------------

interface AdminUser {
  id: string
  name: string
  username: string
  role: string
  status: string
  createdAt: string
  phoneMasked: string
}

function UsersTab() {
  const [users, setUsers] = useState<AdminUser[]>([])
  const [q, setQ] = useState('')
  const [loading, setLoading] = useState(true)

  const load = useCallback(async (query = '') => {
    setLoading(true)
    try {
      const res = await api<{ users: AdminUser[] }>(`/admin/users${query ? `?q=${encodeURIComponent(query)}` : ''}`)
      setUsers(res.users)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  useEffect(() => {
    const t = setTimeout(() => load(q.trim()), 350)
    return () => clearTimeout(t)
  }, [q, load])

  async function act(userId: string, action: string) {
    try {
      await api('/admin/users', { method: 'PATCH', body: { userId, action } })
      load(q.trim())
      toast({ description: 'انجام شد' })
    } catch (e) {
      toast({ description: e instanceof Error ? e.message : T.common.error, variant: 'destructive' })
    }
  }

  return (
    <div className="mx-auto max-w-2xl p-4">
      <div className="relative mb-3">
        <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="جست‌وجوی کاربر…" className="min-h-11 bg-muted/50 pr-9" />
      </div>
      {loading ? (
        <LoadingBlock />
      ) : (
        <div className="space-y-2">
          {users.map((u) => (
            <div key={u.id} className="flex items-center gap-3 rounded-xl border bg-card p-3">
              <BayanAvatar name={u.name} size="sm" />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-bold">
                  {u.name}
                  {u.role !== 'USER' && <span className="mr-1.5 rounded bg-primary/10 px-1.5 py-0.5 text-[0.6rem] text-primary">{u.role}</span>}
                  {u.status === 'BLOCKED' && <span className="mr-1.5 rounded bg-destructive/10 px-1.5 py-0.5 text-[0.6rem] text-destructive">مسدود</span>}
                </p>
                <p className="text-xs text-muted-foreground" dir="ltr">@{u.username} · {u.phoneMasked}</p>
              </div>
              <div className="flex shrink-0 gap-1">
                {u.status === 'ACTIVE' ? (
                  <Button size="icon" variant="outline" className="h-9 w-9" onClick={() => act(u.id, 'block')} aria-label={T.admin.block}>
                    <Ban className="h-4 w-4" />
                  </Button>
                ) : (
                  <Button size="icon" variant="outline" className="h-9 w-9" onClick={() => act(u.id, 'unblock')} aria-label={T.admin.unblock}>
                    <RotateCcw className="h-4 w-4" />
                  </Button>
                )}
                {u.role === 'USER' ? (
                  <Button size="icon" variant="ghost" className="h-9 w-9" onClick={() => act(u.id, 'promote')} aria-label="ارتقا به ناظر">
                    <ShieldCheck className="h-4 w-4" />
                  </Button>
                ) : (
                  u.role === 'MODERATOR' && (
                    <Button size="icon" variant="ghost" className="h-9 w-9" onClick={() => act(u.id, 'demote')} aria-label="سلب ناظری">
                      <ShieldCheck className="h-4 w-4 text-muted-foreground" />
                    </Button>
                  )
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// ---------------- پست‌ها ----------------

interface AdminPost {
  id: string
  content: string
  status: string
  createdAt: string
  author: { id: string; name: string; username: string; avatarUrl: string | null }
}

function PostsTab() {
  const [posts, setPosts] = useState<AdminPost[]>([])
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const res = await api<{ posts: AdminPost[] }>('/admin/posts')
      setPosts(res.posts)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  async function act(postId: string, action: 'hide' | 'unhide' | 'delete') {
    try {
      if (action === 'delete') {
        await api(`/admin/posts?id=${postId}`, { method: 'DELETE' })
        setPosts((p) => p.filter((x) => x.id !== postId))
      } else {
        await api('/admin/posts', { method: 'PATCH', body: { postId, action } })
        setPosts((p) => p.map((x) => (x.id === postId ? { ...x, status: action === 'hide' ? 'HIDDEN' : 'PUBLISHED' } : x)))
      }
      toast({ description: 'انجام شد' })
    } catch (e) {
      toast({ description: e instanceof Error ? e.message : T.common.error, variant: 'destructive' })
    }
  }

  return (
    <div className="mx-auto max-w-2xl p-4">
      {loading ? (
        <LoadingBlock />
      ) : posts.length === 0 ? (
        <EmptyState icon={<FileText className="h-12 w-12" />} title="پستی وجود ندارد" />
      ) : (
        <div className="space-y-2">
          {posts.map((p) => (
            <div key={p.id} className={`rounded-xl border bg-card p-3 ${p.status === 'HIDDEN' ? 'opacity-60' : ''}`}>
              <div className="flex items-center gap-2">
                <BayanAvatar name={p.author.name} src={p.author.avatarUrl} size="sm" />
                <p className="text-xs font-bold" dir="ltr">@{p.author.username}</p>
                <span className="mr-auto text-[0.65rem] text-muted-foreground">{timeAgoFa(p.createdAt)}</span>
                {p.status === 'HIDDEN' && <span className="rounded bg-amber-500/15 px-1.5 py-0.5 text-[0.6rem] text-amber-600">پنهان</span>}
              </div>
              <p className="mt-2 line-clamp-2 text-sm leading-6">{p.content}</p>
              <div className="mt-2 flex gap-1.5">
                {p.status === 'PUBLISHED' ? (
                  <Button size="sm" variant="outline" className="min-h-9 px-3" onClick={() => act(p.id, 'hide')}>
                    <EyeOff className="h-3.5 w-3.5" aria-hidden /> {T.admin.hide}
                  </Button>
                ) : (
                  <Button size="sm" variant="outline" className="min-h-9 px-3" onClick={() => act(p.id, 'unhide')}>
                    <Eye className="h-3.5 w-3.5" aria-hidden /> {T.admin.unhide}
                  </Button>
                )}
                <Button size="sm" variant="outline" className="min-h-9 px-3 text-destructive" onClick={() => act(p.id, 'delete')}>
                  <Trash2 className="h-3.5 w-3.5" aria-hidden /> {T.admin.deletePost}
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// ---------------- گزارش‌ها ----------------

interface AdminReport {
  id: string
  targetType: string
  targetId: string
  targetPreview: string
  reason: string
  details: string
  status: string
  createdAt: string
  reporter: { id: string; name: string; username: string }
}

const STATUS_STYLE: Record<string, string> = {
  NEW: 'bg-red-500/10 text-red-600',
  REVIEWING: 'bg-amber-500/10 text-amber-600',
  RESOLVED: 'bg-green-500/10 text-green-600',
  CLOSED: 'bg-muted text-muted-foreground',
}

function ReportsTab() {
  const [reports, setReports] = useState<AdminReport[]>([])
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const res = await api<{ reports: AdminReport[] }>('/admin/reports')
      setReports(res.reports)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  async function setStatus(reportId: string, status: string) {
    try {
      await api('/admin/reports', { method: 'PATCH', body: { reportId, status } })
      setReports((r) => r.map((x) => (x.id === reportId ? { ...x, status } : x)))
    } catch (e) {
      toast({ description: e instanceof Error ? e.message : T.common.error, variant: 'destructive' })
    }
  }

  const reasonLabel = (r: string) => (T.post.reasons as Record<string, string>)[r] || r

  return (
    <div className="mx-auto max-w-2xl p-4">
      {loading ? (
        <LoadingBlock />
      ) : reports.length === 0 ? (
        <EmptyState icon={<Flag className="h-12 w-12" />} title="گزارشی وجود ندارد" />
      ) : (
        <div className="space-y-2.5">
          {reports.map((r) => (
            <div key={r.id} className="rounded-xl border bg-card p-3.5">
              <div className="flex items-center gap-2 text-xs">
                <span className={`rounded px-1.5 py-0.5 font-bold ${STATUS_STYLE[r.status] || ''}`}>{(T.admin.statuses as Record<string, string>)[r.status] || r.status}</span>
                <span className="text-muted-foreground">{reasonLabel(r.reason)}</span>
                <span className="mr-auto text-muted-foreground">{timeAgoFa(r.createdAt)}</span>
              </div>
              <p className="mt-2 rounded-lg bg-muted/60 p-2 text-sm leading-6">{r.targetPreview}</p>
              <p className="mt-1.5 text-xs text-muted-foreground">
                گزارش‌دهنده: @{r.reporter.username} · نوع: {r.targetType === 'POST' ? 'پست' : r.targetType === 'USER' ? 'کاربر' : r.targetType === 'COMMENT' ? 'نظر' : 'پیام'}
              </p>
              <div className="mt-2.5 flex flex-wrap gap-1.5">
                <Button size="sm" variant="outline" className="min-h-9 px-3" onClick={() => setStatus(r.id, 'REVIEWING')}>
                  در حال بررسی
                </Button>
                <Button size="sm" variant="outline" className="min-h-9 px-3 text-green-600" onClick={() => setStatus(r.id, 'RESOLVED')}>
                  <CheckCircle2 className="h-3.5 w-3.5" aria-hidden /> بررسی‌شد
                </Button>
                <Button size="sm" variant="ghost" className="min-h-9 px-3" onClick={() => setStatus(r.id, 'CLOSED')}>
                  بستن
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
