'use client'

import { useEffect, useRef, useState } from 'react'
import 'leaflet/dist/leaflet.css'
import type { Map as LeafletMap, Marker } from 'leaflet'
import { ScreenHeader, LoadingBlock } from '@/components/bayan/ui-bits'
import { T } from '@/lib/i18n'
import { faNum } from '@/lib/persian'
import { Phone, MapPin, Navigation, X, Store } from 'lucide-react'

// ============================================================
// BAYAN | بیان — نقشه بیان (OpenStreetMap + Leaflet)
// موقعیت زنده کاربر فقط با اجازه صریح او فعال می‌شود
// ============================================================

export interface BusinessData {
  id: string
  name: string
  category: string
  description: string
  phone: string
  address: string
  city: string
  lat: number
  lng: number
  hours: string
  isVerified: boolean
  ownerUsername: string | null
}

const CATEGORY_COLORS: Record<string, string> = {
  فروشگاه: '#0d9488', نانوایی: '#d97706', رستوران: '#dc2626', پزشک: '#2563eb',
  داروخانه: '#16a34a', هتل: '#7c3aed', مدرسه: '#0891b2', دانشگاه: '#4f46e5',
  تعمیرگاه: '#525252', شرکت: '#0f766e', کارخانه: '#78716c', 'خدمات منزل': '#65a30d',
  گردشگری: '#ea580c', 'حمل‌ونقل': '#0369a1', 'مراکز عمومی': '#b45309', سایر: '#6b7280',
}

function categoryIcon(category: string): import('leaflet').DivIcon {
  if (!L_) throw new Error('leaflet not ready')
  return L_.divIcon({
    className: '',
    html: `<div style="background:${CATEGORY_COLORS[category] || '#6b7280'};width:26px;height:26px;border-radius:50% 50% 50% 0;transform:rotate(-45deg);border:2px solid white;box-shadow:0 1px 4px rgba(0,0,0,.35);display:flex;align-items:center;justify-content:center"><span style="transform:rotate(45deg);color:white;font-size:11px;font-weight:bold">ب</span></div>`,
    iconSize: [26, 26],
    iconAnchor: [13, 24],
    popupAnchor: [0, -22],
  })
}

// نگه‌داشت ماژول leaflet برای استفاده در متدهای کمکی
let L_: typeof import('leaflet') | null = null
let leafletPromise: Promise<typeof import('leaflet')> | null = null

/** بارگذاری یک‌باره leaflet (کلاینت فقط) */
export function loadLeaflet(): Promise<typeof import('leaflet')> {
  if (!leafletPromise) {
    leafletPromise = import('leaflet').then((mod) => {
      L_ = (mod.default || mod) as typeof import('leaflet')
      return L_
    })
  }
  return leafletPromise
}

export function MapScreen({ onBack }: { onBack: () => void }) {
  const mapRef = useRef<LeafletMap | null>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const markersRef = useRef<Marker[]>([])
  const [businesses, setBusinesses] = useState<BusinessData[]>([])
  const [categories, setCategories] = useState<string[]>([])
  const [category, setCategory] = useState('all')
  const [selected, setSelected] = useState<BusinessData | null>(null)
  const [loading, setLoading] = useState(true)
  const [ready, setReady] = useState(false)

  async function loadBusinesses() {
    const res = await fetch('/api/businesses')
    return res.json() as Promise<{ businesses: BusinessData[]; categories: string[] }>
  }

  // بارگذاری leaflet به‌صورت پویا (فقط کلاینت)
  useEffect(() => {
    let cancelled = false
    loadLeaflet().then(() => {
      if (!cancelled) setReady(true)
    })
    return () => {
      cancelled = true
    }
  }, [])

  // داده کسب‌وکارها
  useEffect(() => {
    loadBusinesses().then((data) => {
      setBusinesses(data.businesses)
      setCategories(data.categories)
      setLoading(false)
    })
  }, [])

  // ساخت نقشه
  useEffect(() => {
    if (!ready || !containerRef.current || mapRef.current || !L_) return

    const map = L_.map(containerRef.current, {
      center: [30.4394, 48.2666], // خرمشهر — زادگاه ایده برند بیان
      zoom: 13,
      attributionControl: true,
    })

    L_.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '© OpenStreetMap contributors',
    }).addTo(map)

    mapRef.current = map

    return () => {
      map.remove()
      mapRef.current = null
    }
  }, [ready])

  // نشانگرها
  useEffect(() => {
    const map = mapRef.current
    if (!map || !L_) return

    markersRef.current.forEach((m) => m.remove())
    markersRef.current = []

    const filtered = category === 'all' ? businesses : businesses.filter((b) => b.category === category)

    for (const b of filtered) {
      const marker = L_.marker([b.lat, b.lng], { icon: categoryIcon(b.category) }).addTo(map)
      marker.on('click', () => setSelected(b))
      markersRef.current.push(marker)
    }
  }, [businesses, category, ready])

  function locateMe() {
    const map = mapRef.current
    if (!map || !navigator.geolocation) return
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        map.flyTo([pos.coords.latitude, pos.coords.longitude], 15)
        if (L_) {
          L_.circle([pos.coords.latitude, pos.coords.longitude], {
            radius: 60, color: '#0d9488', fillColor: '#0d9488', fillOpacity: 0.15, weight: 2,
          }).addTo(map)
        }
      },
      () => undefined,
      { enableHighAccuracy: true }
    )
  }

  return (
    <div className="fixed inset-0 z-40 flex flex-col bg-background">
      <ScreenHeader title={T.map.title} onBack={onBack} />

      {/* فیلتر دسته‌بندی */}
      <div className="bayan-scroll z-10 flex gap-1.5 overflow-x-auto border-b bg-background px-3 py-2">
        <CategoryChip active={category === 'all'} label={T.map.allCategories} onClick={() => setCategory('all')} />
        {categories.map((c) => (
          <CategoryChip key={c} active={category === c} label={c} color={CATEGORY_COLORS[c]} onClick={() => setCategory(c)} />
        ))}
      </div>

      {/* نقشه */}
      <div className="relative flex-1">
        <div ref={containerRef} className="h-full w-full" aria-label={T.map.title} role="application" />
        {loading && (
          <div className="absolute inset-x-0 top-1/2 -translate-y-1/2">
            <LoadingBlock />
          </div>
        )}

        {/* دکمه موقعیت من */}
        <button
          type="button"
          onClick={locateMe}
          className="absolute bottom-5 left-4 flex h-12 w-12 items-center justify-center rounded-full border bg-card text-primary shadow-lg"
          aria-label={T.map.locateMe}
          title={T.map.locateMe}
        >
          <MapPin className="h-5 w-5" aria-hidden />
        </button>
      </div>

      {/* کارت کسب‌وکار */}
      {selected && (
        <div className="absolute inset-x-3 bottom-4 z-20 max-w-md self-center rounded-2xl border bg-card p-4 shadow-xl" role="dialog" aria-label={T.map.viewProfile}>
          <button
            type="button"
            onClick={() => setSelected(null)}
            className="absolute left-3 top-3 text-muted-foreground hover:text-foreground"
            aria-label={T.common.close}
          >
            <X className="h-5 w-5" aria-hidden />
          </button>

          <div className="flex items-start gap-3">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl text-white" style={{ background: CATEGORY_COLORS[selected.category] || '#6b7280' }}>
              <Store className="h-6 w-6" aria-hidden />
            </div>
            <div className="min-w-0 flex-1">
              <p className="flex items-center gap-1.5 font-black">
                {selected.name}
                {selected.isVerified && <span className="rounded bg-primary/10 px-1.5 py-0.5 text-[0.6rem] font-bold text-primary">{T.business.verified}</span>}
              </p>
              <p className="text-xs text-muted-foreground">
                {selected.category} {selected.city && `· ${selected.city}`}
              </p>
            </div>
          </div>

          {selected.description && <p className="mt-2 text-sm leading-6">{selected.description}</p>}
          {selected.address && <p className="mt-1.5 text-xs text-muted-foreground">📍 {selected.address}</p>}
          {selected.hours && <p className="mt-1 text-xs text-muted-foreground">🕘 {selected.hours}</p>}

          <div className="mt-3 flex gap-2">
            {selected.phone && (
              <a
                href={`tel:${selected.phone}`}
                className="flex min-h-11 flex-1 items-center justify-center gap-1.5 rounded-xl border text-sm font-bold hover:bg-accent"
              >
                <Phone className="h-4 w-4" aria-hidden /> {T.business.call}
              </a>
            )}
            <a
              href={`https://www.openstreetmap.org/directions?to=${selected.lat},${selected.lng}`}
              target="_blank"
              rel="noreferrer"
              className="flex min-h-11 flex-1 items-center justify-center gap-1.5 rounded-xl bg-primary text-sm font-bold text-primary-foreground"
            >
              <Navigation className="h-4 w-4" aria-hidden /> {T.map.directions}
            </a>
          </div>
        </div>
      )}

      {/* شمار کسب‌وکارها */}
      <p className="border-t bg-background py-1.5 text-center text-[0.65rem] text-muted-foreground">
        {faNum(category === 'all' ? businesses.length : businesses.filter((b) => b.category === category).length)} {T.business.title} روی نقشه بیان
      </p>
    </div>
  )
}

function CategoryChip({
  active,
  label,
  color,
  onClick,
}: {
  active: boolean
  label: string
  color?: string
  onClick: () => void
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={`flex min-h-9 shrink-0 items-center gap-1.5 rounded-full border px-3.5 text-xs font-bold transition-colors ${
        active ? 'border-primary bg-primary text-primary-foreground' : 'bg-card text-muted-foreground hover:bg-accent'
      }`}
    >
      {color && <span className="h-2 w-2 rounded-full" style={{ background: active ? 'white' : color }} aria-hidden />}
      {label}
    </button>
  )
}
