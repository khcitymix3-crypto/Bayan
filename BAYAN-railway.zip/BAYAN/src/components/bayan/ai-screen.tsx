'use client'

import { useEffect, useRef, useState } from 'react'
import { api } from '@/components/bayan/api'
import { BayanAvatar, ScreenHeader } from '@/components/bayan/ui-bits'
import { useBayan } from '@/components/bayan/store'
import { Button } from '@/components/ui/button'
import { T } from '@/lib/i18n'
import { toast } from '@/hooks/use-toast'
import { Loader2, Send, Sparkles } from 'lucide-react'

// ============================================================
// BAYAN | بیان — دستیار هوش مصنوعی (گفت‌وگوی متنی MVP)
// فاز ۲: صوت به متن، متن به صدا، توضیح تصویر، کنترل صوتی
// ============================================================

interface AiMessage {
  role: 'user' | 'assistant'
  content: string
}

export function AiScreen() {
  const { goBack, me } = useBayan()
  const [messages, setMessages] = useState<AiMessage[]>([{ role: 'assistant', content: T.ai.greeting }])
  const [text, setText] = useState('')
  const [busy, setBusy] = useState(false)
  const bottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  async function send(preset?: string) {
    const content = (preset || text).trim()
    if (!content || busy) return
    const next: AiMessage[] = [...messages, { role: 'user', content }]
    setMessages(next)
    setText('')
    setBusy(true)
    try {
      const res = await api<{ reply: string }>('/ai/chat', {
        body: { messages: next.filter((m) => m.role === 'user' || m.role === 'assistant').slice(1) },
      })
      setMessages([...next, { role: 'assistant', content: res.reply }])
    } catch (e) {
      toast({ description: e instanceof Error ? e.message : T.ai.error, variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="flex h-dvh flex-col">
      <ScreenHeader title={T.ai.title} subtitle="دستیار هوشمند بیان" onBack={goBack} />

      <div className="bayan-scroll flex-1 overflow-y-auto px-3 py-4">
        <div className="mx-auto max-w-2xl space-y-3">
          {messages.map((m, i) => (
            <div key={i} className={`flex gap-2.5 ${m.role === 'user' ? 'flex-row-reverse' : ''}`}>
              {m.role === 'assistant' ? (
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                  <Sparkles className="h-5 w-5" aria-hidden />
                </div>
              ) : (
                <BayanAvatar name={me?.name || 'شما'} src={me?.avatarUrl} size="sm" />
              )}
              <div
                className={`max-w-[80%] whitespace-pre-wrap break-words rounded-2xl px-4 py-2.5 text-sm leading-7 shadow-sm ${
                  m.role === 'user' ? 'chat-bubble-me bg-primary text-primary-foreground' : 'chat-bubble-them bg-muted'
                }`}
              >
                {m.content}
              </div>
            </div>
          ))}

          {busy && (
            <div className="flex items-center gap-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-primary">
                <Sparkles className="h-5 w-5" aria-hidden />
              </div>
              <div className="flex items-center gap-2 rounded-2xl bg-muted px-4 py-3 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                {T.ai.thinking}
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>
      </div>

      {/* پیشنهادها */}
      {messages.length <= 1 && (
        <div className="mx-auto w-full max-w-2xl px-3 pb-1">
          <div className="flex flex-wrap gap-2">
            {T.ai.chips.map((chip) => (
              <button
                key={chip}
                type="button"
                onClick={() => send(chip)}
                className="rounded-full border bg-card px-3.5 py-2 text-xs font-semibold text-primary transition-colors hover:bg-accent"
              >
                {chip}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="border-t bg-background p-2.5 safe-bottom">
        <div className="mx-auto flex max-w-2xl items-center gap-2">
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={T.ai.placeholder}
            className="min-h-11 flex-1 rounded-full border bg-transparent px-4 text-sm outline-none placeholder:text-muted-foreground/60 focus:ring-1 focus:ring-ring"
            aria-label={T.ai.placeholder}
            onKeyDown={(e) => e.key === 'Enter' && send()}
          />
          <Button size="icon" className="h-11 w-11 shrink-0 rounded-full" onClick={() => send()} disabled={busy || !text.trim()} aria-label={T.ai.send}>
            <Send className="h-5 w-5 -scale-x-100" aria-hidden />
          </Button>
        </div>
      </div>
    </div>
  )
}
