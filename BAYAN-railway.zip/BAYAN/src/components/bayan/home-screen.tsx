'use client'

import { useCallback, useEffect, useState } from 'react'
import { api } from '@/components/bayan/api'
import { PostCard, type PostData } from '@/components/bayan/post-card'
import { EmptyState, FeedSkeleton, LoadingBlock } from '@/components/bayan/ui-bits'
import { useBayan } from '@/components/bayan/store'
import { T } from '@/lib/i18n'
import { Button } from '@/components/ui/button'
import { Sparkles } from 'lucide-react'

// ============================================================
// BAYAN | بیان — صفحه خانه (فید): همه / دنبال‌شده‌ها / ذخیره‌شده‌ها
// ============================================================

export function HomeScreen() {
  const { me } = useBayan()
  const [tab, setTab] = useState<'foryou' | 'following' | 'saved'>('foryou')
  const [posts, setPosts] = useState<PostData[]>([])
  const [cursor, setCursor] = useState<string | null>(null)
  const [hasMore, setHasMore] = useState(false)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const loadFeed = useCallback(async (nextTab: string, refresh = true, after?: string | null) => {
    try {
      setError('')
      if (refresh) setLoading(true)
      const res = await api<{ posts: PostData[]; nextCursor: string | null }>(
        `/posts?tab=${nextTab}${after ? `&cursor=${after}` : ''}`
      )
      setPosts((prev) => (after ? [...prev, ...res.posts] : res.posts))
      setCursor(res.nextCursor)
      setHasMore(!!res.nextCursor)
    } catch (e) {
      setError(e instanceof Error ? e.message : T.common.error)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    loadFeed(tab)
  }, [tab, loadFeed])

  // تازه‌سازی پس از انتشار پست
  useEffect(() => {
    const handler = () => loadFeed(tab)
    window.addEventListener('bayan:feed-refresh', handler)
    return () => window.removeEventListener('bayan:feed-refresh', handler)
  }, [tab, loadFeed])

  const tabs: Array<{ key: 'foryou' | 'following' | 'saved'; label: string }> = [
    { key: 'foryou', label: T.post.forYou },
    { key: 'following', label: T.post.following },
    { key: 'saved', label: T.post.savedTab },
  ]

  return (
    <div className="mx-auto max-w-2xl">
      {/* تب‌ها */}
      <div className="sticky top-14 z-20 flex border-b bg-background/85 backdrop-blur-md" role="tablist" aria-label="فیلتر فید">
        {tabs.map((t) => (
          <button
            key={t.key}
            role="tab"
            aria-selected={tab === t.key}
            className={`flex min-h-12 flex-1 items-center justify-center gap-1.5 text-sm font-semibold transition-colors ${
              tab === t.key ? 'border-b-2 border-primary text-primary' : 'text-muted-foreground hover:text-foreground'
            }`}
            onClick={() => setTab(t.key)}
          >
            {t.label}
          </button>
        ))}
      </div>

      {!me && (
        <div className="mx-4 mt-4 rounded-2xl border border-primary/25 bg-primary/5 p-4">
          <p className="flex items-center gap-2 font-bold text-primary">
            <Sparkles className="h-5 w-5" aria-hidden /> {T.brand}
          </p>
          <p className="mt-1 text-sm text-muted-foreground">{T.tagline}</p>
        </div>
      )}

      {error && (
        <div className="mx-4 mt-4 rounded-xl bg-destructive/10 p-3 text-sm text-destructive" role="alert">
          {error}
          <Button variant="ghost" size="sm" onClick={() => loadFeed(tab)} className="mr-2">
            {T.common.retry}
          </Button>
        </div>
      )}

      {loading ? (
        <FeedSkeleton />
      ) : posts.length === 0 && !error ? (
        <EmptyState
          icon={<Sparkles className="h-12 w-12" />}
          title={T.post.emptyFeed}
          hint={me ? 'با دکمه + پایین صفحه اولین پست را منتشر کنید' : T.auth.hasAccount}
        />
      ) : (
        <div className="space-y-3 p-3" role="feed">
          {posts.map((p) => (
            <PostCard
              key={p.id}
              post={p}
              onChanged={(np) => {
                if (!np) setPosts((arr) => arr.filter((x) => x.id !== p.id))
              }}
            />
          ))}
          {hasMore && (
            <Button
              variant="outline"
              className="mx-auto mt-2 block min-h-11 px-8"
              onClick={() => loadFeed(tab, false, cursor)}
            >
              {T.post.loadMore}
            </Button>
          )}
          {!hasMore && posts.length > 3 && <LoadingBlock />}
        </div>
      )}
    </div>
  )
}
