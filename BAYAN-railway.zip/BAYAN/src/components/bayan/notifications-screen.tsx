'use client'

import { useCallback, useEffect, useState } from 'react'
import { api } from '@/components/bayan/api'
import { BayanAvatar, EmptyState, LoadingBlock, ScreenHeader } from '@/components/bayan/ui-bits'
import { useBayan } from '@/components/bayan/store'
import { T } from '@/lib/i18n'
import { timeAgoFa } from '@/lib/persian'
import { Button } from '@/components/ui/button'
import { Bell, Heart, MessageCircle, UserPlus, Send, Megaphone, Sparkles } from 'lucide-react'

// ============================================================
// BAYAN | بیان — اعلان‌ها: پسند، نظر، پاسخ، دنبال‌کننده، پیام
// ============================================================

interface NotifData {
  id: string
  type: string
  text: string
  entityId: string | null
  isRead: boolean
  createdAt: string
  actor: { id: string; name: string; username: string; avatarUrl: string | null } | null
}

const ICONS: Record<string, typeof Heart> = {
  LIKE: Heart,
  COMMENT: MessageCircle,
  REPLY: MessageCircle,
  FOLLOW: UserPlus,
  MESSAGE: Send,
  CHANNEL: Megaphone,
  SYSTEM: Sparkles,
}

export function NotificationsScreen() {
  const { goBack, navigate, setUnread } = useBayan()
  const [notifs, setNotifs] = useState<NotifData[]>([])
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    try {
      const res = await api<{ notifications: NotifData[]; unread: number }>('/notifications')
      setNotifs(res.notifications)
      setUnread(res.unread)
    } finally {
      setLoading(false)
    }
  }, [setUnread])

  useEffect(() => {
    load()
  }, [load])

  async function markAll() {
    await api('/notifications/read', { method: 'PATCH', body: { all: true } }).catch(() => null)
    setNotifs((n) => n.map((x) => ({ ...x, isRead: true })))
    setUnread(0)
  }

  function open(n: NotifData) {
    api('/notifications/read', { method: 'PATCH', body: { ids: [n.id] } }).catch(() => null)
    setNotifs((arr) => arr.map((x) => (x.id === n.id ? { ...x, isRead: true } : x)))
    if (n.type === 'FOLLOW' && n.actor) navigate({ screen: 'profile', username: n.actor.username })
    else if (n.type === 'MESSAGE' && n.entityId) navigate({ screen: 'chat', conversationId: n.entityId })
    else if (n.type === 'CHANNEL' && n.entityId) navigate({ screen: 'chat', conversationId: n.entityId })
    else if ((n.type === 'LIKE' || n.type === 'COMMENT' || n.type === 'REPLY') && n.actor)
      navigate({ screen: 'profile', username: n.actor.username })
  }

  return (
    <div>
      <ScreenHeader
        title={T.nav.notifications}
        onBack={goBack}
        action={
          notifs.some((n) => !n.isRead) ? (
            <Button size="sm" variant="ghost" className="min-h-10" onClick={markAll}>
              خواندن همه
            </Button>
          ) : undefined
        }
      />
      {loading ? (
        <LoadingBlock />
      ) : notifs.length === 0 ? (
        <EmptyState icon={<Bell className="h-12 w-12" />} title="اعلانی ندارید" hint="اعلان‌های پسند، نظر، دنبال‌کردن و پیام اینجا نمایش داده می‌شود" />
      ) : (
        <div className="mx-auto max-w-2xl divide-y">
          {notifs.map((n) => {
            const Icon = ICONS[n.type] || Bell
            return (
              <button
                key={n.id}
                type="button"
                onClick={() => open(n)}
                className={`flex w-full items-center gap-3 p-3.5 text-right transition-colors hover:bg-accent/50 ${!n.isRead ? 'bg-primary/5' : ''}`}
              >
                {n.actor ? (
                  <BayanAvatar name={n.actor.name} src={n.actor.avatarUrl} />
                ) : (
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary">
                    <Icon className="h-5 w-5" aria-hidden />
                  </div>
                )}
                <div className="min-w-0 flex-1">
                  <p className="text-sm leading-6">
                    {n.actor && <span className="font-bold">{n.actor.name} </span>}
                    {n.text}
                  </p>
                  <p className="text-xs text-muted-foreground">{timeAgoFa(n.createdAt)}</p>
                </div>
                {!n.isRead && <span className="h-2.5 w-2.5 shrink-0 rounded-full bg-primary" aria-label="خوانده‌نشده" />}
              </button>
            )
          })}
        </div>
      )}
    </div>
  )
}
