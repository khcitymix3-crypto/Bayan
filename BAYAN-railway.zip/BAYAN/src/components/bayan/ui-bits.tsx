'use client'

import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Skeleton } from '@/components/ui/skeleton'
import { Button } from '@/components/ui/button'
import { Loader2 } from 'lucide-react'
import type { ReactNode } from 'react'
import { T } from '@/lib/i18n'

// ============================================================
// BAYAN | بیان — اجزای مشترک رابط کاربری
// ============================================================

export function BayanAvatar({
  name,
  src,
  size = 'md',
  className = '',
}: {
  name: string
  src?: string | null
  size?: 'sm' | 'md' | 'lg' | 'xl'
  className?: string
}) {
  const sizeClass = { sm: 'h-8 w-8 text-xs', md: 'h-10 w-10 text-sm', lg: 'h-14 w-14 text-lg', xl: 'h-24 w-24 text-3xl' }[size]
  const initial = (name || '؟').trim().charAt(0)
  return (
    <Avatar className={`${sizeClass} ${className}`}>
      {src ? <AvatarImage src={src} alt={`تصویر ${name}`} loading="lazy" /> : null}
      <AvatarFallback className="bg-primary/10 text-primary font-bold" aria-hidden>
        {initial}
      </AvatarFallback>
    </Avatar>
  )
}

export function ScreenHeader({
  title,
  onBack,
  action,
  subtitle,
}: {
  title: string
  onBack?: () => void
  action?: ReactNode
  subtitle?: string
}) {
  return (
    <header className="sticky top-0 z-30 bg-background/85 backdrop-blur-md border-b border-border/60 safe-top">
      <div className="flex items-center gap-2 px-3 h-14 max-w-2xl mx-auto">
        {onBack && (
          <Button variant="ghost" size="icon" onClick={onBack} aria-label={T.nav.back} className="shrink-0">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
              <path d="M9 6l6 6-6 6" />
            </svg>
          </Button>
        )}
        <div className="min-w-0 flex-1">
          <h1 className="font-bold text-base truncate">{title}</h1>
          {subtitle && <p className="text-xs text-muted-foreground truncate">{subtitle}</p>}
        </div>
        {action}
      </div>
    </header>
  )
}

export function EmptyState({ icon, title, hint }: { icon?: ReactNode; title: string; hint?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-6 text-center">
      {icon && <div className="mb-4 text-muted-foreground/50">{icon}</div>}
      <p className="font-bold text-muted-foreground">{title}</p>
      {hint && <p className="text-sm text-muted-foreground/70 mt-1 max-w-xs">{hint}</p>}
    </div>
  )
}

export function LoadingBlock() {
  return (
    <div className="flex items-center justify-center py-14 text-muted-foreground gap-2">
      <Loader2 className="h-5 w-5 animate-spin" aria-hidden />
      <span className="text-sm">{T.common.loading}</span>
    </div>
  )
}

export function FeedSkeleton() {
  return (
    <div className="space-y-4 p-4">
      {[1, 2, 3].map((i) => (
        <div key={i} className="flex gap-3">
          <Skeleton className="h-10 w-10 rounded-full shrink-0" />
          <div className="flex-1 space-y-2">
            <Skeleton className="h-4 w-32" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-2/3" />
          </div>
        </div>
      ))}
    </div>
  )
}

/** دکمه شناور اصلی — حداقل ۴۴ پیکسل هدف لمسی (دسترسی‌پذیری) */
export function BigTouchButton({
  children,
  className = '',
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { children: ReactNode }) {
  return (
    <button
      className={`min-h-11 min-w-11 inline-flex items-center justify-center gap-2 rounded-xl transition-colors ${className}`}
      {...props}
    >
      {children}
    </button>
  )
}
