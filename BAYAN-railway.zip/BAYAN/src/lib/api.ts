import { NextResponse } from 'next/server'
import { getAuthUser } from '@/lib/auth'
import { db } from '@/lib/db'
import type { User } from '@prisma/client'

// ============================================================
// BAYAN | بیان — Helperهای مشترک API
// ============================================================

export function ok<T>(data: T, init?: ResponseInit) {
  return NextResponse.json(data as object, init)
}

export function err(message: string, status = 400, code?: string) {
  return NextResponse.json({ error: message, code }, { status })
}

export const unauthorized = () => err('برای این عملیات باید وارد حساب خود شوید', 401, 'UNAUTHORIZED')
export const forbidden = () => err('شما اجازه انجام این عملیات را ندارید', 403, 'FORBIDDEN')
export const notFound = (what = 'مورد') => err(`${what} پیدا نشد`, 404, 'NOT_FOUND')

/** کاربر واردشده یا پاسخ ۴۰۱ */
export async function requireUser(request: Request): Promise<User | NextResponse> {
  const user = await getAuthUser(request)
  if (!user) return unauthorized()
  return user
}

export function isResponse(x: unknown): x is NextResponse {
  return x instanceof NextResponse
}

/** اطلاعات عمومی کاربر — شماره تلفن هرگز در پاسخ عمومی نمی‌آید */
export function publicUser(u: {
  id: string
  name: string
  username: string
  bio?: string | null
  avatarUrl?: string | null
  role?: string
  createdAt?: Date
}) {
  return {
    id: u.id,
    name: u.name,
    username: u.username,
    bio: u.bio || '',
    avatarUrl: u.avatarUrl,
    role: u.role || 'USER',
    createdAt: u.createdAt,
  }
}

export function meUser(u: User) {
  return {
    id: u.id,
    phone: u.phone,
    name: u.name,
    username: u.username,
    bio: u.bio || '',
    avatarUrl: u.avatarUrl,
    role: u.role,
    status: u.status,
    isPhoneVerified: u.isPhoneVerified,
    trustedName: u.trustedName || '',
    trustedPhone: u.trustedPhone || '',
    fontScale: u.fontScale,
    highContrast: u.highContrast,
    privacyProfile: u.privacyProfile,
    privacyMessage: u.privacyMessage,
    createdAt: u.createdAt,
  }
}

/** افزودن هشتگ‌های پست */
export async function syncPostHashtags(postId: string, text: string) {
  const { extractHashtags } = await import('@/lib/persian')
  const tags = extractHashtags(text)
  await db.postHashtag.deleteMany({ where: { postId } })
  for (const tag of tags) {
    const normalized = tag.toLowerCase()
    const hashtag = await db.hashtag.upsert({
      where: { tag: normalized },
      update: {},
      create: { tag: normalized },
    })
    await db.postHashtag.create({ data: { postId, hashtagId: hashtag.id } }).catch(() => null)
  }
}

/** ایجاد اعلان داخلی (بدون خطا شکست می‌خورد) */
export async function notify(params: {
  userId: string
  actorId?: string
  type: string
  entityId?: string
  text: string
}) {
  if (params.actorId === params.userId) return // اعلان برای خودم لازم نیست
  await db.notification.create({ data: params }).catch(() => null)
}
