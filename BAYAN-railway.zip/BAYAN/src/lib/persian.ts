// ============================================================
// BAYAN | بیان — ابزارهای فارسی: نرمال‌سازی متن برای جست‌وجو
// یکسان‌سازی «ی/ي» و «ک/ك»، حذف اعراب و نیم‌فاصله
// ============================================================

const ARABIC_TO_PERSIAN: Record<string, string> = {
  'ي': 'ی', 'ك': 'ک', 'ۀ': 'ه', 'ة': 'ه', 'ؤ': 'و', 'إ': 'ا', 'أ': 'ا', 'ٱ': 'ا',
}

export function normalizePersian(text: string): string {
  let out = text
  for (const [from, to] of Object.entries(ARABIC_TO_PERSIAN)) {
    out = out.split(from).join(to)
  }
  out = out
    .replace(/[\u064B-\u065F\u0670]/g, '') // اعراب
    .replace(/\u200c/g, ' ') // نیم‌فاصله → فاصله
    .replace(/[ىي]/g, 'ی')
    .replace(/[كک]/g, 'ک')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase()
  return out
}

/** استخراج هشتگ‌ها از متن پست */
export function extractHashtags(text: string): string[] {
  const matches = text.match(/#([\w\u0600-\u06FF\u200c]+)/g) || []
  const tags = matches
    .map((m) => m.slice(1).replace(/[\u200c_]+$/g, '').trim())
    .filter((t) => t.length >= 2 && t.length <= 50)
  return Array.from(new Set(tags)).slice(0, 10)
}

const FA_MONTHS = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند']

/** تاریخ شمسی خوانا */
export function formatJalali(date: Date): string {
  try {
    return new Intl.DateTimeFormat('fa-IR', { year: 'numeric', month: 'long', day: 'numeric' }).format(date)
  } catch {
    return date.toLocaleDateString()
  }
}

/** زمان نسبی فارسی: «۵ دقیقه پیش» */
export function timeAgoFa(date: Date | string): string {
  const d = typeof date === 'string' ? new Date(date) : date
  const seconds = Math.floor((Date.now() - d.getTime()) / 1000)
  if (seconds < 60) return 'همین حالا'
  const minutes = Math.floor(seconds / 60)
  if (minutes < 60) return `${faNum(minutes)} دقیقه پیش`
  const hours = Math.floor(minutes / 60)
  if (hours < 24) return `${faNum(hours)} ساعت پیش`
  const days = Math.floor(hours / 24)
  if (days < 7) return `${faNum(days)} روز پیش`
  return formatJalali(d)
}

/** تبدیل ارقام به فارسی */
export function faNum(n: number | string): string {
  return String(n).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[Number(d)])
}

export function faCompact(n: number): string {
  if (n >= 1000000) return `${faNum((n / 1000000).toFixed(1))} م`
  if (n >= 1000) return `${faNum((n / 1000).toFixed(1))} هـ`
  return faNum(n)
}
