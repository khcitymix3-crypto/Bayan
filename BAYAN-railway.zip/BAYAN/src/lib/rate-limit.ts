// ============================================================
// BAYAN | بیان — محدودیت نرخ درخواست (In-Memory، سطح MVP)
// در استقرار تولیدی با Redis جایگزین می‌شود — در سند معماری ذکر شده
// ============================================================

const buckets = new Map<string, { count: number; resetAt: number }>()

// پاک‌سازی دوره‌ای برای جلوگیری از نشت حافظه
let lastCleanup = Date.now()
function cleanup() {
  if (Date.now() - lastCleanup < 60_000) return
  lastCleanup = Date.now()
  const now = Date.now()
  for (const [key, bucket] of buckets) {
    if (bucket.resetAt < now) buckets.delete(key)
  }
}

export interface RateLimitResult {
  ok: boolean
  remaining: number
  retryAfterSec: number
}

export function rateLimit(key: string, max: number, windowMs: number): RateLimitResult {
  cleanup()
  const now = Date.now()
  const bucket = buckets.get(key)
  if (!bucket || bucket.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs })
    return { ok: true, remaining: max - 1, retryAfterSec: 0 }
  }
  bucket.count++
  if (bucket.count > max) {
    return { ok: false, remaining: 0, retryAfterSec: Math.ceil((bucket.resetAt - now) / 1000) }
  }
  return { ok: true, remaining: max - bucket.count, retryAfterSec: 0 }
}

export function clientIp(request: Request): string {
  const fwd = request.headers.get('x-forwarded-for')
  if (fwd) return fwd.split(',')[0].trim()
  return request.headers.get('x-real-ip') || 'local'
}
