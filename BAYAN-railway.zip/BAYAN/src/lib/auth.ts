import { db } from '@/lib/db'
import { createHash, randomBytes, scryptSync, timingSafeEqual } from 'crypto'

// ============================================================
// BAYAN | بیان — کتابخانه احراز هویت و امنیت (سمت سرور)
// هش رمز: scrypt استاندارد Node — توکن نشست: تصادفی ۲۵۶بیتی
// توکن خام فقط در کوکی httpOnly؛ در دیتابیس فقط SHA-256 ذخیره می‌شود
// ============================================================

export const SESSION_COOKIE = 'bayan_session'
const SESSION_DAYS = 30

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex')
  const hash = scryptSync(password, salt, 64).toString('hex')
  return `scrypt$${salt}$${hash}`
}

export function verifyPassword(password: string, stored: string): boolean {
  try {
    const [algo, salt, hash] = stored.split('$')
    if (algo !== 'scrypt' || !salt || !hash) return false
    const candidate = scryptSync(password, salt, 64)
    const expected = Buffer.from(hash, 'hex')
    return candidate.length === expected.length && timingSafeEqual(candidate, expected)
  } catch {
    return false
  }
}

function sha256(value: string): string {
  return createHash('sha256').update(value).digest('hex')
}

export async function createSession(userId: string, device?: string, ip?: string) {
  const token = randomBytes(32).toString('hex')
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000)
  await db.session.create({
    data: { tokenHash: sha256(token), userId, device, ip, expiresAt },
  })
  return { token, expiresAt }
}

export async function destroySession(token: string) {
  await db.session.deleteMany({ where: { tokenHash: sha256(token) } })
}

export async function destroyAllSessions(userId: string) {
  await db.session.deleteMany({ where: { userId } })
}

/** کاربر جاری از روی کوکی نشست — null اگر نامعتبر */
export async function getAuthUser(request: Request) {
  const token = readSessionToken(request)
  if (!token) return null
  const session = await db.session.findUnique({
    where: { tokenHash: sha256(token) },
    include: { user: true },
  })
  if (!session) return null
  if (session.expiresAt < new Date()) {
    await db.session.delete({ where: { id: session.id } }).catch(() => null)
    return null
  }
  if (session.user.status === 'BLOCKED') return null
  return session.user
}

export async function getSessionInfo(request: Request) {
  const token = readSessionToken(request)
  if (!token) return null
  return db.session.findUnique({ where: { tokenHash: sha256(token) } })
}

function readSessionToken(request: Request): string | null {
  const cookieHeader = request.headers.get('cookie') || ''
  const match = cookieHeader.match(new RegExp(`${SESSION_COOKIE}=([^;]+)`))
  return match ? decodeURIComponent(match[1]) : null
}

export function sessionCookieHeader(token: string, expiresAt: Date) {
  const secure = process.env.NODE_ENV === 'production' ? ' Secure;' : ''
  return `${SESSION_COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax;${secure} Expires=${expiresAt.toUTCString()}`
}

export function clearSessionCookieHeader() {
  return `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`
}

/** نرمال‌سازی شماره موبایل ایران به فرمت +98 */
export function normalizePhone(raw: string): string | null {
  const digits = toEnglishDigits(raw.trim()).replace(/[\s-()]/g, '')
  let normalized = digits
  if (normalized.startsWith('0098')) normalized = '+98' + normalized.slice(4)
  else if (normalized.startsWith('098')) normalized = '+98' + normalized.slice(3)
  else if (normalized.startsWith('98') && normalized.length >= 12) normalized = '+' + normalized
  else if (normalized.startsWith('09')) normalized = '+98' + normalized.slice(1)
  else if (normalized.startsWith('9')) normalized = '+98' + normalized
  if (!/^\+989\d{9}$/.test(normalized)) return null
  return normalized
}

export function toEnglishDigits(s: string): string {
  return s.replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d))).replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
}

export function validateUsername(username: string): boolean {
  return /^[a-zA-Z0-9_]{3,24}$/.test(username)
}

export function validatePassword(password: string): boolean {
  return password.length >= 8 && password.length <= 72
}
