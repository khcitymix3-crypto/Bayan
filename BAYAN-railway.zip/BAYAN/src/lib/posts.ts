import { db } from '@/lib/db'
import { faNum } from '@/lib/persian'

// ============================================================
// BAYAN | بیان — سریالایز و شکل‌دهی داده پست برای کلاینت
// ============================================================

export interface PostWhereInputSafe {
  status?: string
  authorId?: string
  content?: { contains: string }
  OR?: Array<Record<string, unknown>>
  hashtags?: { some: { hashtag: { tag: string } } }
}

export function postInclude(meId?: string) {
  return {
    author: { select: { id: true, name: true, username: true, avatarUrl: true } },
    likes: meId ? { where: { userId: meId }, select: { id: true } } : false,
    bookmarks: meId ? { where: { userId: meId }, select: { id: true } } : false,
    _count: { select: { likes: true, comments: true } },
  } as const
}

type RawPost = {
  id: string
  content: string
  mediaType: string
  mediaId: string | null
  status: string
  likeCount: number
  commentCount: number
  viewCount: number
  createdAt: Date
  author: { id: string; name: string; username: string; avatarUrl: string | null }
  likes?: { id: string }[]
  bookmarks?: { id: string }[]
  _count: { likes: number; comments: number }
}

export function serializePost(p: RawPost) {
  return {
    id: p.id,
    content: p.content,
    mediaType: p.mediaType,
    mediaUrl: p.mediaId ? `/api/media/${p.mediaId}` : null,
    status: p.status,
    likeCount: p._count.likes,
    commentCount: p._count.comments,
    createdAt: p.createdAt,
    liked: p.likes ? p.likes.length > 0 : false,
    bookmarked: p.bookmarks ? p.bookmarks.length > 0 : false,
    author: p.author,
  }
}

export type SerializedPost = ReturnType<typeof serializePost>

/** ایجاد اعلان و به‌روزرسانی شمارنده پس از تغییر لایک */
export async function syncLikeCount(postId: string): Promise<number> {
  const count = await db.like.count({ where: { postId } })
  await db.post.update({ where: { id: postId }, data: { likeCount: count } })
  return count
}

export async function syncCommentCount(postId: string) {
  const count = await db.comment.count({ where: { postId, isHidden: false } })
  await db.post.update({ where: { id: postId }, data: { commentCount: count } })
}
