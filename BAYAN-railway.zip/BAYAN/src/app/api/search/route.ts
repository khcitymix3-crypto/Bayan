import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'
import { err } from '@/lib/api'
import { normalizePersian } from '@/lib/persian'

// ============================================================
// BAYAN | بیان — جست‌وجوی هوشمند با نرمال‌سازی فارسی (ی/ي ک/ك)
// استراتژی: کوئری گسترده در دیتابیس + فیلتر دقیق با متن نرمال‌شده
// MVP: محدود به ۲۰۰ ردیف — فاز ۲: ستون جست‌وجوی نرمال‌شده در دیتابیس
// tabs: users | posts | channels | hashtags
// ============================================================

export async function GET(request: NextRequest) {
  try {
    const me = await getAuthUser(request)
    const sp = request.nextUrl.searchParams
    const qRaw = (sp.get('q') || '').trim()
    const type = sp.get('type') || 'all'
    if (qRaw.length < 1) {
      return NextResponse.json({ users: [], posts: [], channels: [], hashtags: [] })
    }
    const q = normalizePersian(qRaw)

    const jobs: Promise<unknown>[] = []

    if (type === 'all' || type === 'users') {
      jobs.push(
        db.user
          .findMany({
            where: { status: 'ACTIVE' },
            select: { id: true, name: true, username: true, avatarUrl: true, bio: true },
            take: 300,
            orderBy: { createdAt: 'desc' },
          })
          .then((users) => ({
            users: users
              .filter(
                (u) =>
                  normalizePersian(u.name).includes(q) ||
                  u.username.toLowerCase().includes(qRaw.toLowerCase())
              )
              .slice(0, 10),
          }))
      )
    }

    if (type === 'all' || type === 'posts') {
      jobs.push(
        db.post
          .findMany({
            where: { status: 'PUBLISHED' },
            include: {
              author: { select: { id: true, name: true, username: true, avatarUrl: true } },
              _count: { select: { likes: true, comments: true } },
            },
            orderBy: { createdAt: 'desc' },
            take: 300,
          })
          .then((posts) => ({
            posts: posts
              .filter((p) => normalizePersian(p.content).includes(q))
              .slice(0, 10)
              .map((p) => ({
                id: p.id,
                content: p.content.length > 200 ? p.content.slice(0, 200) + '…' : p.content,
                mediaType: p.mediaType,
                mediaUrl: p.mediaId ? `/api/media/${p.mediaId}` : null,
                createdAt: p.createdAt,
                likeCount: p._count.likes,
                commentCount: p._count.comments,
                author: p.author,
              })),
          }))
      )
    }

    if (type === 'all' || type === 'channels') {
      jobs.push(
        db.conversation
          .findMany({
            where: { type: { in: ['CHANNEL', 'GROUP'] } },
            include: { _count: { select: { members: true } } },
            take: 100,
          })
          .then((channels) => ({
            channels: channels
              .filter((c) => c.title && normalizePersian(c.title + ' ' + (c.description || '')).includes(q))
              .slice(0, 10)
              .map((c) => ({
                id: c.id,
                type: c.type,
                title: c.title,
                description: c.description || '',
                membersCount: c._count.members,
              })),
          }))
      )
    }

    if (type === 'all' || type === 'hashtags') {
      jobs.push(
        db.hashtag
          .findMany({
            include: { _count: { select: { posts: { where: { post: { status: 'PUBLISHED' } } } } } },
            take: 200,
          })
          .then((hashtags) => ({
            hashtags: hashtags
              .filter((h) => h.tag.includes(q) && h._count.posts > 0)
              .sort((a, b) => b._count.posts - a._count.posts)
              .slice(0, 10)
              .map((h) => ({ tag: h.tag, postsCount: h._count.posts })),
          }))
      )
    }

    const results = await Promise.all(jobs)
    const merged = Object.assign({ users: [], posts: [], channels: [], hashtags: [] }, ...results)
    void me
    return NextResponse.json(merged)
  } catch (e) {
    console.error('search error', e)
    return err('خطا در جست‌وجو', 500)
  }
}
