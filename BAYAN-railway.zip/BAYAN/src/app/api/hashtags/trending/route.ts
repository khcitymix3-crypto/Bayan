import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// ============================================================
// BAYAN | بیان — هشتگ‌های پرطرفدار
// ============================================================

export async function GET() {
  try {
    const trending = await db.hashtag.findMany({
      include: {
        _count: {
          select: { posts: { where: { post: { status: 'PUBLISHED' } } } },
        },
      },
      orderBy: { posts: { _count: 'desc' } },
      take: 12,
    })

    return NextResponse.json({
      hashtags: trending
        .filter((h) => h._count.posts > 0)
        .map((h) => ({ tag: h.tag, postsCount: h._count.posts })),
    })
  } catch (e) {
    console.error('trending error', e)
    return NextResponse.json({ hashtags: [] })
  }
}
