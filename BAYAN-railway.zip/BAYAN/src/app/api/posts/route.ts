import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'
import { err, isResponse, ok, requireUser, syncPostHashtags } from '@/lib/api'
import { postInclude, serializePost } from '@/lib/posts'
import { clientIp, rateLimit } from '@/lib/rate-limit'

// ============================================================
// BAYAN | بیان — فید و ساخت پست
// tabs: foryou (عمومی) | following (دنبال‌شده‌ها) | user (پروفایل) | saved
// ============================================================

const PAGE_SIZE = 10

export async function GET(request: NextRequest) {
  try {
    const me = await getAuthUser(request)
    const sp = request.nextUrl.searchParams
    const tab = sp.get('tab') || 'foryou'
    const cursor = sp.get('cursor')
    const username = sp.get('username') || undefined

    let where: Record<string, unknown> = { status: 'PUBLISHED' }

    if (tab === 'following') {
      if (!me) return err('برای فید دنبال‌شده‌ها وارد شوید', 401)
      const follows = await db.follow.findMany({
        where: { followerId: me.id },
        select: { followingId: true },
      })
      const ids = follows.map((f) => f.followingId)
      ids.push(me.id)
      where = { status: 'PUBLISHED', authorId: { in: ids } }
    } else if (tab === 'user' && username) {
      where = { status: 'PUBLISHED', author: { username } }
    } else if (tab === 'hashtag' && sp.get('tag')) {
      where = { status: 'PUBLISHED', hashtags: { some: { hashtag: { tag: sp.get('tag')!.toLowerCase() } } } }
    } else if (tab === 'saved') {
      if (!me) return err('برای ذخیره‌شده‌ها وارد شوید', 401)
      where = { status: 'PUBLISHED', bookmarks: { some: { userId: me.id } } }
    }

    const posts = await db.post.findMany({
      where,
      include: postInclude(me?.id),
      orderBy: { createdAt: 'desc' },
      take: PAGE_SIZE + 1,
      ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
    })

    const hasMore = posts.length > PAGE_SIZE
    const page = hasMore ? posts.slice(0, PAGE_SIZE) : posts
    return NextResponse.json({
      posts: page.map(serializePost),
      nextCursor: hasMore ? page[page.length - 1].id : null,
    })
  } catch (e) {
    console.error('feed error', e)
    return err('خطا در دریافت فید', 500)
  }
}

export async function POST(request: NextRequest) {
  try {
    const auth = await requireUser(request)
    if (isResponse(auth)) return auth
    const rl = rateLimit(`post:${auth.id}`, 20, 10 * 60 * 1000)
    if (!rl.ok) return err('سرعت انتشار بیش از حد مجاز. کمی صبر کنید', 429)

    const body = await request.json().catch(() => null)
    if (!body) return err('درخواست نامعتبر است')

    const content = String(body.content || '').trim()
    const mediaType = ['TEXT', 'IMAGE'].includes(body.mediaType) ? body.mediaType : 'TEXT'
    const mediaId = typeof body.mediaId === 'string' && body.mediaId ? body.mediaId : null
    const status = body.status === 'DRAFT' ? 'DRAFT' : 'PUBLISHED'

    if (mediaType === 'TEXT' && content.length === 0) return err('متن پست خالی است')
    if (content.length > 5000) return err('متن پست حداکثر ۵۰۰۰ نویسه است')
    if (mediaType === 'IMAGE' && !mediaId) return err('تصویر پست یافت نشد')

    const post = await db.post.create({
      data: { authorId: auth.id, content, mediaType, mediaId, status },
      include: postInclude(auth.id),
    })
    await syncPostHashtags(post.id, content)

    return NextResponse.json({ post: serializePost(post) }, { status: 201 })
  } catch (e) {
    console.error('create post error', e)
    return err('خطا در ساخت پست', 500)
  }
}
