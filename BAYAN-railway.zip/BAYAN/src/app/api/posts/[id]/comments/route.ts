import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { err, isResponse, notify, requireUser } from '@/lib/api'
import { syncCommentCount } from '@/lib/posts'
import { clientIp, rateLimit } from '@/lib/rate-limit'

// ============================================================
// BAYAN | بیان — نظرات پست: فهرست و ثبت نظر / پاسخ به نظر
// ============================================================

export async function GET(request: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params
    const comments = await db.comment.findMany({
      where: { postId: id, isHidden: false },
      include: { author: { select: { id: true, name: true, username: true, avatarUrl: true } } },
      orderBy: { createdAt: 'asc' },
      take: 200,
    })
    return NextResponse.json({ comments: comments.map(serializeComment) })
  } catch (e) {
    console.error('comments list error', e)
    return err('خطا در دریافت نظرات', 500)
  }
}

function serializeComment(c: {
  id: string
  content: string
  parentId: string | null
  createdAt: Date
  author: { id: string; name: string; username: string; avatarUrl: string | null }
}) {
  return {
    id: c.id,
    content: c.content,
    parentId: c.parentId,
    createdAt: c.createdAt,
    author: c.author,
  }
}

export async function POST(request: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const auth = await requireUser(request)
    if (isResponse(auth)) return auth
    const { id } = await ctx.params
    const rl = rateLimit(`comment:${auth.id}:${clientIp(request)}`, 30, 10 * 60 * 1000)
    if (!rl.ok) return err('تعداد نظرها بیش از حد مجاز است', 429)

    const post = await db.post.findUnique({ where: { id }, select: { id: true, authorId: true, status: true } })
    if (!post || post.status !== 'PUBLISHED') return err('پست پیدا نشد', 404)

    const body = await request.json().catch(() => null)
    const content = String(body?.content || '').trim()
    const parentId = typeof body?.parentId === 'string' && body.parentId ? body.parentId : null
    if (content.length < 1 || content.length > 1000) return err('متن نظر باید بین ۱ تا ۱۰۰۰ نویسه باشد')

    if (parentId) {
      const parent = await db.comment.findUnique({ where: { id: parentId } })
      if (!parent || parent.postId !== id) return err('نظر اصلی پیدا نشد', 404)
    }

    const comment = await db.comment.create({
      data: { postId: id, authorId: auth.id, parentId, content },
      include: { author: { select: { id: true, name: true, username: true, avatarUrl: true } } },
    })
    await syncCommentCount(id)

    if (parentId) {
      const parent = await db.comment.findUnique({ where: { id: parentId }, select: { authorId: true } })
      if (parent) notify({ userId: parent.authorId, actorId: auth.id, type: 'REPLY', entityId: id, text: 'به نظر شما پاسخ داد' })
    } else {
      await notify({ userId: post.authorId, actorId: auth.id, type: 'COMMENT', entityId: id, text: 'به پست شما نظر داد' })
    }

    return NextResponse.json({ comment: serializeComment(comment) }, { status: 201 })
  } catch (e) {
    console.error('comment create error', e)
    return err('خطا در ثبت نظر', 500)
  }
}
