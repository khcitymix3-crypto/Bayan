import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { err, isResponse, requireUser } from '@/lib/api'

// ============================================================
// BAYAN | بیان — ذخیره / حذف از ذخیره‌شده‌ها (توگل)
// ============================================================

export async function POST(request: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const auth = await requireUser(request)
    if (isResponse(auth)) return auth
    const { id } = await ctx.params

    const post = await db.post.findUnique({ where: { id }, select: { id: true, status: true } })
    if (!post || post.status !== 'PUBLISHED') return err('پست پیدا نشد', 404)

    const existing = await db.bookmark.findUnique({
      where: { postId_userId: { postId: id, userId: auth.id } },
    })

    if (existing) {
      await db.bookmark.delete({ where: { id: existing.id } })
      return NextResponse.json({ bookmarked: false })
    }

    await db.bookmark.create({ data: { postId: id, userId: auth.id } })
    return NextResponse.json({ bookmarked: true })
  } catch (e) {
    console.error('bookmark error', e)
    return err('خطا در ذخیره پست', 500)
  }
}
