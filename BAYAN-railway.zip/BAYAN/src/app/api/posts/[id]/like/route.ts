import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { err, isResponse, notify, requireUser } from '@/lib/api'
import { syncLikeCount } from '@/lib/posts'

// ============================================================
// BAYAN | بیان — لایک / لغو لایک (توگل) + جلوگیری از ثبت تکراری
// ============================================================

export async function POST(request: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const auth = await requireUser(request)
    if (isResponse(auth)) return auth
    const { id } = await ctx.params

    const post = await db.post.findUnique({ where: { id }, select: { id: true, authorId: true, status: true } })
    if (!post || post.status !== 'PUBLISHED') return err('پست پیدا نشد', 404)

    const existing = await db.like.findUnique({
      where: { postId_userId: { postId: id, userId: auth.id } },
    })

    if (existing) {
      await db.like.delete({ where: { id: existing.id } })
      const likeCount = await syncLikeCount(id)
      return NextResponse.json({ liked: false, likeCount })
    }

    await db.like.create({ data: { postId: id, userId: auth.id } })
    const likeCount = await syncLikeCount(id)
    await notify({ userId: post.authorId, actorId: auth.id, type: 'LIKE', entityId: id, text: 'پست شما را پسندید' })
    return NextResponse.json({ liked: true, likeCount })
  } catch (e) {
    console.error('like error', e)
    return err('خطا در ثبت پسند', 500)
  }
}
