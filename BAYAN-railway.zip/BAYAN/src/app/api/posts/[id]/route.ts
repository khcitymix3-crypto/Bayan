import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'
import { err, forbidden, isResponse, ok, requireUser, syncPostHashtags, notify } from '@/lib/api'
import { postInclude, serializePost } from '@/lib/posts'

// ============================================================
// BAYAN | بیان — پست تکی: مشاهده / ویرایش / انتشار پیش‌نویس / حذف
// ============================================================

export async function GET(request: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params
    const me = await getAuthUser(request)
    const post = await db.post.findUnique({ where: { id }, include: postInclude(me?.id) })
    if (!post || post.status === 'DELETED') return err('پست پیدا نشد', 404)
    return NextResponse.json({ post: serializePost(post) })
  } catch (e) {
    console.error('get post error', e)
    return err('خطا در دریافت پست', 500)
  }
}

export async function PATCH(request: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const auth = await requireUser(request)
    if (isResponse(auth)) return auth
    const { id } = await ctx.params

    const post = await db.post.findUnique({ where: { id } })
    if (!post || post.status === 'DELETED') return err('پست پیدا نشد', 404)
    if (post.authorId !== auth.id) return forbidden()

    const body = await request.json().catch(() => null)
    if (!body) return err('درخواست نامعتبر است')

    const data: Record<string, unknown> = {}
    if (typeof body.content === 'string') {
      const content = body.content.trim()
      if (content.length === 0 || content.length > 5000) return err('متن پست نامعتبر است')
      data.content = content
    }
    if (body.status === 'PUBLISHED' && post.status === 'DRAFT') data.status = 'PUBLISHED'
    if (body.status === 'DRAFT' && post.status === 'PUBLISHED') data.status = 'DRAFT'

    const updated = await db.post.update({ where: { id }, data, include: postInclude(auth.id) })
    if (typeof data.content === 'string') await syncPostHashtags(id, String(data.content))
    return NextResponse.json({ post: serializePost(updated) })
  } catch (e) {
    console.error('patch post error', e)
    return err('خطا در ویرایش پست', 500)
  }
}

export async function DELETE(request: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const auth = await requireUser(request)
    if (isResponse(auth)) return auth
    const { id } = await ctx.params

    const post = await db.post.findUnique({ where: { id } })
    if (!post || post.status === 'DELETED') return err('پست پیدا نشد', 404)
    const isOwner = post.authorId === auth.id
    const isModerator = auth.role === 'ADMIN' || auth.role === 'MODERATOR'
    if (!isOwner && !isModerator) return forbidden()

    await db.post.update({ where: { id }, data: { status: 'DELETED' } })
    return ok({ ok: true })
  } catch (e) {
    console.error('delete post error', e)
    return err('خطا در حذف پست', 500)
  }
}
