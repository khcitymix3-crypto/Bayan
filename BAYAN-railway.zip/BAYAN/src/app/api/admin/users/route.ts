import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { destroyAllSessions } from '@/lib/auth'
import { err, forbidden, isResponse, ok, requireUser } from '@/lib/api'
import { normalizePersian } from '@/lib/persian'

// ============================================================
// BAYAN | بیان — مدیریت کاربران (مسدودسازی / نقش)
// تمام عملیات حساس در AdminLog ثبت می‌شود
// ============================================================

async function requireAdmin(request: NextRequest) {
  const auth = await requireUser(request)
  if (isResponse(auth)) return auth
  if (auth.role !== 'ADMIN') return forbidden()
  return auth
}

export async function GET(request: NextRequest) {
  try {
    const auth = await requireAdmin(request)
    if (isResponse(auth)) return auth

    const q = (request.nextUrl.searchParams.get('q') || '').trim()
    const users = await db.user.findMany({
      where: q ? { OR: [{ name: { contains: q } }, { username: { contains: q.toLowerCase() } }] } : {},
      select: { id: true, name: true, username: true, role: true, status: true, createdAt: true, phone: true },
      orderBy: { createdAt: 'desc' },
      take: 100,
    })

    return NextResponse.json({
      users: users.map((u) => ({
        ...u,
        // در پنل مدیریت، فقط ۴ رقم آخر شماره نمایش داده می‌شود
        phoneMasked: u.phone ? u.phone.slice(0, 4) + '***' + u.phone.slice(-4) : '',
      })),
    })
  } catch (e) {
    console.error('admin users error', e)
    return err('خطا در دریافت کاربران', 500)
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const admin = await requireAdmin(request)
    if (isResponse(admin)) return admin

    const body = await request.json().catch(() => null)
    const userId = String(body?.userId || '')
    const action = String(body?.action || '')
    if (!userId) return err('کاربر مشخص نیست')

    const target = await db.user.findUnique({ where: { id: userId } })
    if (!target) return err('کاربر پیدا نشد', 404)
    if (target.id === admin.id) return err('این عملیات روی حساب خودتان مجاز نیست')

    let actionLog = ''
    if (action === 'block') {
      await db.user.update({ where: { id: userId }, data: { status: 'BLOCKED' } })
      await destroyAllSessions(userId) // خروج فوری از همه دستگاه‌ها
      actionLog = 'BLOCK_USER'
    } else if (action === 'unblock') {
      await db.user.update({ where: { id: userId }, data: { status: 'ACTIVE' } })
      actionLog = 'UNBLOCK_USER'
    } else if (action === 'promote') {
      if (admin.role !== 'ADMIN') return forbidden()
      await db.user.update({ where: { id: userId }, data: { role: 'MODERATOR' } })
      actionLog = 'PROMOTE_MODERATOR'
    } else if (action === 'demote') {
      if (admin.role !== 'ADMIN') return forbidden()
      await db.user.update({ where: { id: userId }, data: { role: 'USER' } })
      actionLog = 'DEMOTE_USER'
    } else {
      return err('عملیات نامعتبر است')
    }

    await db.adminLog.create({
      data: {
        adminId: admin.id,
        action: actionLog,
        targetType: 'USER',
        targetId: userId,
        meta: `target=${target.username}`,
      },
    })

    return ok({ ok: true })
  } catch (e) {
    console.error('admin user patch error', e)
    return err('خطا در عملیات مدیریتی', 500)
  }
}
