import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { err, forbidden, isResponse, requireUser } from '@/lib/api'

// ============================================================
// BAYAN | بیان — آمار داشبورد مدیریت (فقط ADMIN/MODERATOR)
// ============================================================

async function requireAdmin(request: NextRequest) {
  const auth = await requireUser(request)
  if (isResponse(auth)) return auth
  if (!['ADMIN', 'MODERATOR'].includes(auth.role)) return forbidden()
  return auth
}

export async function GET(request: NextRequest) {
  try {
    const auth = await requireAdmin(request)
    if (isResponse(auth)) return auth

    const [users, posts, comments, messages, businesses, reportsNew, blocked, media] = await Promise.all([
      db.user.count(),
      db.post.count({ where: { status: 'PUBLISHED' } }),
      db.comment.count({ where: { isHidden: false } }),
      db.message.count({ where: { isDeleted: false } }),
      db.business.count(),
      db.report.count({ where: { status: 'NEW' } }),
      db.user.count({ where: { status: 'BLOCKED' } }),
      db.media.count(),
    ])

    const recentUsers = await db.user.findMany({
      orderBy: { createdAt: 'desc' },
      take: 5,
      select: { id: true, name: true, username: true, createdAt: true },
    })

    return NextResponse.json({
      stats: { users, posts, comments, messages, businesses, reportsNew, blocked, media },
      recentUsers,
    })
  } catch (e) {
    console.error('admin stats error', e)
    return err('خطا در آمار مدیریت', 500)
  }
}
