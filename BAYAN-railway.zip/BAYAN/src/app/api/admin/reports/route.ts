import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { err, forbidden, isResponse, ok, requireUser } from '@/lib/api'

// ============================================================
// BAYAN | بیان — بررسی گزارش‌های تخلف
// وضعیت: NEW / REVIEWING / RESOLVED / CLOSED
// ============================================================

const STATUSES = ['NEW', 'REVIEWING', 'RESOLVED', 'CLOSED']

async function requireAdmin(request: NextRequest) {
  const auth = await requireUser(request)
  if (isResponse(auth)) return auth
  if (!['ADMIN', 'MODERATOR'].includes(auth.role)) return forbidden()
  return auth
}

export async function GET(request: NextRequest) {
  try {
    const admin = await requireAdmin(request)
    if (isResponse(admin)) return admin

    const reports = await db.report.findMany({
      include: { reporter: { select: { id: true, name: true, username: true } } },
      orderBy: { createdAt: 'desc' },
      take: 100,
    })

    // تفسیر هدف گزارش
    const enriched = await Promise.all(
      reports.map(async (r) => {
        let preview = '—'
        if (r.targetType === 'POST') {
          const p = await db.post.findUnique({ where: { id: r.targetId }, select: { content: true, status: true } })
          preview = p ? `${p.content.slice(0, 80)} [${p.status}]` : 'پست حذف‌شده'
        } else if (r.targetType === 'USER') {
          const u = await db.user.findUnique({ where: { id: r.targetId }, select: { username: true } })
          preview = u ? `کاربر: @${u.username}` : '—'
        } else if (r.targetType === 'COMMENT') {
          const c = await db.comment.findUnique({ where: { id: r.targetId }, select: { content: true } })
          preview = c ? c.content.slice(0, 80) : '—'
        }
        return {
          id: r.id,
          targetType: r.targetType,
          targetId: r.targetId,
          targetPreview: preview,
          reason: r.reason,
          details: r.details || '',
          status: r.status,
          createdAt: r.createdAt,
          reporter: r.reporter,
        }
      })
    )

    return NextResponse.json({ reports: enriched })
  } catch (e) {
    console.error('admin reports error', e)
    return err('خطا در دریافت گزارش‌ها', 500)
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const admin = await requireAdmin(request)
    if (isResponse(admin)) return admin

    const body = await request.json().catch(() => null)
    const reportId = String(body?.reportId || '')
    const status = String(body?.status || '')
    if (!reportId) return err('گزارش مشخص نیست')
    if (!STATUSES.includes(status)) return err('وضعیت نامعتبر است')

    await db.report.update({
      where: { id: reportId },
      data: { status, resolvedAt: ['RESOLVED', 'CLOSED'].includes(status) ? new Date() : null },
    })

    await db.adminLog.create({
      data: { adminId: admin.id, action: `REPORT_${status}`, targetType: 'REPORT', targetId: reportId },
    })

    return ok({ ok: true })
  } catch (e) {
    console.error('admin report patch error', e)
    return err('خطا در به‌روزرسانی گزارش', 500)
  }
}
