import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { err, forbidden, isResponse, ok, requireUser } from '@/lib/api'
import { postInclude, serializePost } from '@/lib/posts'

// ============================================================
// BAYAN | بیان — مدیریت محتوا: پنهان‌سازی و حذف پست‌ها
// ============================================================

async function requireAdmin(request: NextRequest) {
  const auth = await requireUser(request)
  if (isResponse(auth)) return auth
  if (!['ADMIN', 'MODERATOR'].includes(auth.role)) return forbidden()
  return auth
}

export async function GET(request: NextRequest) {
  try {
    const auth = await requireAdmin(request)
    if (isResponse(auth)) return auth

    const posts = await db.post.findMany({
      where: { status: { in: ['PUBLISHED', 'HIDDEN'] } },
      include: postInclude(),
      orderBy: { createdAt: 'desc' },
      take: 50,
    })

    return NextResponse.json({ posts: posts.map(serializePost) })
  } catch (e) {
    console.error('admin posts error', e)
    return err('خطا در دریافت پست‌ها', 500)
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const admin = await requireAdmin(request)
    if (isResponse(admin)) return admin

    const body = await request.json().catch(() => null)
    const postId = String(body?.postId || '')
    const action = String(body?.action || '')
    if (!postId) return err('پست مشخص نیست')

    const post = await db.post.findUnique({ where: { id: postId } })
    if (!post) return err('پست پیدا نشد', 404)

    if (action === 'hide') {
      await db.post.update({ where: { id: postId }, data: { status: 'HIDDEN' } })
    } else if (action === 'unhide') {
      await db.post.update({ where: { id: postId }, data: { status: 'PUBLISHED' } })
    } else {
      return err('عملیات نامعتبر است')
    }

    await db.adminLog.create({
      data: { adminId: admin.id, action: action === 'hide' ? 'HIDE_POST' : 'UNHIDE_POST', targetType: 'POST', targetId: postId },
    })

    return ok({ ok: true })
  } catch (e) {
    console.error('admin post patch error', e)
    return err('خطا در عملیات مدیریتی', 500)
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const admin = await requireAdmin(request)
    if (isResponse(admin)) return admin

    const postId = request.nextUrl.searchParams.get('id') || ''
    if (!postId) return err('پست مشخص نیست')

    await db.post.updateMany({ where: { id: postId }, data: { status: 'DELETED' } })
    await db.adminLog.create({
      data: { adminId: admin.id, action: 'DELETE_POST', targetType: 'POST', targetId: postId },
    })

    return ok({ ok: true })
  } catch (e) {
    console.error('admin post delete error', e)
    return err('خطا در حذف پست', 500)
  }
}
