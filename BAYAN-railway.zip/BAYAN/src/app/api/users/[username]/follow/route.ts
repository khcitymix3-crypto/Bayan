import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { err, isResponse, notify, notFound, requireUser } from '@/lib/api'

// ============================================================
// BAYAN | بیان — دنبال‌کردن / لغو دنبال‌کردن (توگل)
// ============================================================

export async function POST(request: NextRequest, ctx: { params: Promise<{ username: string }> }) {
  try {
    const auth = await requireUser(request)
    if (isResponse(auth)) return auth
    const { username } = await ctx.params

    const target = await db.user.findUnique({ where: { username } })
    if (!target || target.status === 'BLOCKED') return notFound('کاربر')
    if (target.id === auth.id) return err('نمی‌توانید خودتان را دنبال کنید')

    const existing = await db.follow.findUnique({
      where: { followerId_followingId: { followerId: auth.id, followingId: target.id } },
    })

    if (existing) {
      await db.follow.delete({ where: { id: existing.id } })
      return NextResponse.json({ isFollowing: false })
    }

    await db.follow.create({ data: { followerId: auth.id, followingId: target.id } })
    await notify({ userId: target.id, actorId: auth.id, type: 'FOLLOW', text: 'شما را دنبال کرد' })
    return NextResponse.json({ isFollowing: true })
  } catch (e) {
    console.error('follow error', e)
    return err('خطا در دنبال‌کردن', 500)
  }
}
