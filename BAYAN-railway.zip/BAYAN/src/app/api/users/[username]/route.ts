import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'
import { err, notFound } from '@/lib/api'

// ============================================================
// BAYAN | بیان — پروفایل عمومی کاربر
// شماره تلفن در پاسخ عمومی هرگز نمی‌آید (قانون حریم خصوصی)
// ============================================================

export async function GET(request: NextRequest, ctx: { params: Promise<{ username: string }> }) {
  try {
    const { username } = await ctx.params
    const me = await getAuthUser(request)

    const user = await db.user.findUnique({ where: { username } })
    if (!user || user.status === 'BLOCKED') return notFound('کاربر')

    const [postsCount, followersCount, followingCount, isFollowing] = await Promise.all([
      db.post.count({ where: { authorId: user.id, status: 'PUBLISHED' } }),
      db.follow.count({ where: { followingId: user.id } }),
      db.follow.count({ where: { followerId: user.id } }),
      me
        ? db.follow.findFirst({ where: { followerId: me.id, followingId: user.id } })
        : Promise.resolve(null),
    ])

    return NextResponse.json({
      profile: {
        id: user.id,
        name: user.name,
        username: user.username,
        bio: user.bio || '',
        avatarUrl: user.avatarUrl,
        createdAt: user.createdAt,
        postsCount,
        followersCount,
        followingCount,
        isFollowing: !!isFollowing,
        isMe: me?.id === user.id,
      },
    })
  } catch (e) {
    console.error('profile error', e)
    return err('خطا در دریافت پروفایل', 500)
  }
}
