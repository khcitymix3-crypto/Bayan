import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { normalizePhone } from '@/lib/auth'
import { clientIp, rateLimit } from '@/lib/rate-limit'
import { err } from '@/lib/api'

// ============================================================
// BAYAN | بیان — صدور کد یکبارمصرف (OTP)
// حالت دمو: کد در پاسخ برگردانده می‌شود؛ در فاز ۲ با درگاه SMS واقعی
// ============================================================

export async function POST(request: NextRequest) {
  try {
    const ip = clientIp(request)
    const rl = rateLimit(`otp:${ip}`, 8, 10 * 60 * 1000)
    if (!rl.ok) return err('درخواست کد بیش از حد مجاز. چند دقیقه صبر کنید', 429)

    const body = await request.json().catch(() => null)
    const phone = normalizePhone(String(body?.phone || ''))
    if (!phone) return err('شماره موبایل معتبر نیست')

    // حداکثر ۳ کد در ۱۰ دقیقه برای هر شماره
    const recent = await db.otpCode.count({
      where: { phone, createdAt: { gt: new Date(Date.now() - 10 * 60 * 1000) } },
    })
    if (recent >= 3) return err('برای این شماره به‌تازگی کد صادر شده است', 429)

    const code = String(Math.floor(100000 + Math.random() * 900000))
    await db.otpCode.create({
      data: {
        phone,
        code,
        purpose: 'REGISTER',
        expiresAt: new Date(Date.now() + 5 * 60 * 1000),
      },
    })

    // حالت دمو — در تولید: ارسال با SMS Provider و عدم بازگشت کد در پاسخ
    return NextResponse.json({ ok: true, demoCode: code, message: 'کد تأیید ارسال شد (حالت دمو)' })
  } catch (e) {
    console.error('otp error', e)
    return err('خطای سرور در صدور کد', 500)
  }
}
