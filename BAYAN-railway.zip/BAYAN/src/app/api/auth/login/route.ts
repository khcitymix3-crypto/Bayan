import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { createSession, normalizePhone, sessionCookieHeader, verifyPassword } from '@/lib/auth'
import { clientIp, rateLimit } from '@/lib/rate-limit'
import { err, meUser } from '@/lib/api'

// ============================================================
// BAYAN | بیان — ورود با شماره و رمز + محدودیت تلاش ناموفق
// ============================================================

const MAX_FAILED_ATTEMPTS = 5
const LOCK_MINUTES = 15

export async function POST(request: NextRequest) {
  try {
    const ip = clientIp(request)
    const rl = rateLimit(`login:${ip}`, 15, 5 * 60 * 1000)
    if (!rl.ok) return err('تلاش‌های ورود بیش از حد مجاز. کمی صبر کنید', 429)

    const body = await request.json().catch(() => null)
    const phone = normalizePhone(String(body?.phone || ''))
    const password = String(body?.password || '')
    if (!phone || !password) return err('شماره موبایل و رمز عبور را وارد کنید')

    // قفل پس از تلاش‌های ناموفق
    const failed = await db.loginAttempt.count({
      where: {
        phone,
        success: false,
        createdAt: { gt: new Date(Date.now() - LOCK_MINUTES * 60 * 1000) },
      },
    })
    if (failed >= MAX_FAILED_ATTEMPTS) {
      return err(`حساب موقتاً قفل شده است. ${LOCK_MINUTES} دقیقه دیگر تلاش کنید`, 429)
    }

    const user = await db.user.findUnique({ where: { phone } })
    const valid = user ? verifyPassword(password, user.passwordHash) : false

    await db.loginAttempt.create({ data: { phone, ip, success: valid } })

    if (!user || !valid) return err('شماره موبایل یا رمز عبور اشتباه است', 401)
    if (user.status === 'BLOCKED') return err('حساب شما مسدود شده است. با پشتیبانی تماس بگیرید', 403)

    const session = await createSession(user.id, request.headers.get('user-agent') || undefined, ip)
    const response = NextResponse.json({ user: meUser(user) })
    response.headers.set('Set-Cookie', sessionCookieHeader(session.token, session.expiresAt))
    return response
  } catch (e) {
    console.error('login error', e)
    return err('خطای سرور در ورود', 500)
  }
}
