import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import {
  createSession,
  hashPassword,
  normalizePhone,
  sessionCookieHeader,
  validatePassword,
  validateUsername,
  verifyPassword,
} from '@/lib/auth'
import { clientIp, rateLimit } from '@/lib/rate-limit'
import { err, meUser } from '@/lib/api'

// ============================================================
// BAYAN | بیان — API احراز هویت: ثبت‌نام با OTP
// حالت دمو: کد یکبارمصرف در پاسخ نمایش داده می‌شود (درگاه SMS در فاز ۲)
// ============================================================

export async function POST(request: NextRequest) {
  try {
    const ip = clientIp(request)
    const rl = rateLimit(`register:${ip}`, 10, 10 * 60 * 1000)
    if (!rl.ok) return err('تلاش‌های بیش از حد. لطفاً بعداً دوباره امتحان کنید', 429)

    const body = await request.json().catch(() => null)
    if (!body) return err('درخواست نامعتبر است')

    const name = String(body.name || '').trim()
    const username = String(body.username || '').trim().toLowerCase()
    const phone = normalizePhone(String(body.phone || ''))
    const password = String(body.password || '')
    const otpCode = String(body.otpCode || '').trim()

    // اعتبارسنجی ورودی‌ها
    if (name.length < 2 || name.length > 50) return err('نام باید بین ۲ تا ۵۰ حرف باشد')
    if (!validateUsername(username))
      return err('نام کاربری باید ۳ تا ۲۴ نویسه انگلیسی، عدد یا _ باشد')
    if (!phone) return err('شماره موبایل معتبر نیست. نمونه: ۰۹۱۲۳۴۵۶۷۸۹')
    if (!validatePassword(password))
      return err('رمز عبور باید حداقل ۸ نویسه باشد')
    if (!/^\d{6}$/.test(otpCode)) return err('کد تأیید ۶ رقمی را وارد کنید')

    // یکتایی نام کاربری و شماره
    const [existingUsername, existingPhone] = await Promise.all([
      db.user.findUnique({ where: { username } }),
      db.user.findUnique({ where: { phone } }),
    ])
    if (existingUsername) return err('این نام کاربری قبلاً گرفته شده است')
    if (existingPhone) return err('با این شماره قبلاً حساب ساخته شده است. وارد شوید')

    // بررسی کد یکبارمصرف
    const otp = await db.otpCode.findFirst({
      where: { phone, purpose: 'REGISTER', used: false, expiresAt: { gt: new Date() } },
      orderBy: { createdAt: 'desc' },
    })
    if (!otp) return err('کد تأیید منقضی شده است. کد جدید بگیرید')
    if (otp.attempts >= 5) return err('تلاش‌های نامعتبر زیاد است. کد جدید بگیرید')
    if (otp.code !== otpCode) {
      await db.otpCode.update({ where: { id: otp.id }, data: { attempts: { increment: 1 } } })
      return err('کد تأیید اشتباه است')
    }
    await db.otpCode.update({ where: { id: otp.id }, data: { used: true } })

    // ساخت کاربر و نشست
    const user = await db.user.create({
      data: { name, username, phone, passwordHash: hashPassword(password), isPhoneVerified: true },
    })
    const session = await createSession(user.id, request.headers.get('user-agent') || undefined, ip)
    await db.notification.create({
      data: {
        userId: user.id,
        type: 'SYSTEM',
        text: 'به BAYAN | بیان خوش آمدید! پروفایل خود را کامل کنید و اولین پستتان را بگذارید.',
      },
    })

    const response = NextResponse.json({ user: meUser(user) }, { status: 201 })
    response.headers.set('Set-Cookie', sessionCookieHeader(session.token, session.expiresAt))
    return response
  } catch (e) {
    console.error('register error', e)
    return err('خطای سرور در ثبت‌نام', 500)
  }
}
