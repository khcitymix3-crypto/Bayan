import { NextRequest, NextResponse } from 'next/server'
import { clearSessionCookieHeader, destroySession } from '@/lib/auth'
import { ok } from '@/lib/api'

// ============================================================
// BAYAN | بیان — خروج از حساب (حذف نشست جاری)
// ============================================================

function rawToken(request: NextRequest): string | null {
  const cookie = request.headers.get('cookie') || ''
  const m = cookie.match(/bayan_session=([^;]+)/)
  return m ? decodeURIComponent(m[1]) : null
}

export async function POST(request: NextRequest) {
  const token = rawToken(request)
  if (token) await destroySession(token).catch(() => null)
  const response = NextResponse.json({ ok: true })
  response.headers.set('Set-Cookie', clearSessionCookieHeader())
  return response
}
