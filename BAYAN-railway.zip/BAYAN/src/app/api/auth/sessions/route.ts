import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { createHash } from 'crypto'
import { destroyAllSessions, getSessionInfo } from '@/lib/auth'
import { err, forbidden, isResponse, ok, requireUser } from '@/lib/api'

// ============================================================
// BAYAN | بیان — مدیریت دستگاه‌های واردشده (نشست‌های فعال)
// ============================================================

export async function GET(request: NextRequest) {
  const auth = await requireUser(request)
  if (isResponse(auth)) return auth
  const current = await getSessionInfo(request)

  const sessions = await db.session.findMany({
    where: { userId: auth.id, expiresAt: { gt: new Date() } },
    orderBy: { createdAt: 'desc' },
  })

  return NextResponse.json({
    sessions: sessions.map((s) => ({
      id: s.id,
      device: s.device || 'دستگاه ناشناس',
      createdAt: s.createdAt,
      expiresAt: s.expiresAt,
      isCurrent: current ? s.id === current.id : false,
    })),
  })
}

/** خروج از همه دستگاه‌های دیگر */
export async function DELETE(request: NextRequest) {
  const auth = await requireUser(request)
  if (isResponse(auth)) return auth
  const current = await getSessionInfo(request)
  if (current) {
    await db.session.deleteMany({
      where: { userId: auth.id, id: { not: current.id } },
    })
  }
  return ok({ ok: true, message: 'از همه دستگاه‌های دیگر خارج شدید' })
}
