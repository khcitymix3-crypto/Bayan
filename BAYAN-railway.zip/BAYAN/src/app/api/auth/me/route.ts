import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'
import { err, isResponse, meUser, requireUser } from '@/lib/api'

// ============================================================
// BAYAN | بیان — اطلاعات من / ویرایش پروفایل و تنظیمات
// ============================================================

export async function GET(request: NextRequest) {
  const user = await getAuthUser(request)
  if (!user) return NextResponse.json({ user: null })
  const unread = await db.notification.count({ where: { userId: user.id, isRead: false } })
  return NextResponse.json({ user: meUser(user), unread })
}

export async function PATCH(request: NextRequest) {
  const auth = await requireUser(request)
  if (isResponse(auth)) return auth
  const me = auth

  try {
    const body = await request.json().catch(() => null)
    if (!body) return err('درخواست نامعتبر است')

    const data: Record<string, unknown> = {}

    if (typeof body.name === 'string') {
      const name = body.name.trim()
      if (name.length < 2 || name.length > 50) return err('نام باید بین ۲ تا ۵۰ حرف باشد')
      data.name = name
    }
    if (typeof body.bio === 'string') {
      if (body.bio.length > 300) return err('معرفی حداکثر ۳۰۰ نویسه است')
      data.bio = body.bio.trim()
    }
    if (typeof body.avatarUrl === 'string') {
      if (body.avatarUrl.length > 500) return err('آدرس تصویر نامعتبر است')
      data.avatarUrl = body.avatarUrl || null
    }
    if (typeof body.trustedName === 'string' && typeof body.trustedPhone === 'string') {
      data.trustedName = body.trustedName.trim() || null
      data.trustedPhone = body.trustedPhone.trim() || null
    }
    if (typeof body.fontScale === 'number' && body.fontScale >= 0.8 && body.fontScale <= 1.5) {
      data.fontScale = body.fontScale
    }
    if (typeof body.highContrast === 'boolean') data.highContrast = body.highContrast
    if (
      typeof body.privacyProfile === 'string' &&
      ['EVERYONE', 'FOLLOWERS', 'NOBODY'].includes(body.privacyProfile)
    ) {
      data.privacyProfile = body.privacyProfile
    }
    if (
      typeof body.privacyMessage === 'string' &&
      ['EVERYONE', 'FOLLOWERS', 'NOBODY'].includes(body.privacyMessage)
    ) {
      data.privacyMessage = body.privacyMessage
    }

    if (Object.keys(data).length === 0) return err('تغییری ارسال نشده است')

    const updated = await db.user.update({ where: { id: me.id }, data })
    return NextResponse.json({ user: meUser(updated) })
  } catch (e) {
    console.error('me patch error', e)
    return err('خطای سرور در ذخیره تنظیمات', 500)
  }
}
