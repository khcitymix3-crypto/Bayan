import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { err, forbidden, isResponse, ok, requireUser } from '@/lib/api'
import { syncCommentCount } from '@/lib/posts'

// ============================================================
// BAYAN | بیان — حذف نظر (نویسنده نظر / نویسنده پست / مدیر)
// ============================================================

export async function DELETE(request: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const auth = await requireUser(request)
    if (isResponse(auth)) return auth
    const { id } = await ctx.params

    const comment = await db.comment.findUnique({ where: { id }, include: { post: { select: { authorId: true } } } })
    if (!comment || comment.isHidden) return err('نظر پیدا نشد', 404)

    const canDelete =
      comment.authorId === auth.id ||
      comment.post.authorId === auth.id ||
      auth.role === 'ADMIN' ||
      auth.role === 'MODERATOR'
    if (!canDelete) return forbidden()

    // حذف نرم + حذف پاسخ‌ها
    await db.comment.updateMany({ where: { parentId: id }, data: { isHidden: true } })
    await db.comment.update({ where: { id }, data: { isHidden: true } })
    await syncCommentCount(comment.postId)

    return ok({ ok: true })
  } catch (e) {
    console.error('comment delete error', e)
    return err('خطا در حذف نظر', 500)
  }
}
