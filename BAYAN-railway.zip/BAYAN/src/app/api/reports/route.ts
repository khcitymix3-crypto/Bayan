import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { err, isResponse, requireUser } from '@/lib/api'
import { clientIp, rateLimit } from '@/lib/rate-limit'

// ============================================================
// BAYAN | بیان — گزارش محتوا توسط کاربران
// وضعیت: NEW / REVIEWING / RESOLVED / CLOSED — بررسی در پنل مدیریت
// ============================================================

const REASONS = ['SPAM', 'ABUSE', 'SCAM', 'FAKE', 'ILLEGAL', 'CHILD_SAFETY', 'OTHER']
const TARGETS = ['POST', 'COMMENT', 'USER', 'MESSAGE']

export async function POST(request: NextRequest) {
  try {
    const auth = await requireUser(request)
    if (isResponse(auth)) return auth

    const rl = rateLimit(`report:${auth.id}:${clientIp(request)}`, 10, 60 * 60 * 1000)
    if (!rl.ok) return err('گزارش‌های زیادی ارسال کرده‌اید. بعداً تلاش کنید', 429)

    const body = await request.json().catch(() => null)
    const targetType = String(body?.targetType || '')
    const targetId = String(body?.targetId || '')
    const reason = String(body?.reason || '')
    const details = String(body?.details || '').slice(0, 500)

    if (!TARGETS.includes(targetType)) return err('نوع محتوای گزارش نامعتبر است')
    if (!targetId) return err('شناسه محتوا مشخص نیست')
    if (!REASONS.includes(reason)) return err('دلیل گزارش نامعتبر است')

    // بررسی وجود محتوای هدف
    let exists = false
    if (targetType === 'POST') exists = !!(await db.post.findUnique({ where: { id: targetId } }))
    else if (targetType === 'COMMENT') exists = !!(await db.comment.findUnique({ where: { id: targetId } }))
    else if (targetType === 'USER') exists = !!(await db.user.findUnique({ where: { id: targetId } }))
    else if (targetType === 'MESSAGE') exists = !!(await db.message.findUnique({ where: { id: targetId } }))
    if (!exists) return err('محتوای گزارش‌شده پیدا نشد', 404)

    await db.report.create({
      data: { reporterId: auth.id, targetType, targetId, reason, details },
    })

    return NextResponse.json({ ok: true, message: 'گزارش شما ثبت شد و بررسی خواهد شد' }, { status: 201 })
  } catch (e) {
    console.error('report error', e)
    return err('خطا در ثبت گزارش', 500)
  }
}
