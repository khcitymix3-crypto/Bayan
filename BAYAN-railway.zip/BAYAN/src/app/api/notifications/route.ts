import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { err, isResponse, ok, requireUser } from '@/lib/api'

// ============================================================
// BAYAN | بیان — اعلان‌ها: فهرست + علامت‌گذاری خوانده‌شده
// ============================================================

export async function GET(request: NextRequest) {
  try {
    const auth = await requireUser(request)
    if (isResponse(auth)) return auth

    const notifications = await db.notification.findMany({
      where: { userId: auth.id },
      include: { actor: { select: { id: true, name: true, username: true, avatarUrl: true } } },
      orderBy: { createdAt: 'desc' },
      take: 50,
    })

    const unread = await db.notification.count({ where: { userId: auth.id, isRead: false } })

    return NextResponse.json({
      notifications: notifications.map((n) => ({
        id: n.id,
        type: n.type,
        text: n.text,
        entityId: n.entityId,
        isRead: n.isRead,
        createdAt: n.createdAt,
        actor: n.actor,
      })),
      unread,
    })
  } catch (e) {
    console.error('notifications error', e)
    return err('خطا در دریافت اعلان‌ها', 500)
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const auth = await requireUser(request)
    if (isResponse(auth)) return auth

    const body = await request.json().catch(() => ({}))
    if (Array.isArray(body.ids) && body.ids.length > 0) {
      await db.notification.updateMany({
        where: { userId: auth.id, id: { in: body.ids.slice(0, 100) } },
        data: { isRead: true },
      })
    } else {
      await db.notification.updateMany({ where: { userId: auth.id, isRead: false }, data: { isRead: true } })
    }
    return ok({ ok: true })
  } catch (e) {
    console.error('notifications read error', e)
    return err('خطا در به‌روزرسانی اعلان‌ها', 500)
  }
}
