import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'
import { err, isResponse, requireUser } from '@/lib/api'
import { clientIp, rateLimit } from '@/lib/rate-limit'

// ============================================================
// BAYAN | بیان — دستیار هوش مصنوعی (سمت سرور فقط)
// قابلیت MVP: گفت‌وگوی متنی، خلاصه‌سازی، ترجمه، کمک به نوشتن
// فاز ۲: صوت، توضیح تصویر، کنترل صوتی برنامه
// ============================================================

const SYSTEM_PROMPT = `تو «بیان» (BAYAN AI) هستی، دستیار هوشمند پلتفرم اجتماعی بیان.
ویژگی‌های تو:
- همیشه فارسی روان و محترمانه پاسخ بده (مگر اینکه کاربر به زبان دیگری بنویسد)
- کوتاه، مفید و دقیق پاسخ بده؛ از پاسخ‌های طولانی بی‌دلیل پرهیز کن
- در کمک به نوشتن متن، خلاصه‌سازی، ترجمه، ایده‌پردازی و پاسخ به پرسش‌های عمومی مهارت داری
- اطلاعات خصوصی کاربران را نمی‌خواهی و توصیه‌های امنیتی درست می‌دهی
- برای موضوعات اضطراری، همیشه شماره‌های رسمی اضطراری کشور کاربر را یادآوری می‌کنی (در ایران: ۱۱۵ اورژانس، ۱۱۰ پلیس، ۱۲۵ آتش‌نشانی)
- هرگز محتوای غیرقانونی، آزارگرانه یا خطرناک تولید نمی‌کنی`

export async function POST(request: NextRequest) {
  try {
    const auth = await requireUser(request)
    if (isResponse(auth)) return auth

    const rl = rateLimit(`ai:${auth.id}:${clientIp(request)}`, 20, 10 * 60 * 1000)
    if (!rl.ok) return err('سقف استفاده از هوش مصنوعی موقتاً پر شده است. چند دقیقه صبر کنید', 429)

    const body = await request.json().catch(() => null)
    const messages = Array.isArray(body?.messages) ? body.messages : null
    if (!messages || messages.length === 0) return err('پیامی ارسال نشده است')

    // محدودسازی تاریخچه به ۱۲ پیام آخر + اعتبارسنجی
    const safeMessages = messages
      .slice(-12)
      .filter((m: { role?: string; content?: string }) => m && typeof m.content === 'string')
      .map((m: { role?: string; content?: string }) => ({
        role: m.role === 'assistant' ? ('assistant' as const) : ('user' as const),
        content: String(m.content).slice(0, 4000),
      }))
      .filter((m: { content: string }) => m.content.length > 0)

    if (safeMessages.length === 0) return err('پیام نامعتبر است')

    // اگر سرور، سرویس هوش مصنوعی نداشته باشد پیام روشن و صادقانه برمی‌گردد
    let zai
    try {
      zai = await ZAI.create()
    } catch {
      return err('سرویس هوش مصنوعی روی این سرور پیکربندی نشده است؛ بقیه بخش‌های بیان کار می‌کنند', 503)
    }

    const completion = await zai.chat.completions.create({
      messages: [{ role: 'system', content: SYSTEM_PROMPT }, ...safeMessages],
    })

    const reply = completion?.choices?.[0]?.message?.content || 'پاسخی دریافت نشد. دوباره تلاش کنید.'
    return NextResponse.json({ reply })
  } catch (e) {
    console.error('ai chat error', e)
    return err('دستیار بیان موقتاً در دسترس نیست. کمی بعد تلاش کنید', 500)
  }
}
