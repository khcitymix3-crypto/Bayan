import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { err } from '@/lib/api'

// ============================================================
// BAYAN | بیان — سرو تصویر از دیتابیس با هدرهای امن
// ============================================================

export async function GET(request: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params
    const media = await db.media.findUnique({ where: { id } })
    if (!media) return err('تصویر پیدا نشد', 404)

    const buffer = Buffer.from(media.data, 'base64')
    return new NextResponse(new Uint8Array(buffer), {
      headers: {
        'Content-Type': media.mime,
        'Content-Length': String(buffer.length),
        'Cache-Control': 'public, max-age=31536000, immutable',
        'X-Content-Type-Options': 'nosniff',
      },
    })
  } catch (e) {
    console.error('media error', e)
    return err('خطا در سرو تصویر', 500)
  }
}
