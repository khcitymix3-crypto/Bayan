import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { err, isResponse, requireUser } from '@/lib/api'
import { clientIp, rateLimit } from '@/lib/rate-limit'

// ============================================================
// BAYAN | بیان — آپلود رسانه با اعتبارسنجی امن
// - فقط تصویر jpeg/png/webp/gif
// - حداکثر ۵ مگابایت
// - پردازش با sharp: تغییر اندازه تا ۱۴۴۰px + تبدیل به webp
// MVP: ذخیره در دیتابیس (base64) — فاز ۲: Object Storage + CDN
// ============================================================

const ALLOWED = new Set(['image/jpeg', 'image/png', 'image/webp', 'image/gif'])
const MAX_SIZE = 5 * 1024 * 1024

export async function POST(request: NextRequest) {
  try {
    const auth = await requireUser(request)
    if (isResponse(auth)) return auth

    const rl = rateLimit(`upload:${auth.id}:${clientIp(request)}`, 30, 60 * 60 * 1000)
    if (!rl.ok) return err('سقف آپلود ساعتانه پر شده است', 429)

    const form = await request.formData().catch(() => null)
    if (!form) return err('فایل یافت نشد')

    const file = form.get('file')
    if (!(file instanceof File)) return err('فایل نامعتبر است')
    if (!ALLOWED.has(file.type)) return err('فقط تصویر JPEG / PNG / WebP / GIF مجاز است')
    if (file.size > MAX_SIZE) return err('حجم فایل باید کمتر از ۵ مگابایت باشد')

    const buffer = Buffer.from(await file.arrayBuffer())

    // پردازش تصویر با sharp (حذف metadata خطرناک + resize)
    const sharp = (await import('sharp')).default
    const processed = await sharp(buffer)
      .rotate() // اعمال EXIF rotation
      .resize(1440, 1440, { fit: 'inside', withoutEnlargement: true })
      .webp({ quality: 82 })
      .toBuffer({ resolveWithObject: true })

    const media = await db.media.create({
      data: {
        ownerId: auth.id,
        mime: 'image/webp',
        size: processed.data.length,
        width: processed.info.width,
        height: processed.info.height,
        data: processed.data.toString('base64'),
      },
    })

    return NextResponse.json({
      mediaId: media.id,
      url: `/api/media/${media.id}`,
      width: media.width,
      height: media.height,
    })
  } catch (e) {
    console.error('upload error', e)
    return err('خطا در پردازش تصویر', 500)
  }
}
