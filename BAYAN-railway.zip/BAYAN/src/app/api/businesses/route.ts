import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { err, isResponse, requireUser } from '@/lib/api'
import { normalizePersian } from '@/lib/persian'
import { clientIp, rateLimit } from '@/lib/rate-limit'

// ============================================================
// BAYAN | بیان — کسب‌وکارها: فهرست + ثبت کسب‌وکار جدید
// دسته‌بندی‌های گسترده مطابق سند محصول
// ============================================================

export const BUSINESS_CATEGORIES = [
  'فروشگاه', 'نانوایی', 'رستوران', 'پزشک', 'داروخانه', 'هتل',
  'مدرسه', 'دانشگاه', 'تعمیرگاه', 'شرکت', 'کارخانه', 'خدمات منزل',
  'گردشگری', 'حمل‌ونقل', 'مراکز عمومی', 'سایر',
]

export async function GET(request: NextRequest) {
  try {
    const sp = request.nextUrl.searchParams
    const q = normalizePersian(sp.get('q') || '')
    const category = sp.get('category') || undefined
    const mine = sp.get('mine') === '1'
    const me = await getAuthUserSafe(request)

    const where: Record<string, unknown> = {}
    if (category && category !== 'all') where.category = category
    if (mine && me) where.ownerId = me.id

    let businesses = await db.business.findMany({
      where,
      include: { owner: { select: { username: true, name: true } } },
      orderBy: { createdAt: 'desc' },
      take: 200,
    })

    if (q) {
      businesses = businesses.filter(
        (b) => normalizePersian(b.name).includes(q) || (b.description || '').length > 0 && normalizePersian(b.description || '').includes(q) || (b.address || '') && normalizePersian(b.address || '').includes(q)
      )
    }

    return NextResponse.json({
      businesses: businesses.map((b) => ({
        id: b.id,
        name: b.name,
        category: b.category,
        description: b.description || '',
        phone: b.phone || '',
        address: b.address || '',
        city: b.city || '',
        lat: b.lat,
        lng: b.lng,
        hours: b.hours || '',
        isVerified: b.isVerified,
        ownerUsername: b.owner?.username || null,
      })),
      categories: BUSINESS_CATEGORIES,
    })
  } catch (e) {
    console.error('businesses error', e)
    return err('خطا در دریافت کسب‌وکارها', 500)
  }
}

async function getAuthUserSafe(request: NextRequest) {
  const { getAuthUser } = await import('@/lib/auth')
  return getAuthUser(request)
}

export async function POST(request: NextRequest) {
  try {
    const auth = await requireUser(request)
    if (isResponse(auth)) return auth

    const rl = rateLimit(`business:${auth.id}:${clientIp(request)}`, 5, 24 * 60 * 60 * 1000)
    if (!rl.ok) return err('سقف ثبت کسب‌وکار روزانه پر شده است', 429)

    const body = await request.json().catch(() => null)
    if (!body) return err('درخواست نامعتبر است')

    const name = String(body.name || '').trim()
    const category = String(body.category || '').trim()
    const description = String(body.description || '').trim().slice(0, 1000)
    const phone = String(body.phone || '').trim().slice(0, 20)
    const address = String(body.address || '').trim().slice(0, 300)
    const city = String(body.city || '').trim().slice(0, 50)
    const hours = String(body.hours || '').trim().slice(0, 100)
    const lat = Number(body.lat)
    const lng = Number(body.lng)

    if (name.length < 2 || name.length > 80) return err('نام کسب‌وکار باید بین ۲ تا ۸۰ نویسه باشد')
    if (!BUSINESS_CATEGORIES.includes(category)) return err('دسته‌بندی معتبر انتخاب کنید')
    if (!Number.isFinite(lat) || lat < -90 || lat > 90) return err('عرض جغرافیایی نامعتبر است')
    if (!Number.isFinite(lng) || lng < -180 || lng > 180) return err('طول جغرافیایی نامعتبر است')

    const business = await db.business.create({
      data: { ownerId: auth.id, name, category, description, phone, address, city, hours, lat, lng },
    })

    return NextResponse.json({ business: { id: business.id } }, { status: 201 })
  } catch (e) {
    console.error('business create error', e)
    return err('خطا در ثبت کسب‌وکار', 500)
  }
}
