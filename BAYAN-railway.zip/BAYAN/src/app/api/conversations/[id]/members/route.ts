import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { err, forbidden, isResponse, notFound, requireUser } from '@/lib/api'

// ============================================================
// BAYAN | بیان — مدیریت اعضای گروه/کانال
// ============================================================

export async function POST(request: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const auth = await requireUser(request)
    if (isResponse(auth)) return auth
    const { id } = await ctx.params

    const membership = await db.convMember.findUnique({
      where: { conversationId_userId: { conversationId: id, userId: auth.id } },
      include: { conversation: true },
    })
    if (!membership) return forbidden()
    if (membership.conversation.type === 'DIRECT') return err('گفت‌وگوی خصوصی عضو نمی‌پذیرد')
    if (!['OWNER', 'ADMIN'].includes(membership.role)) return err('فقط مدیران می‌توانند عضو اضافه کنند')

    const body = await request.json().catch(() => null)
    const username = String(body?.username || '').trim()
    if (!username) return err('نام کاربری را وارد کنید')

    const user = await db.user.findUnique({ where: { username } })
    if (!user || user.status === 'BLOCKED') return notFound('کاربر')

    const existing = await db.convMember.findUnique({
      where: { conversationId_userId: { conversationId: id, userId: user.id } },
    })
    if (existing) return err('این کاربر از قبل عضو است')

    await db.convMember.create({ data: { conversationId: id, userId: user.id } })
    await db.message.create({
      data: {
        conversationId: id,
        type: 'SYSTEM',
        content: `${user.name} به ${membership.conversation.type === 'CHANNEL' ? 'کانال' : 'گروه'} اضافه شد.`,
      },
    })

    return NextResponse.json({ ok: true, added: user.username })
  } catch (e) {
    console.error('add member error', e)
    return err('خطا در افزودن عضو', 500)
  }
}
