import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { err, forbidden, isResponse, notify, notFound, requireUser } from '@/lib/api'
import { clientIp, rateLimit } from '@/lib/rate-limit'

// ============================================================
// BAYAN | بیان — پیام‌های یک گفت‌وگو + ارسال پیام
// دسترسی فقط برای اعضای مجاز گفت‌وگو (کنترل سمت سرور)
// ============================================================

async function getMembership(conversationId: string, userId: string) {
  return db.convMember.findUnique({
    where: { conversationId_userId: { conversationId, userId } },
    include: { conversation: true },
  })
}

export async function GET(request: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const auth = await requireUser(request)
    if (isResponse(auth)) return auth
    const { id } = await ctx.params

    const membership = await getMembership(id, auth.id)
    if (!membership) return forbidden()

    const sp = request.nextUrl.searchParams
    const after = sp.get('after')

    const messages = await db.message.findMany({
      where: {
        conversationId: id,
        isDeleted: false,
        ...(after ? { createdAt: { gt: new Date(after) } } : {}),
      },
      include: { sender: { select: { id: true, name: true, username: true, avatarUrl: true } } },
      orderBy: { createdAt: 'asc' },
      take: 200,
    })

    // علامت‌گذاری خوانده‌شدن
    await db.convMember.update({
      where: { id: membership.id },
      data: { lastReadAt: new Date() },
    })

    return NextResponse.json({
      conversation: {
        id: membership.conversation.id,
        type: membership.conversation.type,
        title: membership.conversation.title,
        description: membership.conversation.description || '',
        myRole: membership.role,
      },
      messages: messages.map((m) => ({
        id: m.id,
        type: m.type,
        content: m.content,
        mediaId: m.mediaId,
        createdAt: m.createdAt,
        isMine: m.senderId === auth.id,
        sender: m.sender,
      })),
    })
  } catch (e) {
    console.error('messages error', e)
    return err('خطا در دریافت پیام‌ها', 500)
  }
}

export async function POST(request: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const auth = await requireUser(request)
    if (isResponse(auth)) return auth
    const { id } = await ctx.params

    const rl = rateLimit(`msg:${auth.id}:${clientIp(request)}`, 60, 60 * 1000)
    if (!rl.ok) return err('سرعت ارسال پیام بیش از حد مجاز', 429)

    const membership = await getMembership(id, auth.id)
    if (!membership) return forbidden()

    const conv = membership.conversation
    // در کانال فقط مالک و مدیر می‌توانند پست کنند
    if (conv.type === 'CHANNEL' && membership.role === 'MEMBER') {
      return err('در کانال فقط مدیران می‌توانند پیام منتشر کنند', 403)
    }

    const body = await request.json().catch(() => null)
    const content = String(body?.content || '').trim()
    const mediaId = typeof body?.mediaId === 'string' && body.mediaId ? body.mediaId : null
    const type = mediaId ? 'IMAGE' : 'TEXT'
    if (!content && !mediaId) return err('پیام خالی است')
    if (content.length > 4000) return err('متن پیام حداکثر ۴۰۰۰ نویسه است')

    const message = await db.message.create({
      data: { conversationId: id, senderId: auth.id, type, content: content || '🖼', mediaId },
      include: { sender: { select: { id: true, name: true, username: true, avatarUrl: true } } },
    })

    await db.conversation.update({ where: { id }, data: { lastMessageAt: new Date() } })

    // اعلان برای اعضای دیگر
    const members = await db.convMember.findMany({
      where: { conversationId: id, userId: { not: auth.id } },
      select: { userId: true },
    })
    const preview = type === 'IMAGE' ? 'یک عکس ارسال کرد' : content.slice(0, 80)
    for (const m of members.slice(0, 50)) {
      await notify({
        userId: m.userId,
        actorId: auth.id,
        type: 'MESSAGE',
        entityId: id,
        text: `${conv.type === 'CHANNEL' ? conv.title + ': ' : ''}${preview}`,
      })
    }

    // اگر پاسخ بعد از ۳۰ ثانیه آمد، پاسخ خودکار BAYAN AI در گفت‌وگوی دمو فعال نیست — فاز ۲

    return NextResponse.json({
      message: {
        id: message.id,
        type: message.type,
        content: message.content,
        mediaId: message.mediaId,
        createdAt: message.createdAt,
        isMine: true,
        sender: message.sender,
      },
    })
  } catch (e) {
    console.error('send message error', e)
    return err('خطا در ارسال پیام', 500)
  }
}
