import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { err, isResponse, requireUser } from '@/lib/api'

// ============================================================
// BAYAN | بیان — گفت‌وگوها: فهرست + ساخت گفت‌وگوی خصوصی / گروه / کانال
// ============================================================

export async function GET(request: NextRequest) {
  try {
    const auth = await requireUser(request)
    if (isResponse(auth)) return auth

    const memberships = await db.convMember.findMany({
      where: { userId: auth.id },
      include: {
        conversation: {
          include: {
            members: { include: { user: { select: { id: true, name: true, username: true, avatarUrl: true } } } },
            messages: { orderBy: { createdAt: 'desc' }, take: 1, include: { sender: { select: { name: true } } } },
          },
        },
      },
    })

    const conversations = memberships
      .map((m) => {
        const conv = m.conversation
        const other = conv.type === 'DIRECT' ? conv.members.find((x) => x.userId !== auth.id)?.user : null
        const last = conv.messages[0]
        // تعداد پیام‌های نخوانده
        const unreadAfter = m.lastReadAt || new Date(0)
        return {
          id: conv.id,
          type: conv.type,
          title: conv.type === 'DIRECT' ? other?.name || 'کاربر حذف‌شده' : conv.title || 'بدون عنوان',
          avatarUrl: conv.type === 'DIRECT' ? other?.avatarUrl : null,
          otherUsername: other?.username || null,
          description: conv.description || '',
          membersCount: conv.members.length,
          lastMessage: last
            ? {
                content: last.type === 'IMAGE' ? '🖼 عکس' : last.content,
                senderName: last.sender?.name || '',
                createdAt: last.createdAt,
                isMine: last.senderId === auth.id,
              }
            : null,
          lastMessageAt: conv.lastMessageAt,
          myRole: m.role,
        }
      })
      .sort((a, b) => new Date(b.lastMessageAt).getTime() - new Date(a.lastMessageAt).getTime())

    // شمارش unread واقعی
    const withUnread = await Promise.all(
      conversations.map(async (c) => {
        const m = memberships.find((x) => x.conversation.id === c.id)!
        const unread = await db.message.count({
          where: {
            conversationId: c.id,
            isDeleted: false,
            senderId: { not: auth.id },
            createdAt: { gt: m.lastReadAt || new Date(0) },
          },
        })
        return { ...c, unread }
      })
    )

    return NextResponse.json({ conversations: withUnread })
  } catch (e) {
    console.error('conversations error', e)
    return err('خطا در دریافت گفت‌وگوها', 500)
  }
}

export async function POST(request: NextRequest) {
  try {
    const auth = await requireUser(request)
    if (isResponse(auth)) return auth

    const body = await request.json().catch(() => null)
    if (!body) return err('درخواست نامعتبر است')

    const type = ['DIRECT', 'GROUP', 'CHANNEL'].includes(body.type) ? body.type : 'DIRECT'

    // گفت‌وگوی خصوصی: اگر از قبل وجود دارد همان را بده
    if (type === 'DIRECT') {
      const targetUsername = String(body.username || '')
      const target = await db.user.findUnique({ where: { username: targetUsername } })
      if (!target || target.status === 'BLOCKED') return err('کاربر پیدا نشد', 404)
      if (target.id === auth.id) return err('نمی‌توانید با خودتان گفت‌وگو کنید')

      // حریم خصوصی پیام
      if (target.privacyMessage === 'NOBODY') return err('این کاربر پیام خصوصی را بسته است')
      if (target.privacyMessage === 'FOLLOWERS') {
        const followsMe = await db.follow.findFirst({
          where: { followerId: target.id, followingId: auth.id },
        })
        if (!followsMe) return err('این کاربر فقط پیام از دنبال‌کنندگان را می‌پذیرد')
      }

      const mine = await db.convMember.findMany({
        where: { userId: auth.id, conversation: { type: 'DIRECT' } },
        select: { conversationId: true },
      })
      const theirs = await db.convMember.findMany({
        where: { userId: target.id, conversation: { type: 'DIRECT' } },
        select: { conversationId: true },
      })
      const shared = mine.find((m) => theirs.some((t) => t.conversationId === m.conversationId))

      if (shared) return NextResponse.json({ conversationId: shared.conversationId })

      const conv = await db.conversation.create({ data: { type: 'DIRECT' } })
      await db.convMember.createMany({
        data: [
          { conversationId: conv.id, userId: auth.id, role: 'OWNER' },
          { conversationId: conv.id, userId: target.id },
        ],
      })
      return NextResponse.json({ conversationId: conv.id }, { status: 201 })
    }

    // گروه / کانال
    const title = String(body.title || '').trim()
    if (title.length < 2 || title.length > 60) return err('عنوان باید بین ۲ تا ۶۰ نویسه باشد')
    const description = String(body.description || '').trim().slice(0, 300)

    const conv = await db.conversation.create({
      data: { type, title, description, ownerId: auth.id },
    })
    await db.convMember.create({
      data: { conversationId: conv.id, userId: auth.id, role: 'OWNER' },
    })

    // افزودن اعضا با نام کاربری (اختیاری)
    const memberUsernames: string[] = Array.isArray(body.members) ? body.members.slice(0, 50) : []
    for (const username of memberUsernames) {
      const u = await db.user.findUnique({ where: { username: String(username) } })
      if (u && u.id !== auth.id) {
        await db.convMember
          .create({ data: { conversationId: conv.id, userId: u.id } })
          .catch(() => null)
      }
    }

    return NextResponse.json({ conversationId: conv.id }, { status: 201 })
  } catch (e) {
    console.error('create conversation error', e)
    return err('خطا در ساخت گفت‌وگو', 500)
  }
}
