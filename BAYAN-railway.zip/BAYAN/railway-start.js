'use strict';

// ============================================================
// BAYAN | بیان — لانچر Railway
// وظیفه: اگر DATABASE_URL به یک فایل خالی (مثل Volume تازه) اشاره کند،
// نسخهٔ آماده با حساب‌های نمونه به آن کپی می‌شود؛ بعد سرور روشن می‌شود.
// ============================================================

const fs = require('fs');
const path = require('path');

process.env.NODE_ENV = process.env.NODE_ENV || 'production';

if (!process.env.DATABASE_URL) {
  // پیش‌فرض: همان دیتابیس آماده داخل پروژه (حاوی حساب‌های نمونه)
  process.env.DATABASE_URL = 'file:' + path.join(__dirname, 'db', 'custom.db');
} else {
  // اگر مسیر سفارشی (مثلاً Volume در /data) خالی بود، seed را کپی کن
  const dbPath = process.env.DATABASE_URL.replace(/^file:/, '');
  try {
    if (!fs.existsSync(dbPath)) {
      fs.mkdirSync(path.dirname(dbPath), { recursive: true });
      fs.copyFileSync(path.join(__dirname, 'db', 'custom.db'), dbPath);
      console.log('[BAYAN] دیتابیس اولیه ساخته شد: ' + dbPath);
    }
  } catch (e) {
    console.error('[BAYAN] خطا در ساخت دیتابیس: ' + e.message);
  }
}

// جلوگیری از خطای bind وقتی HOSTNAME مقدار سیستمی دارد
process.env.HOSTNAME = '0.0.0.0';

console.log('[BAYAN] DATABASE_URL=' + process.env.DATABASE_URL);
require(path.join(__dirname, '.next', 'standalone', 'server.js'));
