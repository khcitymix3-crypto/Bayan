// ============================================================
// BAYAN | بیان — Service Worker (PWA)
// استراتژی: Network-First برای API، Cache-First برای آیکون‌ها
// ============================================================

const CACHE_NAME = 'bayan-v1'
const STATIC_CACHE = ['/', '/manifest.webmanifest', '/icons/icon-192.png', '/icons/icon-512.png']

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(STATIC_CACHE)).catch(() => null)
  )
  self.skipWaiting()
})

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  )
  self.clients.claim()
})

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url)
  if (event.request.method !== 'GET' || url.origin !== location.origin) return

  // API و تصاویر: شبکه اول، کش پشتیبان (آفلاین محدود)
  if (url.pathname.startsWith('/api/')) {
    if (url.pathname.startsWith('/api/media/')) {
      event.respondWith(
        caches.open(CACHE_NAME).then(async (cache) => {
          const cached = await cache.match(event.request)
          if (cached) return cached
          const res = await fetch(event.request).catch(() => null)
          if (res && res.ok) cache.put(event.request, res.clone())
          return res
        })
      )
    }
    return // سایر APIها مستقیم به شبکه
  }

  // صفحات و آیکون‌ها: کش اول با به‌روزرسانی پس‌زمینه
  event.respondWith(
    caches.open(CACHE_NAME).then(async (cache) => {
      const cached = await cache.match(event.request)
      const fetchPromise = fetch(event.request)
        .then((res) => {
          if (res.ok) cache.put(event.request, res.clone())
          return res
        })
        .catch(() => cached)
      return cached || fetchPromise
    })
  )
})
